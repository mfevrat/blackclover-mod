package com.blackclovermod.item;

import com.blackclovermod.magic.KnightOrder;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Capuche ou robe d'un ordre de chevaliers-mages. La robe affiche aussi une cape 3D. */
public class OrderArmorItem extends ArmorItem {
    public final KnightOrder order;

    public OrderArmorItem(KnightOrder order, Type type, Properties props) {
        super(OrderArmorMaterial.INSTANCE, type, props);
        this.order = order;
    }

    @Override
    public @Nullable String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return "blackclover:textures/models/armor/" + order.id + "_armor.png";
    }

    /** Modèle 3D détaillé (côté client uniquement). */
    @Override
    public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(com.blackclovermod.client.OrderArmorClientExtensions.INSTANCE);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(order.displayName());
        tip.add(Component.translatable("tooltip.blackclover.order_set").withStyle(ChatFormatting.DARK_AQUA));
        tip.add(order.bonusText());
    }
}
