package com.blackclovermod.item;

import com.blackclovermod.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Matériau des tenues d'ordre : légères (comme du fer léger), très enchantables. */
public final class OrderArmorMaterial implements ArmorMaterial {
    public static final OrderArmorMaterial INSTANCE = new OrderArmorMaterial();

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return switch (type) { case HELMET -> 220; case CHESTPLATE -> 320; case LEGGINGS -> 300; case BOOTS -> 260; };
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) { case HELMET -> 2; case CHESTPLATE -> 6; case LEGGINGS -> 5; case BOOTS -> 2; };
    }

    @Override public int getEnchantmentValue() { return 20; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.MANA_CRYSTAL.get()); }
    @Override public String getName() { return "blackclover:order"; }
    @Override public float getToughness() { return 1.0f; }
    @Override public float getKnockbackResistance() { return 0f; }

    private OrderArmorMaterial() {}
}
