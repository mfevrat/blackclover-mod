package com.blackclovermod.item;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.block.AltarBlock;
import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

import java.util.function.Supplier;

/**
 * Objet d'invocation de boss.
 * - Sur l'autel de la bonne structure : lance le rituel (géré par AltarBlock).
 * - N'importe où ailleurs : vibre et indique la direction de la structure la plus proche.
 */
public class BossSummonItem extends LoreItem {
    private final Supplier<? extends EntityType<? extends MagicBossEntity>> type;
    private final TagKey<Structure> structure;
    private final ResourceKey<Level> dimension;

    public BossSummonItem(Properties props, Supplier<? extends EntityType<? extends MagicBossEntity>> type, String structure, ResourceKey<Level> dimension) {
        super(props);
        this.type = type;
        this.structure = TagKey.create(Registries.STRUCTURE, BlackCloverMod.id(structure));
        this.dimension = dimension;
    }

    public EntityType<? extends MagicBossEntity> bossType() { return type.get(); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel sl) locate(sl, player);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().getBlockState(ctx.getClickedPos()).getBlock() instanceof AltarBlock) return InteractionResult.PASS;
        if (ctx.getLevel() instanceof ServerLevel sl && ctx.getPlayer() != null) locate(sl, ctx.getPlayer());
        return InteractionResult.sidedSuccess(ctx.getLevel().isClientSide);
    }

    private void locate(ServerLevel level, Player player) {
        if (player.getCooldowns().isOnCooldown(this)) return;
        player.getCooldowns().addCooldown(this, 60);
        if (level.dimension() != dimension) {
            player.displayClientMessage(Component.translatable(dimension == Level.NETHER ? "msg.blackclover.locate_nether" : "msg.blackclover.locate_overworld")
                    .withStyle(ChatFormatting.GOLD), false);
            return;
        }
        BlockPos found = level.findNearestMapStructure(structure, player.blockPosition(), 100, false);
        if (found == null) {
            player.displayClientMessage(Component.translatable("msg.blackclover.locate_none").withStyle(ChatFormatting.GRAY), false);
            return;
        }
        int dx = found.getX() - player.getBlockX(), dz = found.getZ() - player.getBlockZ();
        int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
        String[] dirs = {"south", "southwest", "west", "northwest", "north", "northeast", "east", "southeast"};
        int idx = Math.floorMod(Math.round((float) (Math.toDegrees(Math.atan2(-dx, dz)) / 45.0)), 8);
        player.displayClientMessage(Component.translatable("msg.blackclover.locate", getDescription(),
                Component.translatable("dir.blackclover." + dirs[idx]), dist, found.getX(), found.getZ()).withStyle(ChatFormatting.AQUA), false);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, player.getSoundSource(), 1f, 0.7f);
    }
}
