package com.blackclovermod.item;

import com.blackclovermod.magic.MagicData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Cristal de mana : +20 mana maximum (jusqu'à +200). */
public class ManaCrystalItem extends LoreItem {
    public ManaCrystalItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        if (!MagicData.hasGrimoire(sp)) {
            sp.displayClientMessage(Component.translatable("msg.blackclover.need_grimoire_first").withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }
        if (MagicData.bonusMana(sp) >= MagicData.MAX_BONUS_MANA) {
            sp.displayClientMessage(Component.translatable("msg.blackclover.crystal_max").withStyle(ChatFormatting.YELLOW), true);
            return InteractionResultHolder.fail(stack);
        }
        MagicData.addBonusMana(sp, 20);
        MagicData.setMana(sp, MagicData.maxMana(sp));
        MagicData.sync(sp);
        if (MagicData.maxMana(sp) >= 300) com.blackclovermod.util.ModAdvancements.award(sp, "mana_reservoir");
        sp.serverLevel().sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.4, 0.6, 0.4, 0.05);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, sp.getSoundSource(), 1.5f, 1.2f);
        sp.displayClientMessage(Component.translatable("msg.blackclover.crystal_used", (int) MagicData.maxMana(sp)).withStyle(ChatFormatting.AQUA), true);
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }
}
