package com.blackclovermod.item;

import com.blackclovermod.entity.MagicCircleEntity;
import com.blackclovermod.entity.MagicProjectileEntity;
import com.blackclovermod.entity.ProjectileKind;
import com.blackclovermod.entity.SpellBeamEntity;
import com.blackclovermod.entity.boss.MagicBossEntity;
import com.blackclovermod.magic.AntiSwords;
import com.blackclovermod.magic.MagicData;
import com.blackclovermod.magic.MagicElement;
import com.blackclovermod.util.Fx;
import com.blackclovermod.util.TaskScheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * ÉPÉES D'ANTI-MAGIE, invoquées depuis le grimoire à 5 feuilles (elles disparaissent au bout de 30 secondes).
 * Chaque épée frappe fort au corps à corps et possède une capacité au CLIC DROIT.
 */
public class AntiSwordItem extends SwordItem {
    public enum Kind { SLAYER, DWELLER, DESTROYER, SLASHER }

    public static final int LIFETIME = 600;
    private static final Tier TIER = new Tier() {
        @Override public int getUses() { return 0; }           // incassable
        @Override public float getSpeed() { return 8f; }
        @Override public float getAttackDamageBonus() { return 0f; }
        @Override public int getLevel() { return 4; }
        @Override public int getEnchantmentValue() { return 0; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    };

    public final Kind kind;

    public AntiSwordItem(Kind kind, int damage, float speed, Properties props) {
        super(TIER, damage, speed, props);
        this.kind = kind;
    }

    // ------------------------------------------------------------------
    // Passifs (tant que l'épée est en main)
    // ------------------------------------------------------------------
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof ServerPlayer p)) return;
        long expire = stack.getOrCreateTag().getLong("Expire");
        if (expire == 0 || level.getGameTime() > expire || !MagicData.hasGrimoire(p) || MagicData.element(p) != MagicElement.ANTI) {
            AntiSwords.dismiss(p, true);
            return;
        }
        if (!selected) return;
        ServerLevel l = p.serverLevel();
        if (p.tickCount % 3 == 0) {
            Vec3 hand = p.position().add(0, 1.1, 0).add(Vec3.directionFromRotation(0, p.yBodyRot + 90).scale(-0.4));
            l.sendParticles(ParticleTypes.LARGE_SMOKE, hand.x, hand.y, hand.z, 1, 0.1, 0.3, 0.1, 0.005);
        }
        if (kind == Kind.SLAYER) {          // renvoie les projectiles qui l'approchent
            for (Projectile pr : l.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(2.5), x -> x.getOwner() != p)) {
                Vec3 v = pr.getDeltaMovement();
                if (v.dot(p.position().subtract(pr.position())) <= 0) continue; // ne s'approche pas
                pr.setOwner(p);
                pr.setDeltaMovement(v.scale(-1.3));
                l.sendParticles(ParticleTypes.SWEEP_ATTACK, pr.getX(), pr.getY(), pr.getZ(), 1, 0, 0, 0, 0);
                Fx.sound(l, pr.position(), SoundEvents.ANVIL_LAND, 0.4f, 1.8f);
            }
        } else if (kind == Kind.DWELLER) {  // absorbe la magie des alentours
            int charge = stack.getTag().getInt("Charge");
            for (MagicProjectileEntity m : l.getEntitiesOfClass(MagicProjectileEntity.class, p.getBoundingBox().inflate(5), x -> x.getOwner() != p)) {
                Fx.line(l, ParticleTypes.SQUID_INK, m.position(), p.position().add(0, 1, 0), 0.3);
                m.discard();
                charge = Math.min(12, charge + 1);
                Fx.sound(l, p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.4f, 0.5f);
            }
            stack.getTag().putInt("Charge", charge);
        }
    }

    // ------------------------------------------------------------------
    // Capacités (clic droit)
    // ------------------------------------------------------------------
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        if (!(player instanceof ServerPlayer p) || p.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        float pow = MagicData.power(p);
        int cd = switch (kind) {
            case SLAYER -> { slayerSlash(p, pow); yield 40; }
            case DWELLER -> { dwellerRelease(p, stack, pow); yield 30; }
            case DESTROYER -> { annihilda(p, pow); yield 200; }
            case SLASHER -> targetedCut(p, pow) ? 70 : 10;
        };
        p.getCooldowns().addCooldown(this, cd);
        p.swing(hand, true);
        return InteractionResultHolder.consume(stack);
    }

    /** Épée du Démon : immense tranche en arc qui coupe et dissipe la magie. */
    private static void slayerSlash(ServerPlayer p, float pow) {
        ServerLevel l = p.serverLevel();
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle();
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), x -> x != p && x.isAlive() && !x.isAlliedTo(p))) {
            Vec3 to = e.position().add(0, e.getBbHeight() / 2, 0).subtract(eye);
            if (to.length() < 6 && to.normalize().dot(look) > 0.3) {
                e.invulnerableTime = 0;
                e.hurt(p.damageSources().playerAttack(p), 16 * pow);
                e.knockback(1.2, -look.x, -look.z);
            }
        }
        for (MagicProjectileEntity m : l.getEntitiesOfClass(MagicProjectileEntity.class, p.getBoundingBox().inflate(7), x -> x.getOwner() != p)) m.discard();
        for (int a = -70; a <= 70; a += 5) {
            Vec3 d = look.yRot((float) Math.toRadians(a));
            for (double r = 2; r <= 5; r += 1.5) {
                Vec3 q = eye.add(d.scale(r)).add(0, -0.4, 0);
                l.sendParticles(MagicElement.ANTI.dust(2.2f), q.x, q.y, q.z, 1, 0.05, 0.05, 0.05, 0);
            }
            Vec3 q = eye.add(d.scale(4)).add(0, -0.4, 0);
            l.sendParticles(ParticleTypes.LARGE_SMOKE, q.x, q.y, q.z, 1, 0.05, 0.05, 0.05, 0.02);
        }
        l.sendParticles(ParticleTypes.SWEEP_ATTACK, eye.x + look.x * 2.5, eye.y - 0.4 + look.y * 2.5, eye.z + look.z * 2.5, 3, 0.8, 0.2, 0.8, 0);
        Fx.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 0.45f);
        Fx.sound(l, p.position(), SoundEvents.ANVIL_LAND, 0.4f, 1.4f);
    }

    /** Épée du Habitacle : libère la magie absorbée sous forme de tranche d'énergie. */
    private static void dwellerRelease(ServerPlayer p, ItemStack stack, float pow) {
        ServerLevel l = p.serverLevel();
        int charge = stack.getOrCreateTag().getInt("Charge");
        stack.getTag().putInt("Charge", 0);
        Vec3 look = p.getLookAngle();
        MagicProjectileEntity m = new MagicProjectileEntity(l, p, ProjectileKind.ANTI_SLASH, (8 + 3 * charge) * pow, 1.0f + charge * 0.15f);
        m.setPos(p.getX() + look.x, p.getEyeY() - 0.3 + look.y, p.getZ() + look.z);
        m.shoot(look.x, look.y, look.z, 2.0f, 0f);
        l.addFreshEntity(m);
        if (charge > 0) {
            float[] ang = Fx.beamAngles(look);
            Fx.circle(l, p.getEyePosition().add(look.scale(1.2)), 1.2f + charge * 0.15f, 0x8A3AD0, 12, 2, ang[0], ang[1]);
            p.displayClientMessage(Component.translatable("msg.blackclover.dweller_release", charge).withStyle(ChatFormatting.DARK_PURPLE), true);
        }
        Fx.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.6f);
    }

    /** Épée du Destructeur — ANNIHILDA : brise malédictions, enchantements et magie dans une vaste zone. */
    private static void annihilda(ServerPlayer p, float pow) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        p.removeEffect(net.minecraft.world.effect.MobEffects.WITHER);
        List<MobEffectInstance> bad = new ArrayList<>();
        for (Player ally : l.getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(12))) {
            bad.clear();
            for (MobEffectInstance ef : ally.getActiveEffects()) if (!ef.getEffect().isBeneficial()) bad.add(ef);
            for (MobEffectInstance ef : bad) ally.removeEffect(ef.getEffect());
        }
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(12), x -> x != p && !(x instanceof Player) && x.isAlive())) {
            e.removeAllEffects();
            e.invulnerableTime = 0;
            e.hurt(p.damageSources().playerAttack(p), 10 * pow);
            if (e instanceof MagicBossEntity boss) boss.interrupt(80);
        }
        AABB box = p.getBoundingBox().inflate(16);
        for (MagicProjectileEntity m : l.getEntitiesOfClass(MagicProjectileEntity.class, box, x -> x.getOwner() != p)) m.discard();
        for (MagicCircleEntity m : l.getEntitiesOfClass(MagicCircleEntity.class, box)) m.discard();
        for (SpellBeamEntity b : l.getEntitiesOfClass(SpellBeamEntity.class, box)) b.discard();
        Fx.circle(l, c.add(0, 0.05, 0), 12f, 0xC01818, 30, 2);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3;
            Fx.beam(l, c.add(Math.cos(a) * 6, 14, Math.sin(a) * 6), 14f, 1.2f, 0xC01818, 14, 180f, 0f);
        }
        TaskScheduler.repeat(12, k -> Fx.ringOut(l, ParticleTypes.LARGE_SMOKE, c.add(0, 0.3, 0), 1 + k, 30 + k * 6, 0.1));
        Fx.burst(l, ParticleTypes.EXPLOSION_EMITTER, c.add(0, 1, 0), 1, 0, 0);
        Fx.sound(l, c, SoundEvents.WARDEN_SONIC_BOOM, 2f, 0.6f);
        Fx.sound(l, c, SoundEvents.GLASS_BREAK, 2f, 0.5f);
    }

    /** Sabre du Démon : traverse et tranche UNIQUEMENT la cible visée (les autres ne sont pas touchés). */
    private static boolean targetedCut(ServerPlayer p, float pow) {
        ServerLevel l = p.serverLevel();
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle(), end = eye.add(look.scale(24));
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(l, p, eye, end, p.getBoundingBox().expandTowards(look.scale(24)).inflate(1.5),
                e -> e instanceof LivingEntity && e != p && e.isAlive() && !e.isSpectator());
        if (hit == null || !(hit.getEntity() instanceof LivingEntity target)) {
            p.displayClientMessage(Component.translatable("msg.blackclover.katana_no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 start = p.position();
        Vec3 dir = target.position().subtract(start);
        Vec3 h = new Vec3(dir.x, 0, dir.z).normalize();
        Vec3 dest = target.position().add(h.scale(target.getBbWidth() / 2 + 1.5));
        if (!l.noCollision(p, p.getBoundingBox().move(dest.subtract(start)))) dest = target.position().subtract(h.scale(target.getBbWidth() / 2 + 1.2));
        Fx.line(l, MagicElement.ANTI.dust(1.8f), start.add(0, 1, 0), dest.add(0, 1, 0), 0.25);
        Fx.line(l, ParticleTypes.SWEEP_ATTACK, start.add(0, 1, 0), dest.add(0, 1, 0), 1.5);
        p.teleportTo(dest.x, dest.y, dest.z);
        p.fallDistance = 0;
        target.invulnerableTime = 0;
        target.hurt(p.damageSources().playerAttack(p), 22 * pow);
        if (!(target instanceof Player)) target.removeAllEffects();
        l.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(), 4, 0.3, 0.4, 0.3, 0);
        Fx.sound(l, dest, SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 1.6f);
        Fx.sound(l, dest, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.8f);
        return true;
    }

    // ------------------------------------------------------------------
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // l'anti-magie annule les bonus magiques de la cible
        if (!(target instanceof Player)) {
            List<MobEffectInstance> good = new ArrayList<>();
            for (MobEffectInstance ef : target.getActiveEffects()) if (ef.getEffect().isBeneficial()) good.add(ef);
            for (MobEffectInstance ef : good) target.removeEffect(ef.getEffect());
        }
        if (target.level() instanceof ServerLevel l)
            l.sendParticles(ParticleTypes.LARGE_SMOKE, target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(), 6, 0.2, 0.3, 0.2, 0.02);
        return super.hurtEnemy(stack, target, attacker);
    }

    /** Lâchée au sol, l'épée retourne dans le grimoire. */
    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        entity.discard();
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable(getDescriptionId() + ".desc").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("tooltip.blackclover.anti_sword").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        if (kind == Kind.DWELLER && stack.hasTag())
            tip.add(Component.translatable("tooltip.blackclover.charge", stack.getTag().getInt("Charge")).withStyle(ChatFormatting.DARK_PURPLE));
    }
}
