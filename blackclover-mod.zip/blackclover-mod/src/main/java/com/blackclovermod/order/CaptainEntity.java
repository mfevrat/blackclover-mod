package com.blackclovermod.order;

import com.blackclovermod.magic.KnightOrder;
import com.blackclovermod.registry.ModItems;
import com.blackclovermod.util.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Capitaine d'un ordre de chevaliers-mages (personnage original).
 * - "Home" : vit au quartier général de son ordre et parle aux joueurs.
 * - "Temporaire" : apparaît au Colisée pendant l'examen d'entrée, puis disparaît.
 */
public class CaptainEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> ORDER = SynchedEntityData.defineId(CaptainEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> RAISED = SynchedEntityData.defineId(CaptainEntity.class, EntityDataSerializers.BOOLEAN);
    private boolean home;
    private int tempLife = -1;

    public CaptainEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 200).add(Attributes.MOVEMENT_SPEED, 0.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 16f));
        goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(ORDER, 0);
        entityData.define(RAISED, false);
    }

    public KnightOrder order() { return KnightOrder.values()[Math.max(0, Math.min(4, entityData.get(ORDER)))]; }

    public void setOrder(KnightOrder o) {
        entityData.set(ORDER, o.ordinal());
        setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.HOODS.get(o).get()));
        setItemSlot(EquipmentSlot.CHEST, new ItemStack(ModItems.ROBES.get(o).get()));
        setDropChance(EquipmentSlot.HEAD, 0f);
        setDropChance(EquipmentSlot.CHEST, 0f);
    }

    public boolean isRaised() { return entityData.get(RAISED); }
    public void setRaised(boolean b) { entityData.set(RAISED, b); }
    public void makeTemporary(int ticks) { tempLife = ticks; }
    public boolean isHome() { return home; }

    @Override
    public Component getName() {
        return Component.translatable("captain.blackclover." + order().id);
    }

    @Override public boolean shouldShowName() { return true; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // les capitaines sont intouchables (sauf commande /kill)
        if (source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (isRaised() && tickCount % 3 == 0)
                level().addParticle(ParticleTypes.END_ROD, getX(), getY() + 2.6, getZ(), 0, 0.05, 0);
            return;
        }
        if (getItemBySlot(EquipmentSlot.CHEST).isEmpty()) setOrder(order());
        if (tempLife > 0 && --tempLife == 0) vanish();
    }

    public void vanish() {
        if (level() instanceof ServerLevel l) {
            l.sendParticles(ParticleTypes.POOF, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.05);
            Fx.circle(l, position().add(0, 0.05, 0), 1.4f, order().color, 15, 1);
            Fx.sound(l, position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.2f);
        }
        discard();
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            if (!ExamManager.onCaptainClicked(this, sp)) CaptainDialogue.talk(this, sp);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Order", order().id);
        tag.putBoolean("Home", home);
        tag.putBoolean("Temp", tempLife > 0);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        for (KnightOrder o : KnightOrder.values()) if (o.id.equals(tag.getString("Order"))) setOrder(o);
        home = tag.getBoolean("Home");
        if (tag.getBoolean("Temp")) tempLife = 1;      // un capitaine d'examen ne survit pas à un redémarrage
    }
}
