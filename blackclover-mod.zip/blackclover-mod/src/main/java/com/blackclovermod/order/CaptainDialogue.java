package com.blackclovermod.order;

import com.blackclovermod.magic.KnightOrder;
import com.blackclovermod.magic.MagicData;
import com.blackclovermod.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

/** Ce que disent les capitaines quand on leur parle à leur quartier général. */
public final class CaptainDialogue {

    public static void talk(CaptainEntity c, ServerPlayer p) {
        KnightOrder o = c.order();
        Component name = c.getName().copy().withStyle(s -> s.withColor(o.color));
        String key;
        KnightOrder mine = MagicData.order(p);
        if (!MagicData.hasGrimoire(p)) key = "no_grimoire";
        else if (mine == null) key = "not_member";
        else if (mine != o) key = "other_order";
        else {
            key = "member";
            long now = p.level().getGameTime();
            if (now > MagicData.gearCooldown(p)) {          // le capitaine fournit une tenue neuve une fois par jour
                MagicData.setGearCooldown(p, now + 24000);
                p.getInventory().add(new ItemStack(ModItems.HOODS.get(o).get()));
                p.getInventory().add(new ItemStack(ModItems.ROBES.get(o).get()));
                p.sendSystemMessage(Component.translatable("dialogue.blackclover.gear").withStyle(ChatFormatting.GREEN));
            }
        }
        p.sendSystemMessage(Component.literal("").append(name).append(" : ")
                .append(Component.translatable("dialogue.blackclover." + o.id + "." + key, mine == null ? "" : mine.displayName()).withStyle(ChatFormatting.WHITE)));
        p.playNotifySound(SoundEvents.VILLAGER_AMBIENT, net.minecraft.sounds.SoundSource.NEUTRAL, 0.6f, 0.8f);
    }

    private CaptainDialogue() {}
}
