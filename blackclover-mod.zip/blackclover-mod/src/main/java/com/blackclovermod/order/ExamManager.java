package com.blackclovermod.order;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.cinematic.CinematicType;
import com.blackclovermod.cinematic.Cinematics;
import com.blackclovermod.magic.KnightOrder;
import com.blackclovermod.magic.MagicData;
import com.blackclovermod.magic.MagicElement;
import com.blackclovermod.magic.PlayerAnimState;
import com.blackclovermod.registry.ModEntities;
import com.blackclovermod.registry.ModItems;
import com.blackclovermod.registry.ModParticles;
import com.blackclovermod.util.Fx;
import com.blackclovermod.util.ModAdvancements;
import com.blackclovermod.util.PlayerAnims;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * EXAMEN D'ENTRÉE DES CHEVALIERS-MAGES (au Colisée).
 * 1. Les 5 capitaines apparaissent dans leurs loges.  2. Épreuve : vaincre les adversaires invoqués (90 s).
 * 3. Délibération : chaque capitaine lève la main... ou non.  4. Le joueur choisit son ordre parmi ceux qui l'ont voulu.
 */
public final class ExamManager {
    private static final int T_FIGHT = 70, FIGHT_TIME = 1800, CHOICE_TIME = 600;

    private static final class Exam {
        UUID player; ServerLevel level; BlockPos pedestal; Vec3 center;
        int t, phase, fightEnd, evalStart, kills;
        final Map<KnightOrder, Vec3> seats = new EnumMap<>(KnightOrder.class);
        final Map<KnightOrder, CaptainEntity> captains = new EnumMap<>(KnightOrder.class);
        final List<Zombie> foes = new ArrayList<>();
        final Set<KnightOrder> raised = EnumSet.noneOf(KnightOrder.class);
        int score;
    }

    private static final Map<UUID, Exam> ACTIVE = new HashMap<>();

    public static boolean start(ServerLevel l, BlockPos pedestal, ServerPlayer p) {
        if (!MagicData.hasGrimoire(p)) { msg(p, "exam_no_grimoire", ChatFormatting.RED); return false; }
        if (MagicData.order(p) != null) { msg(p, "exam_already", ChatFormatting.YELLOW); return false; }
        if (l.getGameTime() < MagicData.examCooldown(p)) { msg(p, "exam_cooldown", ChatFormatting.YELLOW); return false; }
        for (Exam e : ACTIVE.values()) if (e.pedestal.equals(pedestal)) { msg(p, "exam_busy", ChatFormatting.YELLOW); return false; }
        if (ACTIVE.containsKey(p.getUUID())) return false;
        Exam ex = new Exam();
        ex.player = p.getUUID(); ex.level = l; ex.pedestal = pedestal.immutable(); ex.center = Vec3.atBottomCenterOf(pedestal);
        findSeats(l, ex);
        ACTIVE.put(p.getUUID(), ex);
        for (ServerPlayer o : l.getPlayers(pl -> pl.distanceToSqr(ex.center) < 64 * 64))
            Fx.title(o, Component.translatable("title.blackclover.exam").withStyle(ChatFormatting.GOLD),
                    Component.translatable("title.blackclover.exam_sub", p.getDisplayName()).withStyle(ChatFormatting.GRAY), 10, 60, 20);
        Cinematics.playAt(p, CinematicType.ALTAR, ex.center.add(0, 4, 0), 60);
        PlayerAnims.play(p, PlayerAnimState.AWAIT, 60);
        Fx.sound(l, ex.center, SoundEvents.RAID_HORN.value(), 3f, 1.2f);
        return true;
    }

    /** Les loges sont repérées par une magnétite ; la couleur de la laine voisine indique l'ordre. */
    private static void findSeats(ServerLevel l, Exam ex) {
        Map<Block, KnightOrder> wool = Map.of(Blocks.BLACK_WOOL, KnightOrder.ONYX_RAVENS, Blocks.BLUE_WOOL, KnightOrder.AZURE_STAGS,
                Blocks.RED_WOOL, KnightOrder.SCARLET_PHOENIX, Blocks.GREEN_WOOL, KnightOrder.JADE_SERPENTS, Blocks.WHITE_WOOL, KnightOrder.SILVER_OWLS);
        BlockPos c = ex.pedestal;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-22, -2, -22), c.offset(22, 8, 22))) {
            if (!l.getBlockState(pos).is(Blocks.LODESTONE)) continue;
            for (BlockPos n : BlockPos.betweenClosed(pos.offset(-3, 1, -3), pos.offset(3, 5, 3))) {
                KnightOrder o = wool.get(l.getBlockState(n).getBlock());
                if (o != null) { ex.seats.put(o, Vec3.atBottomCenterOf(pos.above(2))); break; }
            }
        }
        // pupitre posé ailleurs qu'au Colisée : les capitaines se placent en cercle
        int i = 0;
        for (KnightOrder o : KnightOrder.values()) {
            if (!ex.seats.containsKey(o)) {
                double a = i * Math.PI * 2 / 5;
                ex.seats.put(o, Fx.groundAt(l, ex.center.add(Math.cos(a) * 9, 3, Math.sin(a) * 9)));
            }
            i++;
        }
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) return;
        Iterator<Map.Entry<UUID, Exam>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Exam ex = it.next().getValue();
            ServerPlayer p = server.getPlayerList().getPlayer(ex.player);
            boolean done;
            try {
                done = p == null || !p.isAlive() || p.level() != ex.level || p.distanceToSqr(ex.center) > 48 * 48 || step(ex, p);
            } catch (Exception e) {
                BlackCloverMod.LOGGER.error("Erreur pendant l'examen", e);
                done = true;
            }
            if (done) { cleanup(ex); it.remove(); }
        }
    }

    private static boolean step(Exam ex, ServerPlayer p) {
        ServerLevel l = ex.level;
        int t = ex.t++;
        // 1) arrivée des capitaines, un par un
        KnightOrder[] all = KnightOrder.values();
        if (t >= 10 && t < 10 + all.length * 10 && (t - 10) % 10 == 0) {
            KnightOrder o = all[(t - 10) / 10];
            Vec3 s = ex.seats.get(o);
            CaptainEntity c = ModEntities.CAPTAIN.get().create(l);
            if (c != null) {
                c.setOrder(o);
                c.makeTemporary(FIGHT_TIME + CHOICE_TIME + 600);
                c.moveTo(s.x, s.y, s.z, (float) Math.toDegrees(Math.atan2(-(ex.center.x - s.x), ex.center.z - s.z)), 0f);
                l.addFreshEntity(c);
                ex.captains.put(o, c);
                Fx.circle(l, s.add(0, 0.05, 0), 1.6f, o.color, 30, 1);
                Fx.beam(l, s, 10f, 0.8f, o.color, 14, 0f, 0f);
                Fx.burst(l, ParticleTypes.POOF, s.add(0, 1, 0), 20, 0.3, 0.05);
                Fx.sound(l, s, SoundEvents.ILLUSIONER_MIRROR_MOVE, 2f, 1f);
                p.displayClientMessage(Component.translatable("msg.blackclover.exam_captain_arrives", c.getName().copy().withStyle(st -> st.withColor(o.color)), o.displayName()), true);
            }
        }
        // 2) l'épreuve
        if (t == T_FIGHT) {
            msg(p, "exam_fight", ChatFormatting.GOLD);
            Fx.title(p, Component.translatable("title.blackclover.exam_fight").withStyle(ChatFormatting.RED), Component.translatable("title.blackclover.exam_fight_sub"), 5, 40, 10);
            for (int i = 0; i < 6; i++) {
                double a = i * Math.PI / 3;
                Vec3 s = Fx.groundAt(l, ex.center.add(Math.cos(a) * 7, 3, Math.sin(a) * 7));
                Zombie z = EntityType.ZOMBIE.create(l);
                if (z == null) continue;
                z.moveTo(s.x, s.y, s.z, 0, 0);
                z.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.CHAINMAIL_HELMET));
                z.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.CHAINMAIL_CHESTPLATE));
                z.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
                for (EquipmentSlot sl : EquipmentSlot.values()) z.setDropChance(sl, 0f);
                var hp = z.getAttribute(Attributes.MAX_HEALTH);
                if (hp != null) hp.setBaseValue(30);
                z.setHealth(30);
                z.setCustomName(Component.translatable("entity.blackclover.exam_foe"));
                z.setPersistenceRequired();
                z.addTag("bc_exam");
                z.setTarget(p);
                l.addFreshEntity(z);
                ex.foes.add(z);
                Fx.circle(l, s.add(0, 0.05, 0), 1.2f, 0xFF5050, 20, 0);
            }
            ex.fightEnd = t + FIGHT_TIME;
        }
        if (t > T_FIGHT && ex.phase == 0) {
            ex.kills = (int) ex.foes.stream().filter(z -> !z.isAlive()).count();
            int left = ex.fightEnd - t;
            if (t % 20 == 0) p.displayClientMessage(Component.translatable("msg.blackclover.exam_progress", ex.kills, ex.foes.size(), left / 20), true);
            if (ex.kills >= ex.foes.size() || left <= 0) {
                ex.score = score(p, ex.kills, Math.max(0, left / 20));
                ex.phase = 1; ex.evalStart = t + 30;
                for (var z : ex.foes) if (z.isAlive()) { Fx.burst(l, ParticleTypes.POOF, z.position(), 15, 0.3, 0.05); z.discard(); }
                msg(p, "exam_deliberation", ChatFormatting.GOLD);
                PlayerAnims.play(p, PlayerAnimState.AWAIT, all.length * 30 + 60);
            }
        }
        // 3) délibération : les capitaines lèvent la main (ou pas)
        if (ex.phase == 1 && t >= ex.evalStart && (t - ex.evalStart) % 30 == 0) {
            int idx = (t - ex.evalStart) / 30;
            if (idx < all.length) {
                KnightOrder o = all[idx];
                CaptainEntity c = ex.captains.get(o);
                boolean yes = wants(o, p, ex.score);
                Component cn = c != null ? c.getName().copy().withStyle(st -> st.withColor(o.color)) : o.displayName();
                if (yes) {
                    ex.raised.add(o);
                    if (c != null) {
                        c.setRaised(true);
                        Fx.beam(l, c.position(), 6f, 0.6f, o.color, 40, 0f, 0f);
                        Fx.burst(l, ModParticles.LIGHT.get(), c.position().add(0, 2.4, 0), 25, 0.3, 0.05);
                    }
                    Fx.title(p, Component.literal(""), Component.translatable("msg.blackclover.exam_raise", cn).withStyle(ChatFormatting.GREEN), 3, 25, 5);
                    p.sendSystemMessage(Component.literal("").append(cn).append(" : ").append(Component.translatable("dialogue.blackclover." + o.id + ".accept")));
                    Fx.sound(l, ex.center, SoundEvents.PLAYER_LEVELUP, 2f, 1.2f);
                } else {
                    Fx.title(p, Component.literal(""), Component.translatable("msg.blackclover.exam_still", cn).withStyle(ChatFormatting.GRAY), 3, 25, 5);
                    Fx.sound(l, ex.center, SoundEvents.NOTE_BLOCK_BASS.value(), 1.5f, 0.6f);
                }
            } else if (idx == all.length) {
                if (ex.raised.isEmpty()) {
                    Fx.title(p, Component.translatable("title.blackclover.exam_failed").withStyle(ChatFormatting.RED), Component.translatable("title.blackclover.exam_failed_sub"), 10, 60, 20);
                    MagicData.setExamCooldown(p, l.getGameTime() + 24000);
                    return true;
                }
                ex.phase = 2; ex.fightEnd = t + CHOICE_TIME;
                msg(p, "exam_choose", ChatFormatting.AQUA);
                for (KnightOrder o : all) if (!ex.raised.contains(o) && ex.captains.get(o) != null) ex.captains.get(o).vanish();
            }
        }
        if (ex.phase == 2 && t > ex.fightEnd) {
            msg(p, "exam_timeout", ChatFormatting.GRAY);
            MagicData.setExamCooldown(p, l.getGameTime() + 2400);
            return true;
        }
        if (ex.phase == 3) return true;
        return false;
    }

    /** Clic sur un capitaine : si c'est le moment de choisir et qu'il a levé la main, on rejoint son ordre. */
    public static boolean onCaptainClicked(CaptainEntity c, ServerPlayer p) {
        Exam ex = ACTIVE.get(p.getUUID());
        if (ex == null || ex.phase != 2) return false;
        if (!ex.raised.contains(c.order())) { msg(p, "exam_not_raised", ChatFormatting.GRAY); return true; }
        join(p, c.order(), ex.level, c.position());
        ex.phase = 3;
        return true;
    }

    private static void join(ServerPlayer p, KnightOrder o, ServerLevel l, Vec3 at) {
        MagicData.setOrder(p, o);
        p.getInventory().add(new ItemStack(ModItems.HOODS.get(o).get()));
        p.getInventory().add(new ItemStack(ModItems.ROBES.get(o).get()));
        Fx.title(p, Component.translatable("title.blackclover.exam_joined", o.displayName()).withStyle(ChatFormatting.GOLD),
                Component.translatable("title.blackclover.exam_joined_sub"), 10, 70, 20);
        Fx.burst(l, ParticleTypes.FIREWORK, p.position().add(0, 1.5, 0), 120, 0.6, 0.3);
        Fx.circle(l, p.position().add(0, 0.05, 0), 3f, o.color, 60, 1);
        Fx.sound(l, p.position(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.5f, 1f);
        PlayerAnims.play(p, PlayerAnimState.TRIUMPH, 50);
        ModAdvancements.award(p, "joined_order");
    }

    /** Note de l'examen : combat + vitesse + niveau du grimoire + trèfle + boss vaincus. */
    private static int score(ServerPlayer p, int kills, int secondsLeft) {
        int s = kills * 8 + Math.min(30, secondsLeft / 3) + MagicData.level(p) * 4;
        int leaves = MagicData.leaves(p);
        s += leaves == 4 ? 12 : leaves == 5 ? 20 : 0;
        if (done(p, "guardian_slain")) s += 8;
        if (done(p, "elf_slain")) s += 10;
        if (done(p, "demon_slain")) s += 12;
        if (done(p, "creator_slain")) s += 20;
        return s;
    }

    private static boolean done(ServerPlayer p, String adv) {
        var a = p.server.getAdvancements().getAdvancement(BlackCloverMod.id(adv));
        return a != null && p.getAdvancements().getOrStartProgress(a).isDone();
    }

    /** Chaque capitaine a ses préférences (attributs favoris) et son niveau d'exigence. */
    private static boolean wants(KnightOrder o, ServerPlayer p, int score) {
        MagicElement el = MagicData.element(p);
        int need; Set<MagicElement> likes;
        switch (o) {
            case ONYX_RAVENS -> { need = 45; likes = EnumSet.of(MagicElement.ANTI, MagicElement.DARKNESS); }
            case AZURE_STAGS -> { need = 55; likes = EnumSet.of(MagicElement.WATER, MagicElement.WIND); }
            case SCARLET_PHOENIX -> { need = 55; likes = EnumSet.of(MagicElement.FIRE, MagicElement.LIGHTNING); }
            case JADE_SERPENTS -> { need = 50; likes = EnumSet.of(MagicElement.THORN, MagicElement.DARKNESS); }
            default -> { need = 65; likes = EnumSet.of(MagicElement.LIGHT, MagicElement.WATER); }
        }
        int s = score + (likes.contains(el) ? 15 : 0);
        if (o == KnightOrder.ONYX_RAVENS && MagicData.leaves(p) == 5) return true; // le capitaine des Corbeaux croit toujours aux parias
        return s >= need;
    }

    private static void cleanup(Exam ex) {
        for (CaptainEntity c : ex.captains.values()) if (c.isAlive()) c.vanish();
        for (Zombie z : ex.foes) if (z.isAlive()) z.discard();
    }

    public static void clear() {
        ACTIVE.values().forEach(ExamManager::cleanup);
        ACTIVE.clear();
    }

    private static void msg(ServerPlayer p, String key, ChatFormatting f) {
        p.sendSystemMessage(Component.translatable("msg.blackclover." + key).withStyle(f));
    }

    private ExamManager() {}
}
