package com.blackclovermod.network;

import com.blackclovermod.magic.PlayerAnimState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Serveur -> Clients : un joueur commence une pose animée. */
public record PlayerAnimPacket(int entityId, int type, int ticks) {
    public void encode(FriendlyByteBuf b) { b.writeVarInt(entityId); b.writeVarInt(type); b.writeVarInt(ticks); }
    public static PlayerAnimPacket decode(FriendlyByteBuf b) { return new PlayerAnimPacket(b.readVarInt(), b.readVarInt(), b.readVarInt()); }
    public void handle(Supplier<NetworkEvent.Context> ctx) { PlayerAnimState.play(entityId, type, ticks); }
}
