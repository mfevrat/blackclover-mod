package com.blackclovermod.network;

import com.blackclovermod.client.CinematicManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Serveur -> Client : démarre une cinématique (type -1 = changer seulement la cible). (x,y,z) = point d'intérêt. */
public record CinematicPacket(int type, int focusId, int duration, double x, double y, double z) {
    public CinematicPacket(int type, int focusId, int duration) { this(type, focusId, duration, 0, 0, 0); }

    public void encode(FriendlyByteBuf b) {
        b.writeVarInt(type + 1);
        b.writeVarInt(focusId + 1);
        b.writeVarInt(duration);
        b.writeDouble(x); b.writeDouble(y); b.writeDouble(z);
    }

    public static CinematicPacket decode(FriendlyByteBuf b) {
        return new CinematicPacket(b.readVarInt() - 1, b.readVarInt() - 1, b.readVarInt(), b.readDouble(), b.readDouble(), b.readDouble());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CinematicManager.receive(type, focusId, duration, x, y, z));
    }
}
