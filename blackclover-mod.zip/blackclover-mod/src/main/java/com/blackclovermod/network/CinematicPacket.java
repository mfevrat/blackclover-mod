package com.blackclovermod.network;

import com.blackclovermod.client.CinematicManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Serveur -> Client : démarre une cinématique (type -1 = changer seulement la cible). */
public record CinematicPacket(int type, int focusId, int duration) {
    public void encode(FriendlyByteBuf b) {
        b.writeVarInt(type + 1);
        b.writeVarInt(focusId + 1);
        b.writeVarInt(duration);
    }

    public static CinematicPacket decode(FriendlyByteBuf b) {
        return new CinematicPacket(b.readVarInt() - 1, b.readVarInt() - 1, b.readVarInt());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CinematicManager.receive(type, focusId, duration));
    }
}
