package com.blackclovermod.registry;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.loot.AddRandomItemModifier;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModLoot {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, BlackCloverMod.MODID);
    public static final RegistryObject<Codec<AddRandomItemModifier>> ADD_RANDOM_ITEM = MODIFIERS.register("add_random_item", AddRandomItemModifier.CODEC);

    private ModLoot() {}
}
