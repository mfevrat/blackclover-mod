package com.blackclovermod.registry;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.block.AltarBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, BlackCloverMod.MODID);

    private static BlockBehaviour.Properties altarProps(MapColor color) {
        // indestructible (comme la bedrock) pour que la structure reste intacte
        return BlockBehaviour.Properties.of().mapColor(color).strength(-1.0F, 3600000.0F).lightLevel(s -> 10)
                .noOcclusion().sound(SoundType.DEEPSLATE_BRICKS);
    }

    public static final RegistryObject<Block> GUARDIAN_ALTAR = BLOCKS.register("guardian_altar",
            () -> new AltarBlock(altarProps(MapColor.STONE), () -> ModEntities.DUNGEON_GUARDIAN.get(), 0x50E0FF));
    public static final RegistryObject<Block> ELF_ALTAR = BLOCKS.register("elf_altar",
            () -> new AltarBlock(altarProps(MapColor.QUARTZ), () -> ModEntities.ELF_KING.get(), 0xFFE27A));
    public static final RegistryObject<Block> DEMON_ALTAR = BLOCKS.register("demon_altar",
            () -> new AltarBlock(altarProps(MapColor.COLOR_BLACK), () -> ModEntities.ARCHDEMON.get(), 0xC01818));

    public static final RegistryObject<Block> ORIGIN_ALTAR = BLOCKS.register("origin_altar",
            () -> new AltarBlock(altarProps(MapColor.COLOR_PURPLE), () -> ModEntities.CREATOR.get(), 0xA050FF));
    public static final RegistryObject<Item> ORIGIN_ALTAR_ITEM = ModItems.ITEMS.register("origin_altar",
            () -> new BlockItem(ORIGIN_ALTAR.get(), new Item.Properties().rarity(Rarity.EPIC)));

    public static final RegistryObject<Block> EXAM_PEDESTAL = BLOCKS.register("exam_pedestal",
            () -> new com.blackclovermod.order.ExamPedestalBlock(altarProps(MapColor.GOLD)));
    public static final RegistryObject<Item> EXAM_PEDESTAL_ITEM = ModItems.ITEMS.register("exam_pedestal",
            () -> new BlockItem(EXAM_PEDESTAL.get(), new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> GUARDIAN_ALTAR_ITEM = ModItems.ITEMS.register("guardian_altar",
            () -> new BlockItem(GUARDIAN_ALTAR.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> ELF_ALTAR_ITEM = ModItems.ITEMS.register("elf_altar",
            () -> new BlockItem(ELF_ALTAR.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> DEMON_ALTAR_ITEM = ModItems.ITEMS.register("demon_altar",
            () -> new BlockItem(DEMON_ALTAR.get(), new Item.Properties().rarity(Rarity.EPIC)));

    private ModBlocks() {}
}
