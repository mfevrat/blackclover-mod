package com.blackclovermod.registry;

import com.blackclovermod.BlackCloverMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Particules dessinées pour le mod (une par élément + runes et éclats). */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, BlackCloverMod.MODID);

    private static RegistryObject<SimpleParticleType> reg(String n) { return PARTICLES.register(n, () -> new SimpleParticleType(true)); }

    public static final RegistryObject<SimpleParticleType> FIRE = reg("fire_wisp");
    public static final RegistryObject<SimpleParticleType> WATER = reg("water_drop");
    public static final RegistryObject<SimpleParticleType> WIND = reg("wind_streak");
    public static final RegistryObject<SimpleParticleType> LIGHTNING = reg("lightning_arc");
    public static final RegistryObject<SimpleParticleType> DARK = reg("dark_wisp");
    public static final RegistryObject<SimpleParticleType> LIGHT = reg("light_star");
    public static final RegistryObject<SimpleParticleType> THORN = reg("thorn_petal");
    public static final RegistryObject<SimpleParticleType> ANTI = reg("anti_ash");
    public static final RegistryObject<SimpleParticleType> RUNE = reg("rune");
    public static final RegistryObject<SimpleParticleType> EARTH = reg("earth_shard");

    private ModParticles() {}
}
