package com.blackclovermod.cinematic;

import com.blackclovermod.network.CinematicPacket;
import com.blackclovermod.network.ModNetwork;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/** Côté serveur : déclenche les cinématiques chez les joueurs. */
public final class Cinematics {

    public static void play(ServerPlayer p, CinematicType type, Entity focus, int duration) {
        ModNetwork.toPlayer(p, new CinematicPacket(type.ordinal(), focus == null ? -1 : focus.getId(), duration));
    }

    /** Cinématique avec un point d'intérêt (ex. centre de l'arène). */
    public static void playAt(ServerPlayer p, CinematicType type, net.minecraft.world.phys.Vec3 point, int duration) {
        ModNetwork.toPlayer(p, new CinematicPacket(type.ordinal(), p.getId(), duration, point.x, point.y, point.z));
    }

    /** Change la cible suivie par la caméra (ex. le grimoire qui vient de choisir le joueur). */
    public static void focus(ServerPlayer p, Entity focus) {
        ModNetwork.toPlayer(p, new CinematicPacket(-1, focus.getId(), 0));
    }

    /** Joue une cinématique pour tous les joueurs proches d'une entité. */
    public static void around(Entity center, CinematicType type, int duration, double radius) {
        if (!(center.level() instanceof ServerLevel l)) return;
        for (ServerPlayer p : l.getPlayers(pl -> pl.distanceToSqr(center) < radius * radius && !pl.isSpectator())) {
            play(p, type, center, duration);
        }
    }

    private Cinematics() {}
}
