package com.blackclovermod.cinematic;

/** Les différentes cinématiques du mod. */
public enum CinematicType {
    CEREMONY,      // cérémonie de la Tour des Grimoires
    BOSS_INTRO,    // apparition d'un boss
    BOSS_PHASE,    // transformation d'un boss
    BOSS_DEATH,    // mort d'un boss
    ULTIMATE,      // sort ultime (plan "par-dessus l'épaule")
    DEPARTURE,     // le joueur est aspiré vers la Tour des Grimoires
    ALTAR;         // rituel d'invocation sur un autel

    public static CinematicType byIndex(int i) {
        CinematicType[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, i))];
    }
}
