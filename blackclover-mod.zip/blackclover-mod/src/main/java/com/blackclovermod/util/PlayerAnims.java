package com.blackclovermod.util;

import com.blackclovermod.network.ModNetwork;
import com.blackclovermod.network.PlayerAnimPacket;
import net.minecraft.server.level.ServerPlayer;

/** Côté serveur : fait jouer une pose au personnage (visible par tous les joueurs autour). */
public final class PlayerAnims {
    public static void play(ServerPlayer p, int type, int ticks) {
        ModNetwork.toTrackingAndSelf(p, new PlayerAnimPacket(p.getId(), type, ticks));
    }

    private PlayerAnims() {}
}
