package com.blackclovermod.util;

import com.blackclovermod.BlackCloverMod;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.server.level.ServerPlayer;

/** Débloque un succès du mod depuis le code (succès à critère "impossible"). */
public final class ModAdvancements {

    public static void award(ServerPlayer p, String name) {
        Advancement adv = p.server.getAdvancements().getAdvancement(BlackCloverMod.id(name));
        if (adv == null) return;
        AdvancementProgress progress = p.getAdvancements().getOrStartProgress(adv);
        if (progress.isDone()) return;
        for (String criterion : progress.getRemainingCriteria()) p.getAdvancements().award(adv, criterion);
    }

    private ModAdvancements() {}
}
