package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.client.model.ArchdemonModel;
import com.blackclovermod.client.model.DungeonGuardianModel;
import com.blackclovermod.client.model.ElfKingModel;
import com.blackclovermod.entity.boss.ArchdemonEntity;
import com.blackclovermod.entity.boss.DungeonGuardianEntity;
import com.blackclovermod.entity.boss.ElfKingEntity;
import com.blackclovermod.item.GrimoireItem;
import com.blackclovermod.registry.ModEntities;
import com.blackclovermod.registry.ModItems;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = BlackCloverMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {

    private static ResourceLocation tex(String name) {
        return BlackCloverMod.id("textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        // le modèle 3D du grimoire change selon le nombre de feuilles du trèfle
        e.enqueueWork(() -> ItemProperties.register(ModItems.GRIMOIRE.get(), BlackCloverMod.id("leaves"),
                (stack, level, entity, seed) -> GrimoireItem.leaves(stack) / 10f));
    }

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(ModModelLayers.DUNGEON_GUARDIAN, DungeonGuardianModel::createBodyLayer);
        e.registerLayerDefinition(ModModelLayers.ELF_KING, ElfKingModel::createBodyLayer);
        e.registerLayerDefinition(ModModelLayers.ARCHDEMON, ArchdemonModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.MAGIC_PROJECTILE.get(), NoopRenderer::new);
        e.registerEntityRenderer(ModEntities.FLOATING_GRIMOIRE.get(), FloatingGrimoireRenderer::new);
        e.registerEntityRenderer(ModEntities.MAGIC_CIRCLE.get(), MagicCircleRenderer::new);
        e.registerEntityRenderer(ModEntities.SPELL_BEAM.get(), SpellBeamRenderer::new);
        e.registerEntityRenderer(ModEntities.DUNGEON_GUARDIAN.get(), ctx -> new ModelBossRenderer<DungeonGuardianEntity, DungeonGuardianModel<DungeonGuardianEntity>>(ctx,
                new DungeonGuardianModel<>(ctx.bakeLayer(ModModelLayers.DUNGEON_GUARDIAN)), tex("dungeon_guardian"), tex("dungeon_guardian_glow"), 1.0f));
        e.registerEntityRenderer(ModEntities.ELF_KING.get(), ctx -> new ModelBossRenderer<ElfKingEntity, ElfKingModel<ElfKingEntity>>(ctx,
                new ElfKingModel<>(ctx.bakeLayer(ModModelLayers.ELF_KING)), tex("elf_king"), tex("elf_king_glow"), 1.0f));
        e.registerEntityRenderer(ModEntities.ARCHDEMON.get(), ctx -> new ModelBossRenderer<ArchdemonEntity, ArchdemonModel<ArchdemonEntity>>(ctx,
                new ArchdemonModel<>(ctx.bakeLayer(ModModelLayers.ARCHDEMON)), tex("archdemon"), tex("archdemon_glow"), 0.85f));
    }

    /** Ajoute aux joueurs : le grimoire flottant et la cape d'ordre. */
    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers e) {
        for (String skin : e.getSkins()) {
            PlayerRenderer renderer = e.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new FloatingGrimoireLayer(renderer, e.getEntityModels()));
                renderer.addLayer(new OrderCapeLayer(renderer));
            }
        }
    }

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent e) {
        e.register(KeyBindings.CAST);
        e.register(KeyBindings.CYCLE);
        e.register(KeyBindings.SKIP);
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("mana_hud", ManaHud.HUD);
        e.registerAboveAll("cinematic", CinematicOverlay.HUD);
    }

    /** Colore la couverture du grimoire selon son attribut. */
    @SubscribeEvent
    public static void onItemColors(RegisterColorHandlersEvent.Item e) {
        e.register((stack, tintIndex) -> tintIndex == 0 ? GrimoireItem.color(stack) : -1, ModItems.GRIMOIRE.get());
    }

    private ClientModEvents() {}
}
