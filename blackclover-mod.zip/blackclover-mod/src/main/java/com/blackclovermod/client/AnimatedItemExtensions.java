package com.blackclovermod.client;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Branche le rendu animé sur les objets du mod. */
public final class AnimatedItemExtensions implements IClientItemExtensions {
    public static final AnimatedItemExtensions INSTANCE = new AnimatedItemExtensions();

    @Override
    public BlockEntityWithoutLevelRenderer getCustomRenderer() {
        return ModItemRenderer.get();
    }

    private AnimatedItemExtensions() {}
}
