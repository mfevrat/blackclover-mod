package com.blackclovermod.client;

import com.blackclovermod.entity.RockShardEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;

public class RockShardRenderer extends EntityRenderer<RockShardEntity> {
    public RockShardRenderer(EntityRendererProvider.Context ctx) { super(ctx); shadowRadius = 0.3f; }

    @Override
    public void render(RockShardEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float t = e.tickCount + pt;
        float s = e.getScale();
        ps.pushPose();
        ps.translate(0, 0.4 * s, 0);
        ps.mulPose(Axis.YP.rotationDegrees(t * 4f + e.getId() * 37f));
        ps.mulPose(Axis.XP.rotationDegrees(t * 2.5f + e.getId() * 13f));
        ps.scale(s, s, s);
        ps.translate(-0.5, -0.5, -0.5);
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(e.getBlock(), ps, buf, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(RockShardEntity e) { return TextureAtlas.LOCATION_BLOCKS; }
}
