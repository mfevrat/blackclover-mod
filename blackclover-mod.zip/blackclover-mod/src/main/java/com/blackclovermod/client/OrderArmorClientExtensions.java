package com.blackclovermod.client;

import com.blackclovermod.client.model.OrderArmorModel;
import com.blackclovermod.item.OrderArmorItem;
import com.blackclovermod.magic.KnightOrder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.EnumMap;
import java.util.Map;

/** Remplace le modèle d'armure "plat" de Minecraft par le modèle 3D de l'ordre. */
public final class OrderArmorClientExtensions implements IClientItemExtensions {
    private static final Map<KnightOrder, OrderArmorModel> MODELS = new EnumMap<>(KnightOrder.class);
    public static final OrderArmorClientExtensions INSTANCE = new OrderArmorClientExtensions();

    private OrderArmorClientExtensions() {}

    @Override
    public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
        if (!(stack.getItem() instanceof OrderArmorItem armor)) return original;
        return MODELS.computeIfAbsent(armor.order, o -> new OrderArmorModel(
                Minecraft.getInstance().getEntityModels().bakeLayer(ModModelLayers.armor(o))));
    }

    /** Appelé au rechargement des ressources (F3+T) pour reconstruire les modèles. */
    public static void clear() {
        MODELS.clear();
    }
}
