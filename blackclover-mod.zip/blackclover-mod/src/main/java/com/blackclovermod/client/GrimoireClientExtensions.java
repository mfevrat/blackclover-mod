package com.blackclovermod.client;

import com.blackclovermod.magic.ClientFxState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/**
 * Pose des bras quand on tient le grimoire :
 *  - normalement : le grimoire est tenu ouvert devant soi, comme pour le lire
 *  - en lançant un sort : le bras se tend vers l'avant, dans la direction du regard
 */
public final class GrimoireClientExtensions implements IClientItemExtensions {
    public static final GrimoireClientExtensions INSTANCE = new GrimoireClientExtensions();

    private static final HumanoidModel.ArmPose READING = HumanoidModel.ArmPose.create("BLACKCLOVER_GRIMOIRE", false,
            (model, entity, arm) -> {
                ModelPart a = arm == HumanoidArm.RIGHT ? model.rightArm : model.leftArm;
                boolean casting = ClientFxState.get(entity.getId()) != null;
                float side = arm == HumanoidArm.RIGHT ? -1f : 1f;
                if (casting) {
                    a.xRot = -1.55f + model.head.xRot;
                    a.yRot = model.head.yRot + side * 0.15f;
                    a.zRot = 0f;
                } else {
                    a.xRot = -0.95f + model.head.xRot * 0.3f;
                    a.yRot = side * -0.45f;
                    a.zRot = 0f;
                }
            });

    @Override
    public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
        return ModItemRenderer.get();
    }

    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return READING;
    }

    private GrimoireClientExtensions() {}
}
