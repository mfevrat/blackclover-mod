package com.blackclovermod.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.world.entity.LivingEntity;

/**
 * Armures d'ordre en 3D (capuche avec visière et drapé, épaulettes, ceinture, pans de robe, accessoire unique).
 * Généré par gen/armor_v3.py.
 */
public class OrderArmorModel extends HumanoidModel<LivingEntity> {

    public OrderArmorModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createOnyxRavens() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hat = root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F, new CubeDeformation(1.01F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 0).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(-5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(72, 0).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_brim = p_head.addOrReplaceChild("hood_brim", CubeListBuilder.create().texOffs(88, 0).addBox(-4.5F, 0F, -1.2F, 9F, 2F, 2F), PartPose.offsetAndRotation(0.000F, -8.600F, -4.600F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_hood_drape = p_head.addOrReplaceChild("hood_drape", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, 0F, -1F, 9F, 5F, 2F), PartPose.offsetAndRotation(0.000F, -1.000F, 4.600F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_r = p_head.addOrReplaceChild("hood_side_r", CubeListBuilder.create().texOffs(22, 16).addBox(-0.8F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(-4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_l = p_head.addOrReplaceChild("hood_side_l", CubeListBuilder.create().texOffs(28, 16).addBox(-0.2F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_mantle = p_body.addOrReplaceChild("mantle", CubeListBuilder.create().texOffs(34, 16).addBox(-5.5F, -1F, -3.2F, 11F, 3F, 6F), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_collar = p_body.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(68, 16).addBox(-4.5F, -3F, 0F, 9F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -0.500F, 2.600F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_belt = p_body.addOrReplaceChild("belt", CubeListBuilder.create().texOffs(88, 16).addBox(-4.5F, 0F, -2.7F, 9F, 2F, 5F).texOffs(116, 16).addBox(-1F, -0.2F, -3.3F, 2F, 2F, 1F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_emblem = p_body.addOrReplaceChild("emblem", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, -1.5F, -0.5F, 3F, 3F, 1F), PartPose.offsetAndRotation(0.000F, 3.500F, -3.200F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_sash = p_body.addOrReplaceChild("sash", CubeListBuilder.create().texOffs(8, 25).addBox(-1F, 0F, 0F, 2F, 13F, 0F), PartPose.offsetAndRotation(2.500F, 0.500F, -3.050F, 0.0000F, 0.0000F, -0.4887F));
        PartDefinition p_tail_front = p_body.addOrReplaceChild("tail_front", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, 0F, -0.5F, 7F, 7F, 1F).texOffs(28, 25).addBox(-3.5F, 6F, -0.6F, 7F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, -2.600F, -0.1047F, 0.0000F, 0.0000F));
        PartDefinition p_tail_back = p_body.addOrReplaceChild("tail_back", CubeListBuilder.create().texOffs(44, 25).addBox(-4F, 0F, -0.5F, 8F, 9F, 1F).texOffs(62, 25).addBox(-4F, 8F, -0.6F, 8F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, 2.600F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_tail_r = p_body.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(80, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(-4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.1396F));
        PartDefinition p_tail_l = p_body.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(90, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, -0.1396F));
        PartDefinition p_pauldron_r = p_right_arm.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(100, 25).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(0, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(-1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, 0.3142F));
        PartDefinition p_cuff_r = p_right_arm.addOrReplaceChild("cuff_r", CubeListBuilder.create().texOffs(20, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(-1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_pauldron_l = p_left_arm.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(40, 38).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(64, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, -0.3142F));
        PartDefinition p_cuff_l = p_left_arm.addOrReplaceChild("cuff_l", CubeListBuilder.create().texOffs(84, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_beak = p_head.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(104, 38).addBox(-1F, 0F, -2F, 2F, 1F, 2F), PartPose.offsetAndRotation(0.000F, -8.400F, -5.400F, 0.4363F, 0.0000F, 0.0000F));
        PartDefinition p_plume_0 = p_head.addOrReplaceChild("plume_0", CubeListBuilder.create().texOffs(112, 38).addBox(-0.5F, -7F, 0F, 1F, 7F, 0F), PartPose.offsetAndRotation(-1.500F, -9.000F, 1.000F, -0.6109F, 0.0000F, -0.2618F));
        PartDefinition p_plume_1 = p_head.addOrReplaceChild("plume_1", CubeListBuilder.create().texOffs(114, 38).addBox(-0.5F, -7F, 0F, 1F, 7F, 0F), PartPose.offsetAndRotation(0.000F, -9.000F, 1.000F, -0.6109F, 0.0000F, 0.0000F));
        PartDefinition p_plume_2 = p_head.addOrReplaceChild("plume_2", CubeListBuilder.create().texOffs(116, 38).addBox(-0.5F, -7F, 0F, 1F, 7F, 0F), PartPose.offsetAndRotation(1.500F, -9.000F, 1.000F, -0.6109F, 0.0000F, 0.2618F));
        PartDefinition p_feather_mantle = p_body.addOrReplaceChild("feather_mantle", CubeListBuilder.create().texOffs(0, 47).addBox(-5F, -1F, 0F, 10F, 7F, 0F), PartPose.offsetAndRotation(0.000F, 0.000F, 3.000F, 0.2618F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition createAzureStags() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hat = root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F, new CubeDeformation(1.01F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 0).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(-5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(72, 0).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_brim = p_head.addOrReplaceChild("hood_brim", CubeListBuilder.create().texOffs(88, 0).addBox(-4.5F, 0F, -1.2F, 9F, 2F, 2F), PartPose.offsetAndRotation(0.000F, -8.600F, -4.600F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_hood_drape = p_head.addOrReplaceChild("hood_drape", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, 0F, -1F, 9F, 5F, 2F), PartPose.offsetAndRotation(0.000F, -1.000F, 4.600F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_r = p_head.addOrReplaceChild("hood_side_r", CubeListBuilder.create().texOffs(22, 16).addBox(-0.8F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(-4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_l = p_head.addOrReplaceChild("hood_side_l", CubeListBuilder.create().texOffs(28, 16).addBox(-0.2F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_mantle = p_body.addOrReplaceChild("mantle", CubeListBuilder.create().texOffs(34, 16).addBox(-5.5F, -1F, -3.2F, 11F, 3F, 6F), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_collar = p_body.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(68, 16).addBox(-4.5F, -3F, 0F, 9F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -0.500F, 2.600F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_belt = p_body.addOrReplaceChild("belt", CubeListBuilder.create().texOffs(88, 16).addBox(-4.5F, 0F, -2.7F, 9F, 2F, 5F).texOffs(116, 16).addBox(-1F, -0.2F, -3.3F, 2F, 2F, 1F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_emblem = p_body.addOrReplaceChild("emblem", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, -1.5F, -0.5F, 3F, 3F, 1F), PartPose.offsetAndRotation(0.000F, 3.500F, -3.200F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_sash = p_body.addOrReplaceChild("sash", CubeListBuilder.create().texOffs(8, 25).addBox(-1F, 0F, 0F, 2F, 13F, 0F), PartPose.offsetAndRotation(2.500F, 0.500F, -3.050F, 0.0000F, 0.0000F, -0.4887F));
        PartDefinition p_tail_front = p_body.addOrReplaceChild("tail_front", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, 0F, -0.5F, 7F, 7F, 1F).texOffs(28, 25).addBox(-3.5F, 6F, -0.6F, 7F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, -2.600F, -0.1047F, 0.0000F, 0.0000F));
        PartDefinition p_tail_back = p_body.addOrReplaceChild("tail_back", CubeListBuilder.create().texOffs(44, 25).addBox(-4F, 0F, -0.5F, 8F, 9F, 1F).texOffs(62, 25).addBox(-4F, 8F, -0.6F, 8F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, 2.600F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_tail_r = p_body.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(80, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(-4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.1396F));
        PartDefinition p_tail_l = p_body.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(90, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, -0.1396F));
        PartDefinition p_pauldron_r = p_right_arm.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(100, 25).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(0, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(-1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, 0.3142F));
        PartDefinition p_cuff_r = p_right_arm.addOrReplaceChild("cuff_r", CubeListBuilder.create().texOffs(20, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(-1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_pauldron_l = p_left_arm.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(40, 38).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(64, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, -0.3142F));
        PartDefinition p_cuff_l = p_left_arm.addOrReplaceChild("cuff_l", CubeListBuilder.create().texOffs(84, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_antler_r_0 = p_head.addOrReplaceChild("antler_r_0", CubeListBuilder.create().texOffs(104, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(-3.000F, -8.500F, -1.000F, -0.1745F, 0.0000F, -0.6981F));
        PartDefinition p_antler_r_1 = p_antler_r_0.addOrReplaceChild("antler_r_1", CubeListBuilder.create().texOffs(108, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -3.000F, 0.000F, -0.3491F, 0.0000F, 0.4363F));
        PartDefinition p_antler_r_2 = p_antler_r_1.addOrReplaceChild("antler_r_2", CubeListBuilder.create().texOffs(112, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -3.000F, 0.000F, -0.4363F, 0.0000F, -0.1745F));
        PartDefinition p_tine_r0 = p_antler_r_1.addOrReplaceChild("tine_r0", CubeListBuilder.create().texOffs(116, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -2.000F, 0.000F, -0.6981F, 0.0000F, -0.7854F));
        PartDefinition p_tine_r1 = p_antler_r_2.addOrReplaceChild("tine_r1", CubeListBuilder.create().texOffs(120, 38).addBox(-0.5F, -2F, -0.5F, 1F, 2F, 1F), PartPose.offsetAndRotation(0.000F, -2.000F, 0.000F, -0.5236F, 0.0000F, 0.6981F));
        PartDefinition p_antler_l_0 = p_head.addOrReplaceChild("antler_l_0", CubeListBuilder.create().texOffs(124, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(3.000F, -8.500F, -1.000F, -0.1745F, 0.0000F, 0.6981F));
        PartDefinition p_antler_l_1 = p_antler_l_0.addOrReplaceChild("antler_l_1", CubeListBuilder.create().texOffs(0, 47).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -3.000F, 0.000F, -0.3491F, 0.0000F, -0.4363F));
        PartDefinition p_antler_l_2 = p_antler_l_1.addOrReplaceChild("antler_l_2", CubeListBuilder.create().texOffs(4, 47).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -3.000F, 0.000F, -0.4363F, 0.0000F, 0.1745F));
        PartDefinition p_tine_l0 = p_antler_l_1.addOrReplaceChild("tine_l0", CubeListBuilder.create().texOffs(8, 47).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -2.000F, 0.000F, -0.6981F, 0.0000F, 0.7854F));
        PartDefinition p_tine_l1 = p_antler_l_2.addOrReplaceChild("tine_l1", CubeListBuilder.create().texOffs(12, 47).addBox(-0.5F, -2F, -0.5F, 1F, 2F, 1F), PartPose.offsetAndRotation(0.000F, -2.000F, 0.000F, -0.5236F, 0.0000F, -0.6981F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition createScarletPhoenix() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hat = root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F, new CubeDeformation(1.01F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 0).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(-5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(72, 0).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_brim = p_head.addOrReplaceChild("hood_brim", CubeListBuilder.create().texOffs(88, 0).addBox(-4.5F, 0F, -1.2F, 9F, 2F, 2F), PartPose.offsetAndRotation(0.000F, -8.600F, -4.600F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_hood_drape = p_head.addOrReplaceChild("hood_drape", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, 0F, -1F, 9F, 5F, 2F), PartPose.offsetAndRotation(0.000F, -1.000F, 4.600F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_r = p_head.addOrReplaceChild("hood_side_r", CubeListBuilder.create().texOffs(22, 16).addBox(-0.8F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(-4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_l = p_head.addOrReplaceChild("hood_side_l", CubeListBuilder.create().texOffs(28, 16).addBox(-0.2F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_mantle = p_body.addOrReplaceChild("mantle", CubeListBuilder.create().texOffs(34, 16).addBox(-5.5F, -1F, -3.2F, 11F, 3F, 6F), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_collar = p_body.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(68, 16).addBox(-4.5F, -3F, 0F, 9F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -0.500F, 2.600F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_belt = p_body.addOrReplaceChild("belt", CubeListBuilder.create().texOffs(88, 16).addBox(-4.5F, 0F, -2.7F, 9F, 2F, 5F).texOffs(116, 16).addBox(-1F, -0.2F, -3.3F, 2F, 2F, 1F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_emblem = p_body.addOrReplaceChild("emblem", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, -1.5F, -0.5F, 3F, 3F, 1F), PartPose.offsetAndRotation(0.000F, 3.500F, -3.200F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_sash = p_body.addOrReplaceChild("sash", CubeListBuilder.create().texOffs(8, 25).addBox(-1F, 0F, 0F, 2F, 13F, 0F), PartPose.offsetAndRotation(2.500F, 0.500F, -3.050F, 0.0000F, 0.0000F, -0.4887F));
        PartDefinition p_tail_front = p_body.addOrReplaceChild("tail_front", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, 0F, -0.5F, 7F, 7F, 1F).texOffs(28, 25).addBox(-3.5F, 6F, -0.6F, 7F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, -2.600F, -0.1047F, 0.0000F, 0.0000F));
        PartDefinition p_tail_back = p_body.addOrReplaceChild("tail_back", CubeListBuilder.create().texOffs(44, 25).addBox(-4F, 0F, -0.5F, 8F, 9F, 1F).texOffs(62, 25).addBox(-4F, 8F, -0.6F, 8F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, 2.600F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_tail_r = p_body.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(80, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(-4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.1396F));
        PartDefinition p_tail_l = p_body.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(90, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, -0.1396F));
        PartDefinition p_pauldron_r = p_right_arm.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(100, 25).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(0, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(-1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, 0.3142F));
        PartDefinition p_cuff_r = p_right_arm.addOrReplaceChild("cuff_r", CubeListBuilder.create().texOffs(20, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(-1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_pauldron_l = p_left_arm.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(40, 38).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(64, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, -0.3142F));
        PartDefinition p_cuff_l = p_left_arm.addOrReplaceChild("cuff_l", CubeListBuilder.create().texOffs(84, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_crest_0 = p_head.addOrReplaceChild("crest_0", CubeListBuilder.create().texOffs(104, 38).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -9.000F, -3.000F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_crest_1 = p_head.addOrReplaceChild("crest_1", CubeListBuilder.create().texOffs(108, 38).addBox(-0.5F, -5F, -0.5F, 1F, 5F, 1F), PartPose.offsetAndRotation(0.000F, -9.000F, -1.500F, -0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_crest_2 = p_head.addOrReplaceChild("crest_2", CubeListBuilder.create().texOffs(112, 38).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F), PartPose.offsetAndRotation(0.000F, -9.000F, 0.000F, -0.0698F, 0.0000F, 0.0000F));
        PartDefinition p_crest_3 = p_head.addOrReplaceChild("crest_3", CubeListBuilder.create().texOffs(116, 38).addBox(-0.5F, -5F, -0.5F, 1F, 5F, 1F), PartPose.offsetAndRotation(0.000F, -9.000F, 1.500F, 0.0698F, 0.0000F, 0.0000F));
        PartDefinition p_crest_4 = p_head.addOrReplaceChild("crest_4", CubeListBuilder.create().texOffs(120, 38).addBox(-0.5F, -4F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, -9.000F, 3.000F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_plume_0 = p_head.addOrReplaceChild("plume_0", CubeListBuilder.create().texOffs(0, 47).addBox(-1.5F, 0F, 0.0F, 3F, 4F, 0F), PartPose.offsetAndRotation(0.000F, -5.000F, 4.500F, 0.6981F, 0.0000F, 0.0000F));
        PartDefinition p_plume_1 = p_plume_0.addOrReplaceChild("plume_1", CubeListBuilder.create().texOffs(6, 47).addBox(-1.5F, 0F, 0.0F, 3F, 4F, 0F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_plume_2 = p_plume_1.addOrReplaceChild("plume_2", CubeListBuilder.create().texOffs(12, 47).addBox(-1.0F, 0F, 0.0F, 2F, 4F, 0F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.2618F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition createJadeSerpents() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hat = root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F, new CubeDeformation(1.01F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 0).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(-5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(72, 0).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_brim = p_head.addOrReplaceChild("hood_brim", CubeListBuilder.create().texOffs(88, 0).addBox(-4.5F, 0F, -1.2F, 9F, 2F, 2F), PartPose.offsetAndRotation(0.000F, -8.600F, -4.600F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_hood_drape = p_head.addOrReplaceChild("hood_drape", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, 0F, -1F, 9F, 5F, 2F), PartPose.offsetAndRotation(0.000F, -1.000F, 4.600F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_r = p_head.addOrReplaceChild("hood_side_r", CubeListBuilder.create().texOffs(22, 16).addBox(-0.8F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(-4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_l = p_head.addOrReplaceChild("hood_side_l", CubeListBuilder.create().texOffs(28, 16).addBox(-0.2F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_mantle = p_body.addOrReplaceChild("mantle", CubeListBuilder.create().texOffs(34, 16).addBox(-5.5F, -1F, -3.2F, 11F, 3F, 6F), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_collar = p_body.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(68, 16).addBox(-4.5F, -3F, 0F, 9F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -0.500F, 2.600F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_belt = p_body.addOrReplaceChild("belt", CubeListBuilder.create().texOffs(88, 16).addBox(-4.5F, 0F, -2.7F, 9F, 2F, 5F).texOffs(116, 16).addBox(-1F, -0.2F, -3.3F, 2F, 2F, 1F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_emblem = p_body.addOrReplaceChild("emblem", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, -1.5F, -0.5F, 3F, 3F, 1F), PartPose.offsetAndRotation(0.000F, 3.500F, -3.200F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_sash = p_body.addOrReplaceChild("sash", CubeListBuilder.create().texOffs(8, 25).addBox(-1F, 0F, 0F, 2F, 13F, 0F), PartPose.offsetAndRotation(2.500F, 0.500F, -3.050F, 0.0000F, 0.0000F, -0.4887F));
        PartDefinition p_tail_front = p_body.addOrReplaceChild("tail_front", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, 0F, -0.5F, 7F, 7F, 1F).texOffs(28, 25).addBox(-3.5F, 6F, -0.6F, 7F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, -2.600F, -0.1047F, 0.0000F, 0.0000F));
        PartDefinition p_tail_back = p_body.addOrReplaceChild("tail_back", CubeListBuilder.create().texOffs(44, 25).addBox(-4F, 0F, -0.5F, 8F, 9F, 1F).texOffs(62, 25).addBox(-4F, 8F, -0.6F, 8F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, 2.600F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_tail_r = p_body.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(80, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(-4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.1396F));
        PartDefinition p_tail_l = p_body.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(90, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, -0.1396F));
        PartDefinition p_pauldron_r = p_right_arm.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(100, 25).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(0, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(-1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, 0.3142F));
        PartDefinition p_cuff_r = p_right_arm.addOrReplaceChild("cuff_r", CubeListBuilder.create().texOffs(20, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(-1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_pauldron_l = p_left_arm.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(40, 38).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(64, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, -0.3142F));
        PartDefinition p_cuff_l = p_left_arm.addOrReplaceChild("cuff_l", CubeListBuilder.create().texOffs(84, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_cobra_r = p_head.addOrReplaceChild("cobra_r", CubeListBuilder.create().texOffs(104, 38).addBox(-4F, 0F, -0.5F, 4F, 8F, 1F).texOffs(114, 38).addBox(-4F, 0F, -0.6F, 4F, 1F, 1F), PartPose.offsetAndRotation(-4.600F, -7.000F, 1.000F, 0.0000F, 0.4363F, -0.2618F));
        PartDefinition p_fang_r = p_hood_brim.addOrReplaceChild("fang_r", CubeListBuilder.create().texOffs(124, 38).addBox(-0.5F, 0F, -0.5F, 1F, 2F, 1F), PartPose.offsetAndRotation(-1.500F, 2.000F, -1.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_cobra_l = p_head.addOrReplaceChild("cobra_l", CubeListBuilder.create().texOffs(0, 47).addBox(0F, 0F, -0.5F, 4F, 8F, 1F).texOffs(10, 47).addBox(0F, 0F, -0.6F, 4F, 1F, 1F), PartPose.offsetAndRotation(4.600F, -7.000F, 1.000F, 0.0000F, -0.4363F, 0.2618F));
        PartDefinition p_fang_l = p_hood_brim.addOrReplaceChild("fang_l", CubeListBuilder.create().texOffs(20, 47).addBox(-0.5F, 0F, -0.5F, 1F, 2F, 1F), PartPose.offsetAndRotation(1.500F, 2.000F, -1.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_scale_crest = p_head.addOrReplaceChild("scale_crest", CubeListBuilder.create().texOffs(24, 47).addBox(-1F, -1F, 0F, 2F, 1F, 7F), PartPose.offsetAndRotation(0.000F, -9.000F, -2.000F, -0.1745F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    public static LayerDefinition createSilverOwls() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hat = root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F, new CubeDeformation(1.01F)), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_arm = root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 0).addBox(-3F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(-5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_arm = root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(72, 0).addBox(-1F, -2F, -2F, 4F, 12F, 4F, new CubeDeformation(1.0F)), PartPose.offsetAndRotation(5.000F, 2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.900F, 12.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_brim = p_head.addOrReplaceChild("hood_brim", CubeListBuilder.create().texOffs(88, 0).addBox(-4.5F, 0F, -1.2F, 9F, 2F, 2F), PartPose.offsetAndRotation(0.000F, -8.600F, -4.600F, 0.2094F, 0.0000F, 0.0000F));
        PartDefinition p_hood_drape = p_head.addOrReplaceChild("hood_drape", CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, 0F, -1F, 9F, 5F, 2F), PartPose.offsetAndRotation(0.000F, -1.000F, 4.600F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_r = p_head.addOrReplaceChild("hood_side_r", CubeListBuilder.create().texOffs(22, 16).addBox(-0.8F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(-4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_hood_side_l = p_head.addOrReplaceChild("hood_side_l", CubeListBuilder.create().texOffs(28, 16).addBox(-0.2F, 0F, 0F, 1F, 7F, 2F), PartPose.offsetAndRotation(4.800F, -6.000F, -3.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_mantle = p_body.addOrReplaceChild("mantle", CubeListBuilder.create().texOffs(34, 16).addBox(-5.5F, -1F, -3.2F, 11F, 3F, 6F), PartPose.offsetAndRotation(0.000F, 0.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_collar = p_body.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(68, 16).addBox(-4.5F, -3F, 0F, 9F, 3F, 1F), PartPose.offsetAndRotation(0.000F, -0.500F, 2.600F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition p_belt = p_body.addOrReplaceChild("belt", CubeListBuilder.create().texOffs(88, 16).addBox(-4.5F, 0F, -2.7F, 9F, 2F, 5F).texOffs(116, 16).addBox(-1F, -0.2F, -3.3F, 2F, 2F, 1F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_emblem = p_body.addOrReplaceChild("emblem", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, -1.5F, -0.5F, 3F, 3F, 1F), PartPose.offsetAndRotation(0.000F, 3.500F, -3.200F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_sash = p_body.addOrReplaceChild("sash", CubeListBuilder.create().texOffs(8, 25).addBox(-1F, 0F, 0F, 2F, 13F, 0F), PartPose.offsetAndRotation(2.500F, 0.500F, -3.050F, 0.0000F, 0.0000F, -0.4887F));
        PartDefinition p_tail_front = p_body.addOrReplaceChild("tail_front", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, 0F, -0.5F, 7F, 7F, 1F).texOffs(28, 25).addBox(-3.5F, 6F, -0.6F, 7F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, -2.600F, -0.1047F, 0.0000F, 0.0000F));
        PartDefinition p_tail_back = p_body.addOrReplaceChild("tail_back", CubeListBuilder.create().texOffs(44, 25).addBox(-4F, 0F, -0.5F, 8F, 9F, 1F).texOffs(62, 25).addBox(-4F, 8F, -0.6F, 8F, 1F, 1F), PartPose.offsetAndRotation(0.000F, 11.000F, 2.600F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_tail_r = p_body.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(80, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(-4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.1396F));
        PartDefinition p_tail_l = p_body.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(90, 25).addBox(-0.5F, 0F, -2F, 1F, 6F, 4F), PartPose.offsetAndRotation(4.400F, 11.000F, 0.000F, 0.0000F, 0.0000F, -0.1396F));
        PartDefinition p_pauldron_r = p_right_arm.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(100, 25).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(0, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(-1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, 0.3142F));
        PartDefinition p_cuff_r = p_right_arm.addOrReplaceChild("cuff_r", CubeListBuilder.create().texOffs(20, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(-1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_pauldron_l = p_left_arm.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(40, 38).addBox(-3F, -1F, -3F, 6F, 3F, 6F).texOffs(64, 38).addBox(-2.5F, 1.5F, -2.8F, 5F, 1F, 5F), PartPose.offsetAndRotation(1.000F, -2.600F, 0.000F, 0.0000F, 0.0000F, -0.3142F));
        PartDefinition p_cuff_l = p_left_arm.addOrReplaceChild("cuff_l", CubeListBuilder.create().texOffs(84, 38).addBox(-2.6F, 0F, -2.6F, 5F, 2F, 5F), PartPose.offsetAndRotation(1.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_tuft_r = p_head.addOrReplaceChild("tuft_r", CubeListBuilder.create().texOffs(104, 38).addBox(-1F, -4F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(-3.000F, -9.000F, -1.000F, -0.2618F, 0.0000F, -0.5236F));
        PartDefinition p_tuft_l = p_head.addOrReplaceChild("tuft_l", CubeListBuilder.create().texOffs(110, 38).addBox(-1F, -4F, -0.5F, 2F, 4F, 1F), PartPose.offsetAndRotation(3.000F, -9.000F, -1.000F, -0.2618F, 0.0000F, 0.5236F));
        PartDefinition p_owl_mantle = p_body.addOrReplaceChild("owl_mantle", CubeListBuilder.create().texOffs(0, 47).addBox(-5F, 0F, 0F, 10F, 4F, 0F), PartPose.offsetAndRotation(0.000F, -0.500F, -3.400F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_owl_mantle_back = p_body.addOrReplaceChild("owl_mantle_back", CubeListBuilder.create().texOffs(20, 47).addBox(-5F, 0F, 0F, 10F, 6F, 0F), PartPose.offsetAndRotation(0.000F, -0.500F, 3.400F, 0.0000F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }
}
