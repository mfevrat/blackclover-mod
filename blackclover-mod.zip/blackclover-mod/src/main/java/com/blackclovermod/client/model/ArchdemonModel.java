package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL généré automatiquement (voir gen/bossmodels.py). Les animations sont dans setupAnim. */
public class ArchdemonModel<T extends MagicBossEntity> extends HierarchicalModel<T> {
    private final ModelPart root;
    public final ModelPart body;
    public final ModelPart head;
    public final ModelPart right_horn;
    public final ModelPart right_horn2;
    public final ModelPart right_horn3;
    public final ModelPart left_horn;
    public final ModelPart left_horn2;
    public final ModelPart left_horn3;
    public final ModelPart right_arm;
    public final ModelPart right_forearm;
    public final ModelPart left_arm;
    public final ModelPart left_forearm;
    public final ModelPart right_wing;
    public final ModelPart right_wing_tip;
    public final ModelPart left_wing;
    public final ModelPart left_wing_tip;
    public final ModelPart tail;
    public final ModelPart tail2;
    public final ModelPart tail3;
    public final ModelPart right_leg;
    public final ModelPart right_shin;
    public final ModelPart left_leg;
    public final ModelPart left_shin;

    public ArchdemonModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.right_horn = this.head.getChild("right_horn");
        this.right_horn2 = this.right_horn.getChild("right_horn2");
        this.right_horn3 = this.right_horn2.getChild("right_horn3");
        this.left_horn = this.head.getChild("left_horn");
        this.left_horn2 = this.left_horn.getChild("left_horn2");
        this.left_horn3 = this.left_horn2.getChild("left_horn3");
        this.right_arm = this.body.getChild("right_arm");
        this.right_forearm = this.right_arm.getChild("right_forearm");
        this.left_arm = this.body.getChild("left_arm");
        this.left_forearm = this.left_arm.getChild("left_forearm");
        this.right_wing = this.body.getChild("right_wing");
        this.right_wing_tip = this.right_wing.getChild("right_wing_tip");
        this.left_wing = this.body.getChild("left_wing");
        this.left_wing_tip = this.left_wing.getChild("left_wing_tip");
        this.tail = this.body.getChild("tail");
        this.tail2 = this.tail.getChild("tail2");
        this.tail3 = this.tail2.getChild("tail3");
        this.right_leg = root.getChild("right_leg");
        this.right_shin = this.right_leg.getChild("right_shin");
        this.left_leg = root.getChild("left_leg");
        this.left_shin = this.left_leg.getChild("left_shin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-8F, -20F, -4.5F, 16F, 13F, 9F).texOffs(50, 0).addBox(-5.5F, -7F, -3.5F, 11F, 8F, 7F), PartPose.offsetAndRotation(0F, 2F, 0F, 0.1745F, 0.0000F, 0.0000F));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(86, 0).addBox(-4.5F, -9F, -4.5F, 9F, 9F, 9F).texOffs(122, 0).addBox(-3.5F, -2F, -5.5F, 7F, 3F, 2F), PartPose.offsetAndRotation(0F, -20F, -1F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_horn = head.addOrReplaceChild("right_horn", CubeListBuilder.create().texOffs(140, 0).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(-3.5F, -8F, 0F, -0.3491F, 0.0000F, -0.6109F));
        PartDefinition right_horn2 = right_horn.addOrReplaceChild("right_horn2", CubeListBuilder.create().texOffs(152, 0).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.5236F, 0.0000F, 0.4363F));
        PartDefinition right_horn3 = right_horn2.addOrReplaceChild("right_horn3", CubeListBuilder.create().texOffs(160, 0).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.5236F, 0.0000F, 0.3491F));
        PartDefinition left_horn = head.addOrReplaceChild("left_horn", CubeListBuilder.create().texOffs(164, 0).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(3.5F, -8F, 0F, -0.3491F, 0.0000F, 0.6109F));
        PartDefinition left_horn2 = left_horn.addOrReplaceChild("left_horn2", CubeListBuilder.create().texOffs(176, 0).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.5236F, 0.0000F, -0.4363F));
        PartDefinition left_horn3 = left_horn2.addOrReplaceChild("left_horn3", CubeListBuilder.create().texOffs(184, 0).addBox(-0.5F, -3F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.5236F, 0.0000F, -0.3491F));
        PartDefinition right_arm = body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(188, 0).addBox(-3F, -2F, -3F, 5F, 13F, 6F), PartPose.offsetAndRotation(-10F, -17F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_forearm = right_arm.addOrReplaceChild("right_forearm", CubeListBuilder.create().texOffs(210, 0).addBox(-2.5F, 0F, -2.5F, 5F, 12F, 5F).texOffs(230, 0).addBox(-3F, 11F, -2.5F, 1F, 4F, 1F).texOffs(234, 0).addBox(-1F, 11F, -2.5F, 1F, 5F, 1F).texOffs(238, 0).addBox(1F, 11F, -2.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(-0.5F, 11F, 0F, -0.2618F, 0.0000F, 0.0000F));
        PartDefinition left_arm = body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(0, 22).addBox(-2F, -2F, -3F, 5F, 13F, 6F), PartPose.offsetAndRotation(10F, -17F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_forearm = left_arm.addOrReplaceChild("left_forearm", CubeListBuilder.create().texOffs(22, 22).addBox(-2.5F, 0F, -2.5F, 5F, 12F, 5F).texOffs(42, 22).addBox(-2F, 11F, -2.5F, 1F, 4F, 1F).texOffs(46, 22).addBox(0F, 11F, -2.5F, 1F, 5F, 1F).texOffs(50, 22).addBox(2F, 11F, -2.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.5F, 11F, 0F, -0.2618F, 0.0000F, 0.0000F));
        PartDefinition right_wing = body.addOrReplaceChild("right_wing", CubeListBuilder.create().texOffs(54, 22).addBox(-20F, -1F, -1F, 20F, 2F, 2F).texOffs(98, 22).addBox(-20F, 1F, 0F, 20F, 20F, 0F), PartPose.offsetAndRotation(-3F, -17F, 4F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_wing_tip = right_wing.addOrReplaceChild("right_wing_tip", CubeListBuilder.create().texOffs(138, 22).addBox(-16F, -1F, -1F, 16F, 2F, 2F).texOffs(174, 22).addBox(-16F, 1F, 0F, 16F, 16F, 0F).texOffs(206, 22).addBox(-17F, -2F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(-20F, 0F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_wing = body.addOrReplaceChild("left_wing", CubeListBuilder.create().texOffs(210, 22).addBox(0F, -1F, -1F, 20F, 2F, 2F).texOffs(0, 42).addBox(0F, 1F, 0F, 20F, 20F, 0F), PartPose.offsetAndRotation(3F, -17F, 4F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_wing_tip = left_wing.addOrReplaceChild("left_wing_tip", CubeListBuilder.create().texOffs(40, 42).addBox(0F, -1F, -1F, 16F, 2F, 2F).texOffs(76, 42).addBox(0F, 1F, 0F, 16F, 16F, 0F).texOffs(108, 42).addBox(16F, -2F, -0.5F, 1F, 3F, 1F), PartPose.offsetAndRotation(20F, 0F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition tail = body.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(112, 42).addBox(-1.5F, 0F, -1.5F, 3F, 9F, 3F), PartPose.offsetAndRotation(0F, 0F, 3F, 0.9599F, 0.0000F, 0.0000F));
        PartDefinition tail2 = tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(124, 42).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(0F, 9F, 0F, 0.3491F, 0.0000F, 0.0000F));
        PartDefinition tail3 = tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(132, 42).addBox(-0.5F, 0F, -0.5F, 1F, 7F, 1F).texOffs(136, 42).addBox(-2F, 6F, -0.5F, 4F, 3F, 1F), PartPose.offsetAndRotation(0F, 9F, 0F, 0.3491F, 0.0000F, 0.0000F));
        PartDefinition right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(146, 42).addBox(-2.5F, 0F, -3F, 5F, 12F, 6F), PartPose.offsetAndRotation(-4.5F, 1F, 0F, -0.2618F, 0.0000F, 0.0000F));
        PartDefinition right_shin = right_leg.addOrReplaceChild("right_shin", CubeListBuilder.create().texOffs(168, 42).addBox(-2F, 0F, -2F, 4F, 10F, 4F).texOffs(184, 42).addBox(-2.5F, 9F, -4F, 5F, 2F, 5F), PartPose.offsetAndRotation(0F, 12F, -1F, 0.6981F, 0.0000F, 0.0000F));
        PartDefinition left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(204, 42).addBox(-2.5F, 0F, -3F, 5F, 12F, 6F), PartPose.offsetAndRotation(4.5F, 1F, 0F, -0.2618F, 0.0000F, 0.0000F));
        PartDefinition left_shin = left_leg.addOrReplaceChild("left_shin", CubeListBuilder.create().texOffs(226, 42).addBox(-2F, 0F, -2F, 4F, 10F, 4F).texOffs(0, 62).addBox(-2.5F, 9F, -4F, 5F, 2F, 5F), PartPose.offsetAndRotation(0F, 12F, -1F, 0.6981F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);           // ticks depuis le début de l'animation
        float breathe = Mth.sin(age * 0.08F);

        this.head.yRot = headYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.body.xRot = 0.17F + breathe * 0.03F;
        boolean spread = e.phase() >= 2;
        float flap = Mth.sin(age * (spread ? 0.18F : 0.1F)) * (spread ? 0.35F : 0.15F);
        float fold = spread ? 0.25F : 0.75F;
        this.right_wing.yRot = fold + flap;  this.left_wing.yRot = -fold - flap;
        this.right_wing.zRot = -0.3F + flap * 0.5F; this.left_wing.zRot = 0.3F - flap * 0.5F;
        this.right_wing_tip.yRot = spread ? 0.3F + flap : 1.2F; this.left_wing_tip.yRot = spread ? -0.3F - flap : -1.2F;
        this.tail.zRot = Mth.sin(age * 0.1F) * 0.3F;
        this.tail2.zRot = Mth.sin(age * 0.1F - 0.8F) * 0.35F;
        this.tail3.zRot = Mth.sin(age * 0.1F - 1.6F) * 0.4F;
        this.right_leg.xRot = -0.26F + Mth.cos(limbSwing * 0.6F) * 0.9F * limbAmount;
        this.left_leg.xRot = -0.26F + Mth.cos(limbSwing * 0.6F + Mth.PI) * 0.9F * limbAmount;
        this.right_arm.xRot = Mth.cos(limbSwing * 0.6F + Mth.PI) * 0.5F * limbAmount;
        this.left_arm.xRot = Mth.cos(limbSwing * 0.6F) * 0.5F * limbAmount;
        this.right_arm.zRot = 0.15F; this.left_arm.zRot = -0.15F;
        if (anim == 1 && at < 30) {            // INCANTATION : bras écartés vers le ciel
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.2F * k; this.left_arm.xRot = -2.2F * k;
            this.right_arm.zRot = 0.7F * k;  this.left_arm.zRot = -0.7F * k;
            this.head.xRot -= 0.4F * k;
        } else if (anim == 2 && at < 14) {     // GRIFFE
            float k = at / 14F;
            this.right_arm.xRot = k < 0.4F ? -2.6F * (k / 0.4F) : -2.6F + 3.6F * ((k - 0.4F) / 0.6F);
            this.right_arm.yRot = -0.5F * k;
        } else if (anim == 3 && at < 40) {     // RUGISSEMENT DE TRANSFORMATION
            float k = Mth.sin(Mth.clamp(at / 40F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.8F * k;
            this.right_arm.zRot = 1.3F * k; this.left_arm.zRot = -1.3F * k;
            this.right_wing.yRot = 0.1F; this.left_wing.yRot = -0.1F;
            this.right_wing_tip.yRot = 0.1F; this.left_wing_tip.yRot = -0.1F;
        }

    }
}
