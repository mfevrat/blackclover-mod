package com.blackclovermod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Bandes noires façon cinéma + fondu + petite aide "V pour passer". */
public final class CinematicOverlay {
    public static final IGuiOverlay HUD = (gui, g, partialTick, w, h) -> {
        if (!CinematicManager.active()) return;
        float t = CinematicManager.time() + partialTick;
        float dur = CinematicManager.duration();
        float k = Mth.clamp(Math.min(t / 12f, (dur - t) / 12f), 0f, 1f);
        int bar = (int) (h * 0.11f * k);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        // fondu au noir au tout début et à la fin
        float fade = Mth.clamp(1f - t / 8f, 0f, 1f) + Mth.clamp(1f - (dur - t) / 8f, 0f, 1f);
        if (fade > 0.01f) g.fill(0, 0, w, h, ((int) (Mth.clamp(fade, 0f, 1f) * 200) << 24));
        if (bar > 10) {
            Component hint = Component.translatable("hud.blackclover.skip", KeyBindings.SKIP.getTranslatedKeyMessage());
            var font = Minecraft.getInstance().font;
            g.drawString(font, hint, w - font.width(hint) - 8, h - bar / 2 - 4, 0x99FFFFFF, false);
        }
    };

    private CinematicOverlay() {}
}
