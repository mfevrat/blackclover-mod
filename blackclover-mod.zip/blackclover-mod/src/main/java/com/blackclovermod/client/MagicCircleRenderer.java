package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.entity.MagicCircleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Dessine un cercle magique lumineux : un grand anneau et un anneau intérieur qui tournent en sens inverse. */
public class MagicCircleRenderer extends EntityRenderer<MagicCircleEntity> {
    private static final ResourceLocation[] OUTER = {
            BlackCloverMod.id("textures/effect/circle_arcane.png"),
            BlackCloverMod.id("textures/effect/circle_clover.png"),
            BlackCloverMod.id("textures/effect/circle_demon.png")};
    private static final ResourceLocation OOZE = BlackCloverMod.id("textures/effect/ooze.png");
    private static final ResourceLocation INNER = BlackCloverMod.id("textures/effect/circle_inner.png");

    public MagicCircleRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(MagicCircleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float age = e.tickCount + pt;
        float in = Mth.clamp(age / 6f, 0f, 1f);
        float out = Mth.clamp((e.getLife() - age) / 8f, 0f, 1f);
        float alpha = Math.min(in, out);
        if (alpha <= 0.01f) return;
        float grow = 1f - (1f - in) * (1f - in);
        float r = e.getRadius() * (0.25f + 0.75f * grow);
        int c = e.getColor();
        float cr = ((c >> 16) & 255) / 255f, cg = ((c >> 8) & 255) / 255f, cb = (c & 255) / 255f;
        if (e.getStyle() == 3) {                 // mare de liquide noir (opaque, ondule)
            ps.pushPose();
            ps.translate(0, 0.02, 0);
            float wob = 1f + Mth.sin(age * 0.15f) * 0.04f;
            ps.scale(wob, 1f, 2f - wob);
            ps.mulPose(Axis.YP.rotationDegrees(age * 0.4f));
            quadTranslucent(ps, buf.getBuffer(RenderType.entityTranslucent(OOZE)), r, light, alpha);
            ps.popPose();
            return;
        }
        int style = Mth.clamp(e.getStyle(), 0, OUTER.length - 1);

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(e.getCircleYaw()));
        ps.mulPose(Axis.XP.rotationDegrees(e.getCirclePitch()));
        ps.translate(0, 0.02, 0);

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(age * 1.6f));
        quad(ps, buf.getBuffer(RenderType.eyes(OUTER[style])), r, cr, cg, cb, alpha);
        ps.popPose();

        ps.pushPose();
        ps.translate(0, 0.015, 0);
        ps.mulPose(Axis.YP.rotationDegrees(-age * 3.2f));
        quad(ps, buf.getBuffer(RenderType.eyes(INNER)), r * 0.62f, cr, cg, cb, alpha);
        ps.popPose();

        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    /** Un carré texturé à plat, visible des deux côtés. */
    static void quad(PoseStack ps, VertexConsumer vc, float r, float red, float green, float blue, float a) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        v(vc, m, n, -r, -r, 0, 0, red, green, blue, a);
        v(vc, m, n, -r, r, 0, 1, red, green, blue, a);
        v(vc, m, n, r, r, 1, 1, red, green, blue, a);
        v(vc, m, n, r, -r, 1, 0, red, green, blue, a);
        v(vc, m, n, r, -r, 1, 0, red, green, blue, a);
        v(vc, m, n, r, r, 1, 1, red, green, blue, a);
        v(vc, m, n, -r, r, 0, 1, red, green, blue, a);
        v(vc, m, n, -r, -r, 0, 0, red, green, blue, a);
    }

    private static void v(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float z, float u, float vv, float r, float g, float b, float a) {
        vc.vertex(m, x, 0, z).color(r * a, g * a, b * a, a).uv(u, vv).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 1, 0).endVertex();
    }

    private static void quadTranslucent(PoseStack ps, VertexConsumer vc, float r, int light, float a) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float[][] c = {{-r, -r, 0, 0}, {-r, r, 0, 1}, {r, r, 1, 1}, {r, -r, 1, 0}};
        for (float[] p : c)
            vc.vertex(m, p[0], 0, p[1]).color(1f, 1f, 1f, a).uv(p[2], p[3]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0, 1, 0).endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(MagicCircleEntity e) {
        return OUTER[0];
    }
}
