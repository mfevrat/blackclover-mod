package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.entity.SpellBeamEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Rayon d'énergie : 3 plans croisés qui tournent + un cœur blanc, texture qui défile. */
public class SpellBeamRenderer extends EntityRenderer<SpellBeamEntity> {
    private static final ResourceLocation BEAM = BlackCloverMod.id("textures/effect/beam.png");

    public SpellBeamRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(SpellBeamEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float age = e.tickCount + pt;
        float in = Mth.clamp(age / 3f, 0f, 1f);
        float out = Mth.clamp((e.getLife() - age) / 6f, 0f, 1f);
        float k = Math.min(in, out);
        if (k <= 0.01f) return;
        float len = e.getLength() * Math.min(1f, age / 2f);
        float w = e.getWidth() * (0.4f + 0.6f * k) * (1f + Mth.sin(age * 1.3f) * 0.08f);
        int c = e.getColor();
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float scroll = -age * 0.15f;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(e.getBeamYaw()));
        ps.mulPose(Axis.XP.rotationDegrees(e.getBeamPitch()));
        ps.mulPose(Axis.YP.rotationDegrees(age * 6f));
        VertexConsumer vc = buf.getBuffer(RenderType.eyes(BEAM));
        for (int i = 0; i < 3; i++) {
            ps.pushPose();
            ps.mulPose(Axis.YP.rotationDegrees(i * 60f));
            plane(ps, vc, w, len, scroll, r, g, b, k);
            plane(ps, vc, w * 0.35f, len, scroll * 1.7f, 1f, 1f, 1f, k);
            ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    private static void plane(PoseStack ps, VertexConsumer vc, float w, float len, float scroll, float r, float g, float b, float a) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float h = w / 2f, v1 = scroll, v2 = scroll + len / 4f;
        vert(vc, m, n, -h, 0, 0, v1, r, g, b, a);
        vert(vc, m, n, -h, len, 0, v2, r, g, b, a);
        vert(vc, m, n, h, len, 1, v2, r, g, b, a);
        vert(vc, m, n, h, 0, 1, v1, r, g, b, a);
        vert(vc, m, n, h, 0, 1, v1, r, g, b, a);
        vert(vc, m, n, h, len, 1, v2, r, g, b, a);
        vert(vc, m, n, -h, len, 0, v2, r, g, b, a);
        vert(vc, m, n, -h, 0, 0, v1, r, g, b, a);
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float u, float v, float r, float g, float b, float a) {
        vc.vertex(m, x, y, 0).color(r * a, g * a, b * a, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 0, 1).endVertex();
    }

    @Override
    public boolean shouldRender(SpellBeamEntity e, net.minecraft.client.renderer.culling.Frustum f, double x, double y, double z) {
        return true; // les rayons sont longs : on ne les cache jamais
    }

    @Override
    public ResourceLocation getTextureLocation(SpellBeamEntity e) {
        return BEAM;
    }
}
