package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL généré automatiquement (voir gen/bossmodels.py). Les animations sont dans setupAnim. */
public class ElfKingModel<T extends MagicBossEntity> extends HierarchicalModel<T> {
    private final ModelPart root;
    public final ModelPart body;
    public final ModelPart skirt;
    public final ModelPart head;
    public final ModelPart crown;
    public final ModelPart halo;
    public final ModelPart right_ear;
    public final ModelPart left_ear;
    public final ModelPart right_arm;
    public final ModelPart left_arm;
    public final ModelPart right_wing_up;
    public final ModelPart right_wing_low;
    public final ModelPart left_wing_up;
    public final ModelPart left_wing_low;

    public ElfKingModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.skirt = this.body.getChild("skirt");
        this.head = this.body.getChild("head");
        this.crown = this.head.getChild("crown");
        this.halo = this.head.getChild("halo");
        this.right_ear = this.head.getChild("right_ear");
        this.left_ear = this.head.getChild("left_ear");
        this.right_arm = this.body.getChild("right_arm");
        this.left_arm = this.body.getChild("left_arm");
        this.right_wing_up = this.body.getChild("right_wing_up");
        this.right_wing_low = this.body.getChild("right_wing_low");
        this.left_wing_up = this.body.getChild("left_wing_up");
        this.left_wing_low = this.body.getChild("left_wing_low");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.5F, 0F, -2.5F, 9F, 13F, 5F).texOffs(28, 0).addBox(-5F, -1F, -3F, 10F, 3F, 6F).texOffs(60, 0).addBox(-1F, 1F, -2.8F, 2F, 12F, 1F), PartPose.offsetAndRotation(0F, -14F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition skirt = body.addOrReplaceChild("skirt", CubeListBuilder.create().texOffs(66, 0).addBox(-5.5F, 0F, -3.5F, 11F, 15F, 7F).texOffs(0, 22).addBox(-6F, 14F, -4F, 12F, 2F, 8F), PartPose.offsetAndRotation(0F, 12F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(40, 22).addBox(-4F, -8F, -4F, 8F, 8F, 8F).texOffs(72, 22).addBox(-4.5F, -8.5F, 1F, 9F, 11F, 4F), PartPose.offsetAndRotation(0F, -1F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition crown = head.addOrReplaceChild("crown", CubeListBuilder.create().texOffs(0, 38).addBox(-4.5F, -2F, -4.5F, 9F, 2F, 9F).texOffs(36, 38).addBox(-0.5F, -5F, -4.6F, 1F, 3F, 1F).texOffs(40, 38).addBox(-3.5F, -4F, -4.6F, 1F, 2F, 1F).texOffs(44, 38).addBox(2.5F, -4F, -4.6F, 1F, 2F, 1F), PartPose.offsetAndRotation(0F, -8F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition halo = head.addOrReplaceChild("halo", CubeListBuilder.create().texOffs(48, 38).addBox(-5F, -0.5F, -5F, 10F, 1F, 1F).texOffs(70, 38).addBox(-5F, -0.5F, 4F, 10F, 1F, 1F).texOffs(92, 38).addBox(-5F, -0.5F, -4F, 1F, 1F, 8F).texOffs(110, 38).addBox(4F, -0.5F, -4F, 1F, 1F, 8F), PartPose.offsetAndRotation(0F, -13F, 2F, -0.3491F, 0.0000F, 0.0000F));
        PartDefinition right_ear = head.addOrReplaceChild("right_ear", CubeListBuilder.create().texOffs(0, 49).addBox(-4F, -1F, -0.5F, 4F, 2F, 1F), PartPose.offsetAndRotation(-4F, -4F, 0F, 0.0000F, -0.4363F, -0.2618F));
        PartDefinition left_ear = head.addOrReplaceChild("left_ear", CubeListBuilder.create().texOffs(10, 49).addBox(0F, -1F, -0.5F, 4F, 2F, 1F), PartPose.offsetAndRotation(4F, -4F, 0F, 0.0000F, 0.4363F, 0.2618F));
        PartDefinition right_arm = body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(20, 49).addBox(-2F, -1F, -2F, 3F, 11F, 4F).texOffs(34, 49).addBox(-3F, 8F, -3F, 5F, 6F, 6F).texOffs(56, 49).addBox(-1.5F, 13F, -1.5F, 2F, 2F, 3F), PartPose.offsetAndRotation(-6F, 1F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_arm = body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(66, 49).addBox(-1F, -1F, -2F, 3F, 11F, 4F).texOffs(80, 49).addBox(-2F, 8F, -3F, 5F, 6F, 6F).texOffs(102, 49).addBox(-0.5F, 13F, -1.5F, 2F, 2F, 3F), PartPose.offsetAndRotation(6F, 1F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_wing_up = body.addOrReplaceChild("right_wing_up", CubeListBuilder.create().texOffs(0, 64).addBox(-18F, -14F, 0F, 18F, 16F, 0F), PartPose.offsetAndRotation(-2F, 2F, 3F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_wing_low = body.addOrReplaceChild("right_wing_low", CubeListBuilder.create().texOffs(36, 64).addBox(-13F, 0F, 0F, 13F, 11F, 0F), PartPose.offsetAndRotation(-2F, 7F, 3F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_wing_up = body.addOrReplaceChild("left_wing_up", CubeListBuilder.create().texOffs(62, 64).addBox(0F, -14F, 0F, 18F, 16F, 0F), PartPose.offsetAndRotation(2F, 2F, 3F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_wing_low = body.addOrReplaceChild("left_wing_low", CubeListBuilder.create().texOffs(98, 64).addBox(0F, 0F, 0F, 13F, 11F, 0F), PartPose.offsetAndRotation(2F, 7F, 3F, 0.0000F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);           // ticks depuis le début de l'animation
        float breathe = Mth.sin(age * 0.08F);

        this.head.yRot = headYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.body.y += Mth.sin(age * 0.06F) * 1.5F;           // lévitation
        float flap = Mth.sin(age * 0.15F) * 0.25F;
        this.right_wing_up.yRot = 0.55F + flap;  this.right_wing_low.yRot = 0.45F + flap * 0.8F;
        this.left_wing_up.yRot = -0.55F - flap;  this.left_wing_low.yRot = -0.45F - flap * 0.8F;
        this.right_wing_up.zRot = -0.15F; this.left_wing_up.zRot = 0.15F;
        this.right_wing_low.zRot = 0.25F; this.left_wing_low.zRot = -0.25F;
        this.skirt.xRot = 0.05F + breathe * 0.03F;
        this.right_arm.zRot = 0.1F + breathe * 0.05F; this.left_arm.zRot = -0.1F - breathe * 0.05F;
        this.halo.yRot = age * 0.05F;
        if (anim == 1 && at < 40) {            // PLUIE D'ÉPÉES : bras au ciel, ailes déployées
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.9F * k; this.left_arm.xRot = -2.9F * k;
            this.right_arm.zRot = 0.4F * k;  this.left_arm.zRot = -0.4F * k;
            this.right_wing_up.yRot = 0.2F; this.left_wing_up.yRot = -0.2F;
        } else if (anim == 2 && at < 40) {     // JUGEMENT : désigne le sol
            float k = Mth.clamp(at / 6F, 0F, 1F);
            this.right_arm.xRot = -1.4F * k; this.left_arm.xRot = -0.3F * k;
            this.head.xRot += 0.3F * k;
        } else if (anim == 3 && at < 10) {     // TÉLÉPORTATION : repli des ailes
            float k = 1F - at / 10F;
            this.right_wing_up.yRot += 0.9F * k; this.left_wing_up.yRot -= 0.9F * k;
        }

    }
}
