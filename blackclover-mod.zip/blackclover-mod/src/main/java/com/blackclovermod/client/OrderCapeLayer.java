package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.item.OrderArmorItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Cape 3D qui flotte au vent quand on porte une robe d'ordre (même calcul que les capes de Minecraft). */
public class OrderCapeLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    public OrderCapeLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limbSwing, float limbAmount,
                       float pt, float age, float headYaw, float headPitch) {
        if (p.isInvisible()) return;
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        if (!(chest.getItem() instanceof OrderArmorItem robe)) return;
        ResourceLocation tex = BlackCloverMod.id("textures/entity/cape/" + robe.order.id + ".png");

        ps.pushPose();
        ps.translate(0.0F, 0.0F, 0.19F);
        double dx = Mth.lerp(pt, p.xCloakO, p.xCloak) - Mth.lerp(pt, p.xo, p.getX());
        double dy = Mth.lerp(pt, p.yCloakO, p.yCloak) - Mth.lerp(pt, p.yo, p.getY());
        double dz = Mth.lerp(pt, p.zCloakO, p.zCloak) - Mth.lerp(pt, p.zo, p.getZ());
        float body = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot);
        double sin = Mth.sin(body * Mth.DEG_TO_RAD);
        double cos = -Mth.cos(body * Mth.DEG_TO_RAD);
        float lift = Mth.clamp((float) dy * 10.0F, -6.0F, 32.0F);
        float swing = Mth.clamp((float) (dx * sin + dz * cos) * 100.0F, 0.0F, 150.0F);
        float side = Mth.clamp((float) (dx * cos - dz * sin) * 100.0F, -20.0F, 20.0F);
        float bob = Mth.lerp(pt, p.oBob, p.bob);
        lift += Mth.sin(Mth.lerp(pt, p.walkDistO, p.walkDist) * 6.0F) * 32.0F * bob;
        lift += Mth.sin(age * 0.07F) * 2.0F; // petite brise permanente
        if (p.isCrouching()) lift += 25.0F;
        ps.mulPose(Axis.XP.rotationDegrees(6.0F + swing / 2.0F + lift));
        ps.mulPose(Axis.ZP.rotationDegrees(side / 2.0F));
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - side / 2.0F));
        VertexConsumer vc = buf.getBuffer(RenderType.entitySolid(tex));
        getParentModel().renderCloak(ps, vc, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }
}
