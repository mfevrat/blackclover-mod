package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL généré automatiquement (voir gen/bossmodels.py). Les animations sont dans setupAnim. */
public class DungeonGuardianModel<T extends MagicBossEntity> extends HierarchicalModel<T> {
    private final ModelPart root;
    public final ModelPart body;
    public final ModelPart core;
    public final ModelPart head;
    public final ModelPart right_arm;
    public final ModelPart right_crystal;
    public final ModelPart left_arm;
    public final ModelPart left_crystal;
    public final ModelPart right_leg;
    public final ModelPart left_leg;

    public DungeonGuardianModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.core = this.body.getChild("core");
        this.head = this.body.getChild("head");
        this.right_arm = this.body.getChild("right_arm");
        this.right_crystal = this.right_arm.getChild("right_crystal");
        this.left_arm = this.body.getChild("left_arm");
        this.left_crystal = this.left_arm.getChild("left_crystal");
        this.right_leg = root.getChild("right_leg");
        this.left_leg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-10F, -20F, -5F, 20F, 18F, 10F).texOffs(60, 0).addBox(-7F, -2F, -4F, 14F, 6F, 8F).texOffs(0, 28).addBox(-6F, -22F, 2F, 12F, 4F, 4F), PartPose.offsetAndRotation(0F, 4F, 0F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition core = body.addOrReplaceChild("core", CubeListBuilder.create().texOffs(32, 28).addBox(-2F, -2F, -1F, 4F, 4F, 1F), PartPose.offsetAndRotation(0F, -12F, -5F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(42, 28).addBox(-4F, -7F, -4F, 8F, 7F, 8F).texOffs(74, 28).addBox(-5F, -8F, -4.5F, 10F, 2F, 3F), PartPose.offsetAndRotation(0F, -20F, -2F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_arm = body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 43).addBox(-5F, -3F, -4F, 7F, 22F, 8F).texOffs(30, 43).addBox(-6F, 17F, -4.5F, 9F, 8F, 9F), PartPose.offsetAndRotation(-12F, -16F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition right_crystal = right_arm.addOrReplaceChild("right_crystal", CubeListBuilder.create().texOffs(66, 43).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F), PartPose.offsetAndRotation(-2F, -3F, 0F, 0.0000F, 0.0000F, -0.3491F));
        PartDefinition left_arm = body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(78, 43).addBox(-2F, -3F, -4F, 7F, 22F, 8F).texOffs(0, 73).addBox(-3F, 17F, -4.5F, 9F, 8F, 9F), PartPose.offsetAndRotation(12F, -16F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_crystal = left_arm.addOrReplaceChild("left_crystal", CubeListBuilder.create().texOffs(36, 73).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F), PartPose.offsetAndRotation(2F, -3F, 0F, 0.0000F, 0.0000F, 0.3491F));
        PartDefinition right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(48, 73).addBox(-3.5F, 0F, -3.5F, 7F, 18F, 7F), PartPose.offsetAndRotation(-5F, 6F, 0F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(76, 73).addBox(-3.5F, 0F, -3.5F, 7F, 18F, 7F), PartPose.offsetAndRotation(5F, 6F, 0F, 0.0000F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);           // ticks depuis le début de l'animation
        float breathe = Mth.sin(age * 0.08F);

        this.head.yRot = headYaw * Mth.DEG_TO_RAD * 0.6F;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD * 0.5F;
        this.body.y += breathe * 0.4F;
        this.right_leg.xRot = Mth.cos(limbSwing * 0.5F) * 1.0F * limbAmount;
        this.left_leg.xRot = Mth.cos(limbSwing * 0.5F + Mth.PI) * 1.0F * limbAmount;
        this.right_arm.xRot = Mth.cos(limbSwing * 0.5F + Mth.PI) * 0.6F * limbAmount;
        this.left_arm.xRot = Mth.cos(limbSwing * 0.5F) * 0.6F * limbAmount;
        this.right_arm.zRot = 0.08F + breathe * 0.03F;
        this.left_arm.zRot = -0.08F - breathe * 0.03F;
        if (anim == 1 && at < 26) {            // FRAPPE SISMIQUE : bras levés puis abattus
            float up = at < 14 ? at / 14F : 1F - (at - 14) / 4F;
            up = Mth.clamp(up, -0.3F, 1F);
            this.right_arm.xRot = -2.8F * up;
            this.left_arm.xRot = -2.8F * up;
            this.body.xRot = 0.14F - 0.35F * up + (at > 14 ? 0.5F : 0F);
        } else if (anim == 2 && at < 16) {     // LANCER DE ROCHER
            float k = at / 16F;
            this.right_arm.xRot = k < 0.5F ? -3.0F * (k * 2) : -3.0F + 4.2F * ((k - 0.5F) * 2);
        } else if (anim == 3 && at < 30) {     // RUGISSEMENT
            float k = Mth.sin(at / 30F * Mth.PI);
            this.head.xRot = -0.6F * k;
            this.right_arm.zRot = 1.2F * k;
            this.left_arm.zRot = -1.2F * k;
        }
        this.core.xScale = this.core.yScale = 1F + Mth.sin(age * 0.2F) * 0.15F;

    }
}
