package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL (54 pièces), généré par gen/bosses_v3.py. Les animations sont dans setupAnim. */
public class DungeonGuardianModel<T extends MagicBossEntity> extends HierarchicalModel<T> {
    private final ModelPart root;
    public final ModelPart pelvis;
    public final ModelPart waist;
    public final ModelPart chest;
    public final ModelPart core;
    public final ModelPart rune_0;
    public final ModelPart rune_1;
    public final ModelPart rune_2;
    public final ModelPart rune_3;
    public final ModelPart back_crystal_0;
    public final ModelPart back_crystal_1;
    public final ModelPart back_crystal_2;
    public final ModelPart back_crystal_3;
    public final ModelPart back_crystal_4;
    public final ModelPart vine0_0;
    public final ModelPart vine0_1;
    public final ModelPart vine0_2;
    public final ModelPart vine1_0;
    public final ModelPart vine1_1;
    public final ModelPart vine1_2;
    public final ModelPart vine2_0;
    public final ModelPart vine2_1;
    public final ModelPart vine2_2;
    public final ModelPart head;
    public final ModelPart jaw;
    public final ModelPart head_crystal_l;
    public final ModelPart head_crystal_r;
    public final ModelPart right_shoulder;
    public final ModelPart right_sh_crystal_0;
    public final ModelPart right_sh_crystal_1;
    public final ModelPart right_sh_crystal_2;
    public final ModelPart right_arm;
    public final ModelPart right_elbow;
    public final ModelPart right_forearm;
    public final ModelPart right_hand;
    public final ModelPart right_finger_0;
    public final ModelPart right_finger_1;
    public final ModelPart right_finger_2;
    public final ModelPart right_thigh;
    public final ModelPart right_shin;
    public final ModelPart right_foot;
    public final ModelPart left_shoulder;
    public final ModelPart left_sh_crystal_0;
    public final ModelPart left_sh_crystal_1;
    public final ModelPart left_sh_crystal_2;
    public final ModelPart left_arm;
    public final ModelPart left_elbow;
    public final ModelPart left_forearm;
    public final ModelPart left_hand;
    public final ModelPart left_finger_0;
    public final ModelPart left_finger_1;
    public final ModelPart left_finger_2;
    public final ModelPart left_thigh;
    public final ModelPart left_shin;
    public final ModelPart left_foot;
    public final ModelPart[] vines;

    public DungeonGuardianModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.waist = this.pelvis.getChild("waist");
        this.chest = this.waist.getChild("chest");
        this.core = this.chest.getChild("core");
        this.rune_0 = this.chest.getChild("rune_0");
        this.rune_1 = this.chest.getChild("rune_1");
        this.rune_2 = this.chest.getChild("rune_2");
        this.rune_3 = this.chest.getChild("rune_3");
        this.back_crystal_0 = this.chest.getChild("back_crystal_0");
        this.back_crystal_1 = this.chest.getChild("back_crystal_1");
        this.back_crystal_2 = this.chest.getChild("back_crystal_2");
        this.back_crystal_3 = this.chest.getChild("back_crystal_3");
        this.back_crystal_4 = this.chest.getChild("back_crystal_4");
        this.vine0_0 = this.chest.getChild("vine0_0");
        this.vine0_1 = this.vine0_0.getChild("vine0_1");
        this.vine0_2 = this.vine0_1.getChild("vine0_2");
        this.vine1_0 = this.chest.getChild("vine1_0");
        this.vine1_1 = this.vine1_0.getChild("vine1_1");
        this.vine1_2 = this.vine1_1.getChild("vine1_2");
        this.vine2_0 = this.chest.getChild("vine2_0");
        this.vine2_1 = this.vine2_0.getChild("vine2_1");
        this.vine2_2 = this.vine2_1.getChild("vine2_2");
        this.head = this.chest.getChild("head");
        this.jaw = this.head.getChild("jaw");
        this.head_crystal_l = this.head.getChild("head_crystal_l");
        this.head_crystal_r = this.head.getChild("head_crystal_r");
        this.right_shoulder = this.chest.getChild("right_shoulder");
        this.right_sh_crystal_0 = this.right_shoulder.getChild("right_sh_crystal_0");
        this.right_sh_crystal_1 = this.right_shoulder.getChild("right_sh_crystal_1");
        this.right_sh_crystal_2 = this.right_shoulder.getChild("right_sh_crystal_2");
        this.right_arm = this.right_shoulder.getChild("right_arm");
        this.right_elbow = this.right_arm.getChild("right_elbow");
        this.right_forearm = this.right_arm.getChild("right_forearm");
        this.right_hand = this.right_forearm.getChild("right_hand");
        this.right_finger_0 = this.right_hand.getChild("right_finger_0");
        this.right_finger_1 = this.right_hand.getChild("right_finger_1");
        this.right_finger_2 = this.right_hand.getChild("right_finger_2");
        this.right_thigh = this.pelvis.getChild("right_thigh");
        this.right_shin = this.right_thigh.getChild("right_shin");
        this.right_foot = this.right_shin.getChild("right_foot");
        this.left_shoulder = this.chest.getChild("left_shoulder");
        this.left_sh_crystal_0 = this.left_shoulder.getChild("left_sh_crystal_0");
        this.left_sh_crystal_1 = this.left_shoulder.getChild("left_sh_crystal_1");
        this.left_sh_crystal_2 = this.left_shoulder.getChild("left_sh_crystal_2");
        this.left_arm = this.left_shoulder.getChild("left_arm");
        this.left_elbow = this.left_arm.getChild("left_elbow");
        this.left_forearm = this.left_arm.getChild("left_forearm");
        this.left_hand = this.left_forearm.getChild("left_hand");
        this.left_finger_0 = this.left_hand.getChild("left_finger_0");
        this.left_finger_1 = this.left_hand.getChild("left_finger_1");
        this.left_finger_2 = this.left_hand.getChild("left_finger_2");
        this.left_thigh = this.pelvis.getChild("left_thigh");
        this.left_shin = this.left_thigh.getChild("left_shin");
        this.left_foot = this.left_shin.getChild("left_foot");
        this.vines = new ModelPart[]{this.vine0_0, this.vine0_1, this.vine0_2, this.vine1_0, this.vine1_1, this.vine1_2, this.vine2_0, this.vine2_1, this.vine2_2};
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create().texOffs(0, 0).addBox(-7F, -2F, -4.5F, 14F, 5F, 9F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_waist = p_pelvis.addOrReplaceChild("waist", CubeListBuilder.create().texOffs(46, 0).addBox(-6F, -5F, -4F, 12F, 5F, 8F), PartPose.offsetAndRotation(0.000F, -2.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_chest = p_waist.addOrReplaceChild("chest", CubeListBuilder.create().texOffs(86, 0).addBox(-10F, -12F, -5.5F, 20F, 12F, 11F).texOffs(148, 0).addBox(-7F, -10F, -6.5F, 14F, 8F, 1F).texOffs(178, 0).addBox(-8F, -13F, 2F, 16F, 6F, 5F), PartPose.offsetAndRotation(0.000F, -5.000F, 0.000F, 0.1396F, 0.0000F, 0.0000F));
        PartDefinition p_core = p_chest.addOrReplaceChild("core", CubeListBuilder.create().texOffs(220, 0).addBox(-2F, -2F, -1F, 4F, 4F, 1F), PartPose.offsetAndRotation(0.000F, -6.000F, -6.600F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_rune_0 = p_chest.addOrReplaceChild("rune_0", CubeListBuilder.create().texOffs(230, 0).addBox(-0.5F, -0.5F, -0.5F, 1F, 1F, 1F), PartPose.offsetAndRotation(-3.500F, -6.000F, -6.700F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_rune_1 = p_chest.addOrReplaceChild("rune_1", CubeListBuilder.create().texOffs(234, 0).addBox(-0.5F, -0.5F, -0.5F, 1F, 1F, 1F), PartPose.offsetAndRotation(3.500F, -6.000F, -6.700F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_rune_2 = p_chest.addOrReplaceChild("rune_2", CubeListBuilder.create().texOffs(238, 0).addBox(-0.5F, -0.5F, -0.5F, 1F, 1F, 1F), PartPose.offsetAndRotation(0.000F, -9.500F, -6.700F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_rune_3 = p_chest.addOrReplaceChild("rune_3", CubeListBuilder.create().texOffs(242, 0).addBox(-0.5F, -0.5F, -0.5F, 1F, 1F, 1F), PartPose.offsetAndRotation(0.000F, -2.500F, -6.700F, 0.0000F, 0.0000F, 0.7854F));
        PartDefinition p_back_crystal_0 = p_chest.addOrReplaceChild("back_crystal_0", CubeListBuilder.create().texOffs(0, 23).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(-5.000F, -12.000F, 3.000F, -0.4363F, 0.0000F, -0.3491F));
        PartDefinition p_back_crystal_1 = p_chest.addOrReplaceChild("back_crystal_1", CubeListBuilder.create().texOffs(12, 23).addBox(-1.5F, -10F, -1.5F, 3F, 10F, 3F), PartPose.offsetAndRotation(0.000F, -12.000F, 4.000F, -0.6109F, 0.0000F, 0.0000F));
        PartDefinition p_back_crystal_2 = p_chest.addOrReplaceChild("back_crystal_2", CubeListBuilder.create().texOffs(24, 23).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(5.000F, -12.000F, 3.000F, -0.4363F, 0.0000F, 0.3491F));
        PartDefinition p_back_crystal_3 = p_chest.addOrReplaceChild("back_crystal_3", CubeListBuilder.create().texOffs(36, 23).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(-2.500F, -12.000F, 5.000F, -0.7854F, 0.0000F, -0.1745F));
        PartDefinition p_back_crystal_4 = p_chest.addOrReplaceChild("back_crystal_4", CubeListBuilder.create().texOffs(48, 23).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(2.500F, -12.000F, 5.000F, -0.7854F, 0.0000F, 0.1745F));
        PartDefinition p_vine0_0 = p_chest.addOrReplaceChild("vine0_0", CubeListBuilder.create().texOffs(60, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(-6.000F, -1.000F, 5.500F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine0_1 = p_vine0_0.addOrReplaceChild("vine0_1", CubeListBuilder.create().texOffs(64, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine0_2 = p_vine0_1.addOrReplaceChild("vine0_2", CubeListBuilder.create().texOffs(68, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine1_0 = p_chest.addOrReplaceChild("vine1_0", CubeListBuilder.create().texOffs(72, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(-1.000F, -1.000F, 5.500F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine1_1 = p_vine1_0.addOrReplaceChild("vine1_1", CubeListBuilder.create().texOffs(76, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine1_2 = p_vine1_1.addOrReplaceChild("vine1_2", CubeListBuilder.create().texOffs(80, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine2_0 = p_chest.addOrReplaceChild("vine2_0", CubeListBuilder.create().texOffs(84, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(4.000F, -1.000F, 5.500F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine2_1 = p_vine2_0.addOrReplaceChild("vine2_1", CubeListBuilder.create().texOffs(88, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_vine2_2 = p_vine2_1.addOrReplaceChild("vine2_2", CubeListBuilder.create().texOffs(92, 23).addBox(-0.5F, 0F, -0.5F, 1F, 4F, 1F), PartPose.offsetAndRotation(0.000F, 4.000F, 0.000F, 0.0873F, 0.0000F, 0.0000F));
        PartDefinition p_head = p_chest.addOrReplaceChild("head", CubeListBuilder.create().texOffs(96, 23).addBox(-4F, -6F, -4.5F, 8F, 7F, 8F).texOffs(128, 23).addBox(-5F, -6.5F, -5.5F, 10F, 2F, 3F).texOffs(154, 23).addBox(-3F, -3.5F, -4.6F, 6F, 1F, 0F), PartPose.offsetAndRotation(0.000F, -12.000F, -3.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(166, 23).addBox(-3.5F, 0F, -3.5F, 7F, 2F, 6F), PartPose.offsetAndRotation(0.000F, 0.500F, -1.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_head_crystal_l = p_head.addOrReplaceChild("head_crystal_l", CubeListBuilder.create().texOffs(192, 23).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(2.500F, -6.000F, 0.000F, -0.3491F, 0.0000F, 0.4363F));
        PartDefinition p_head_crystal_r = p_head.addOrReplaceChild("head_crystal_r", CubeListBuilder.create().texOffs(200, 23).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(-2.500F, -6.000F, 0.000F, -0.3491F, 0.0000F, -0.4363F));
        PartDefinition p_right_shoulder = p_chest.addOrReplaceChild("right_shoulder", CubeListBuilder.create().texOffs(208, 23).addBox(-4.5F, -4F, -5F, 9F, 8F, 10F).texOffs(0, 41).addBox(-4F, -5F, -4F, 8F, 1F, 8F), PartPose.offsetAndRotation(-11.000F, -10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_sh_crystal_0 = p_right_shoulder.addOrReplaceChild("right_sh_crystal_0", CubeListBuilder.create().texOffs(32, 41).addBox(-1F, -6F, -1F, 2F, 6F, 2F), PartPose.offsetAndRotation(2.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, 0.3491F));
        PartDefinition p_right_sh_crystal_1 = p_right_shoulder.addOrReplaceChild("right_sh_crystal_1", CubeListBuilder.create().texOffs(40, 41).addBox(-1F, -8F, -1F, 2F, 8F, 2F), PartPose.offsetAndRotation(-1.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, -0.0873F));
        PartDefinition p_right_sh_crystal_2 = p_right_shoulder.addOrReplaceChild("right_sh_crystal_2", CubeListBuilder.create().texOffs(48, 41).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(-3.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, -0.4363F));
        PartDefinition p_right_arm = p_right_shoulder.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(56, 41).addBox(-3.5F, 0F, -3.5F, 7F, 10F, 7F), PartPose.offsetAndRotation(-1.000F, 3.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_elbow = p_right_arm.addOrReplaceChild("right_elbow", CubeListBuilder.create().texOffs(84, 41).addBox(-4F, -1.5F, -4F, 8F, 3F, 8F), PartPose.offsetAndRotation(0.000F, 10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_forearm = p_right_arm.addOrReplaceChild("right_forearm", CubeListBuilder.create().texOffs(116, 41).addBox(-4.5F, 0F, -4.5F, 9F, 11F, 9F).texOffs(152, 41).addBox(-4.5F, 5F, -4.5F, 9F, 1F, 9F, new CubeDeformation(0.05F)), PartPose.offsetAndRotation(0.000F, 10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_hand = p_right_forearm.addOrReplaceChild("right_hand", CubeListBuilder.create().texOffs(188, 41).addBox(-4F, 0F, -4F, 8F, 5F, 8F), PartPose.offsetAndRotation(0.000F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_finger_0 = p_right_hand.addOrReplaceChild("right_finger_0", CubeListBuilder.create().texOffs(220, 41).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(-2.700F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_finger_1 = p_right_hand.addOrReplaceChild("right_finger_1", CubeListBuilder.create().texOffs(230, 41).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(0.000F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_finger_2 = p_right_hand.addOrReplaceChild("right_finger_2", CubeListBuilder.create().texOffs(240, 41).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(2.700F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_thigh = p_pelvis.addOrReplaceChild("right_thigh", CubeListBuilder.create().texOffs(0, 61).addBox(-3.5F, 0F, -3.5F, 7F, 9F, 7F), PartPose.offsetAndRotation(-4.500F, 1.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_shin = p_right_thigh.addOrReplaceChild("right_shin", CubeListBuilder.create().texOffs(28, 61).addBox(-3F, 0F, -3F, 6F, 8F, 6F).texOffs(52, 61).addBox(-3.5F, -1F, -4F, 7F, 3F, 3F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_right_foot = p_right_shin.addOrReplaceChild("right_foot", CubeListBuilder.create().texOffs(72, 61).addBox(-3.5F, 0F, -5F, 7F, 2F, 8F), PartPose.offsetAndRotation(0.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_shoulder = p_chest.addOrReplaceChild("left_shoulder", CubeListBuilder.create().texOffs(102, 61).addBox(-4.5F, -4F, -5F, 9F, 8F, 10F).texOffs(140, 61).addBox(-4F, -5F, -4F, 8F, 1F, 8F), PartPose.offsetAndRotation(11.000F, -10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_sh_crystal_0 = p_left_shoulder.addOrReplaceChild("left_sh_crystal_0", CubeListBuilder.create().texOffs(172, 61).addBox(-1F, -6F, -1F, 2F, 6F, 2F), PartPose.offsetAndRotation(-2.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, -0.3491F));
        PartDefinition p_left_sh_crystal_1 = p_left_shoulder.addOrReplaceChild("left_sh_crystal_1", CubeListBuilder.create().texOffs(180, 61).addBox(-1F, -8F, -1F, 2F, 8F, 2F), PartPose.offsetAndRotation(1.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, 0.0873F));
        PartDefinition p_left_sh_crystal_2 = p_left_shoulder.addOrReplaceChild("left_sh_crystal_2", CubeListBuilder.create().texOffs(188, 61).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(3.000F, -4.000F, 0.000F, -0.1745F, 0.0000F, 0.4363F));
        PartDefinition p_left_arm = p_left_shoulder.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(196, 61).addBox(-3.5F, 0F, -3.5F, 7F, 10F, 7F), PartPose.offsetAndRotation(1.000F, 3.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_elbow = p_left_arm.addOrReplaceChild("left_elbow", CubeListBuilder.create().texOffs(224, 61).addBox(-4F, -1.5F, -4F, 8F, 3F, 8F), PartPose.offsetAndRotation(0.000F, 10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_forearm = p_left_arm.addOrReplaceChild("left_forearm", CubeListBuilder.create().texOffs(0, 79).addBox(-4.5F, 0F, -4.5F, 9F, 11F, 9F).texOffs(36, 79).addBox(-4.5F, 5F, -4.5F, 9F, 1F, 9F, new CubeDeformation(0.05F)), PartPose.offsetAndRotation(0.000F, 10.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_hand = p_left_forearm.addOrReplaceChild("left_hand", CubeListBuilder.create().texOffs(72, 79).addBox(-4F, 0F, -4F, 8F, 5F, 8F), PartPose.offsetAndRotation(0.000F, 11.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_finger_0 = p_left_hand.addOrReplaceChild("left_finger_0", CubeListBuilder.create().texOffs(104, 79).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(-2.700F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_finger_1 = p_left_hand.addOrReplaceChild("left_finger_1", CubeListBuilder.create().texOffs(114, 79).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(0.000F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_finger_2 = p_left_hand.addOrReplaceChild("left_finger_2", CubeListBuilder.create().texOffs(124, 79).addBox(-1F, 0F, -1F, 2F, 3F, 3F), PartPose.offsetAndRotation(2.700F, 5.000F, -2.500F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_thigh = p_pelvis.addOrReplaceChild("left_thigh", CubeListBuilder.create().texOffs(134, 79).addBox(-3.5F, 0F, -3.5F, 7F, 9F, 7F), PartPose.offsetAndRotation(4.500F, 1.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_shin = p_left_thigh.addOrReplaceChild("left_shin", CubeListBuilder.create().texOffs(162, 79).addBox(-3F, 0F, -3F, 6F, 8F, 6F).texOffs(186, 79).addBox(-3.5F, -1F, -4F, 7F, 3F, 3F), PartPose.offsetAndRotation(0.000F, 9.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        PartDefinition p_left_foot = p_left_shin.addOrReplaceChild("left_foot", CubeListBuilder.create().texOffs(206, 79).addBox(-3.5F, 0F, -5F, 7F, 2F, 8F), PartPose.offsetAndRotation(0.000F, 8.000F, 0.000F, 0.0000F, 0.0000F, 0.0000F));
        return LayerDefinition.create(mesh, 256, 128);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);
        float breathe = Mth.sin(age * 0.08F);
        float hurt = e.hurtTime > 0 ? Mth.sin((e.hurtTime - pt) / 10F * Mth.PI) : 0F;
        float death = e.deathTime > 0 ? Mth.clamp((e.deathTime + pt) / 40F, 0F, 1F) : 0F;
        float yawR = headYaw * Mth.DEG_TO_RAD, pitchR = headPitch * Mth.DEG_TO_RAD;

        this.head.yRot = yawR * 0.6F; this.head.xRot = pitchR * 0.5F;
        float walk = limbSwing * 0.45F, amt = Math.min(limbAmount, 1F);
        this.pelvis.y += Math.abs(Mth.sin(walk)) * -1.2F * amt + breathe * 0.3F;
        this.chest.zRot = Mth.sin(walk) * 0.08F * amt;
        this.chest.xRot += breathe * 0.03F - hurt * 0.25F;
        this.right_thigh.xRot = Mth.cos(walk) * 0.8F * amt;
        this.left_thigh.xRot = Mth.cos(walk + Mth.PI) * 0.8F * amt;
        this.right_shin.xRot = Math.max(0F, -Mth.cos(walk) * 0.9F) * amt;
        this.left_shin.xRot = Math.max(0F, Mth.cos(walk) * 0.9F) * amt;
        this.right_shoulder.xRot = Mth.cos(walk + Mth.PI) * 0.5F * amt;
        this.left_shoulder.xRot = Mth.cos(walk) * 0.5F * amt;
        this.right_forearm.xRot = -0.25F - Math.max(0F, Mth.cos(walk)) * 0.4F * amt;
        this.left_forearm.xRot = -0.25F - Math.max(0F, -Mth.cos(walk)) * 0.4F * amt;
        this.right_shoulder.zRot = 0.06F + breathe * 0.02F; this.left_shoulder.zRot = -0.06F - breathe * 0.02F;
        for (int i = 0; i < this.vines.length; i++) this.vines[i].xRot += Mth.sin(age * 0.07F + i * 0.6F) * 0.15F + amt * 0.3F;
        float glow = 1F + Mth.sin(age * 0.2F) * 0.15F;
        this.core.xScale = glow; this.core.yScale = glow;
        if (anim == 1 && at < 28) {            // FRAPPE SISMIQUE
            float up = at < 14 ? at / 14F : Mth.clamp(1F - (at - 14) / 3F, -0.4F, 1F);
            this.right_shoulder.xRot = -2.7F * up; this.left_shoulder.xRot = -2.7F * up;
            this.right_forearm.xRot = -0.6F * up; this.left_forearm.xRot = -0.6F * up;
            this.chest.xRot += -0.3F * up + (at > 14 ? 0.55F : 0F);
            if (at > 14) { this.right_thigh.xRot = -0.5F; this.left_thigh.xRot = -0.5F; this.right_shin.xRot = 0.8F; this.left_shin.xRot = 0.8F; this.pelvis.y += 3F; }
            this.jaw.xRot = 0.4F * Math.max(0F, up);
        } else if (anim == 2 && at < 16) {     // LANCER
            float k = at / 16F;
            this.right_shoulder.xRot = k < 0.5F ? -3.0F * (k * 2) : -3.0F + 4.0F * ((k - 0.5F) * 2);
            this.chest.yRot = (k < 0.5F ? 0.4F : -0.3F);
        } else if (anim == 3 && at < 34) {     // RUGISSEMENT
            float k = Mth.sin(Mth.clamp(at / 34F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.7F * k; this.jaw.xRot = 0.6F * k;
            this.right_shoulder.zRot = 1.1F * k; this.left_shoulder.zRot = -1.1F * k;
            this.chest.xRot -= 0.3F * k;
        }
        if (death > 0F) {                      // s'agenouille puis s'effondre
            this.pelvis.y += 9F * death;
            this.right_thigh.xRot = -1.4F * death; this.left_thigh.xRot = -1.4F * death;
            this.right_shin.xRot = 1.6F * death; this.left_shin.xRot = 1.6F * death;
            this.chest.xRot += 0.9F * death; this.head.xRot = 0.5F * death;
            this.right_shoulder.xRot = -0.4F * death; this.left_shoulder.xRot = -0.4F * death;
        }

    }
}
