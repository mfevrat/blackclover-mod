package com.blackclovermod.client;

import com.blackclovermod.ceremony.GrimoireTower;
import com.blackclovermod.cinematic.CinematicType;
import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * CINÉMATIQUES : on remplace la caméra du joueur par une entité invisible
 * que l'on déplace image par image le long d'une trajectoire.
 * Le joueur ne peut plus bouger pendant la cinématique ; la touche V permet de la passer.
 */
public final class CinematicManager {
    private static CinematicType type;
    private static int focusId = -1;
    private static int duration;
    private static int t;
    private static ArmorStand cam;
    private static Vec3 anchor = Vec3.ZERO;
    private static float startAngle;
    private static Vec3 point = Vec3.ZERO;

    public static boolean active() { return type != null; }
    public static int time() { return t; }
    public static int duration() { return duration; }
    public static CinematicType type() { return type; }

    public static void receive(int typeIndex, int focus, int dur, double px, double py, double pz) {
        point = new Vec3(px, py, pz);
        if (typeIndex < 0) { focusId = focus; return; }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        CinematicType newType = CinematicType.byIndex(typeIndex);
        // une cinématique de boss ne coupe pas la cérémonie
        if (type == CinematicType.CEREMONY && newType != CinematicType.CEREMONY) return;
        type = newType;
        focusId = focus;
        duration = dur;
        t = 0;
        Entity f = focusEntity();
        anchor = f != null ? f.position() : mc.player.position();
        Vec3 toPlayer = mc.player.position().subtract(anchor);
        startAngle = (float) Math.atan2(toPlayer.z, toPlayer.x);
        if (cam == null || cam.level() != mc.level) {
            cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
            cam.setInvisible(true);
            cam.setNoGravity(true);
        }
        place(true);
        mc.setCameraEntity(cam);
    }

    public static void stop() {
        Minecraft mc = Minecraft.getInstance();
        type = null;
        if (mc.player != null && mc.getCameraEntity() != mc.player) mc.setCameraEntity(mc.player);
    }

    /** Appelé à chaque tick client. */
    public static void tick() {
        if (type == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || cam == null || cam.level() != mc.level || !mc.player.isAlive()) {
            stop();
            return;
        }
        if (KeyBindings.SKIP.consumeClick() || ++t >= duration) {
            stop();
            return;
        }
        if (mc.getCameraEntity() != cam) mc.setCameraEntity(cam);
        place(false);
    }

    private static Entity focusEntity() {
        Minecraft mc = Minecraft.getInstance();
        return focusId >= 0 && mc.level != null ? mc.level.getEntity(focusId) : null;
    }

    private static float ease(float x) { x = Mth.clamp(x, 0f, 1f); return x * x * (3 - 2 * x); }

    /** Calcule la position et l'orientation de la caméra pour l'instant t. */
    private static void place(boolean snap) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer pl = mc.player;
        Entity focus = focusEntity();
        Vec3 pos;
        Vec3 look;

        switch (type) {
            case CEREMONY -> {
                Vec3 c = GrimoireTower.platformCenter();
                Vec3 eye = pl.getEyePosition();
                if (t < 70) {                 // plongée en spirale depuis le sommet de la tour
                    float k = ease(t / 70f);
                    double a = t * 0.035, r = Mth.lerp(k, 2.5, 11), y = Mth.lerp(k, 44, 6);
                    pos = c.add(Math.cos(a) * r, y, Math.sin(a) * r);
                    look = c.add(0, Mth.lerp(k, -10, 1.5), 0);
                } else if (t < 160 || focus == null) {   // ronde autour du joueur
                    double a = 70 * 0.035 + (t - 70) * 0.02;
                    pos = c.add(Math.cos(a) * 7, 3.2, Math.sin(a) * 7);
                    look = eye;
                } else if (t < 240) {         // on suit le grimoire qui descend
                    Vec3 b = focus.position().add(0, 0.3, 0);
                    Vec3 away = b.subtract(eye);
                    away = new Vec3(away.x, 0, away.z);
                    away = away.lengthSqr() < 1e-3 ? new Vec3(0, 0, 1) : away.normalize();
                    pos = b.add(away.scale(2.6)).add(0, 1.2, 0);
                    look = eye.add(b.subtract(eye).scale(0.3));
                } else if (t < 300) {         // gros plan de face, lent travelling avant
                    Vec3 b = focus.position().add(0, 0.3, 0);
                    Vec3 front = b.subtract(eye);
                    front = new Vec3(front.x, 0, front.z).normalize();
                    Vec3 side = new Vec3(-front.z, 0, front.x);
                    float k = ease((t - 240) / 60f);
                    double r = Mth.lerp(k, 3.4, 2.3);
                    pos = eye.add(front.scale(r * 0.85)).add(side.scale(r * 0.55)).add(0, 0.35, 0);
                    look = eye.add(b.subtract(eye).scale(0.45));
                } else {                      // la caméra s'éloigne et monte
                    float k = ease((t - 300) / 50f);
                    double a = startAngle + 1.2;
                    pos = eye.add(Math.cos(a) * Mth.lerp(k, 2.5, 7), Mth.lerp(k, 0.4, 5), Math.sin(a) * Mth.lerp(k, 2.5, 7));
                    look = eye;
                }
            }
            case BOSS_INTRO -> {
                Vec3 b = focus != null ? focus.position() : anchor;
                double h = focus != null ? focus.getBbHeight() : 3;
                float k = ease(t / (float) duration);
                double a = startAngle - 0.6 + k * 1.2;
                double r = Mth.lerp(k, 8, 5.5) * Math.max(1, h / 3.5);
                pos = b.add(Math.cos(a) * r, Mth.lerp(k, 0.4, h * 0.45), Math.sin(a) * r);
                look = b.add(0, h * (0.35 + 0.35 * k), 0);
            }
            case BOSS_PHASE -> {
                Vec3 b = focus != null ? focus.position() : anchor;
                double h = focus != null ? focus.getBbHeight() : 3;
                float k = ease(t / (float) duration);
                double a = startAngle;
                double r = Mth.lerp(k, 9, 4.5) * Math.max(1, h / 3.5);
                double shake = t > duration * 0.6 ? (Math.random() - 0.5) * 0.25 : 0;
                pos = b.add(Math.cos(a) * r + shake, h * 0.7 + shake, Math.sin(a) * r + shake);
                look = b.add(0, h * 0.8, 0);
            }
            case BOSS_DEATH -> {
                Vec3 b = focus != null ? focus.position() : anchor;
                double h = focus instanceof MagicBossEntity ? focus.getBbHeight() : 3;
                double a = startAngle + t * 0.03;
                pos = b.add(Math.cos(a) * 7 * Math.max(1, h / 3.5), h * 0.6 + t * 0.03, Math.sin(a) * 7 * Math.max(1, h / 3.5));
                look = b.add(0, h * 0.5, 0);
            }
            case DEPARTURE -> {                // orbite montante autour du joueur aspiré par la lumière
                Vec3 eye = pl.getEyePosition();
                float k = ease(t / (float) duration);
                double a = startAngle + 0.8 + k * 2.2;
                double r = Mth.lerp(k, 3.2, 6.5);
                pos = eye.add(Math.cos(a) * r, Mth.lerp(k, -0.8, 2.5), Math.sin(a) * r);
                look = eye.add(0, Mth.lerp(k, 0, 3), 0);
            }
            case ALTAR -> {                    // gros plan sur le joueur, puis plan large sur l'arène
                Vec3 eye = pl.getEyePosition();
                Vec3 toC = point.subtract(eye);
                Vec3 h = new Vec3(toC.x, 0, toC.z);
                h = h.lengthSqr() < 1e-3 ? new Vec3(0, 0, 1) : h.normalize();
                Vec3 side = new Vec3(-h.z, 0, h.x);
                if (t < 40) {
                    float k = ease(t / 40f);
                    pos = eye.add(h.scale(2.2)).add(side.scale(1.6)).add(0, Mth.lerp(k, -0.6, 0.2), 0);
                    look = eye.add(0, 0.6 * k, 0);
                } else {
                    float k = ease((t - 40) / 60f);
                    pos = eye.subtract(h.scale(Mth.lerp(k, 2, 6))).add(side.scale(Mth.lerp(k, 1.6, 4))).add(0, Mth.lerp(k, 0.5, 6), 0);
                    look = point.add(0, Mth.lerp(k, 0.5, 2.5), 0);
                }
            }
            default -> {                       // ULTIMATE : par-dessus l'épaule, puis recul
                float k = ease(t / (float) duration);
                Vec3 eye = pl.getEyePosition();
                Vec3 fwd = Vec3.directionFromRotation(0, pl.getYRot());
                Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
                pos = eye.subtract(fwd.scale(Mth.lerp(k, 1.8, 4.5))).add(right.scale(0.9)).add(0, Mth.lerp(k, 0.3, 1.8), 0);
                look = eye.add(fwd.scale(6));
            }
        }

        Vec3 d = look.subtract(pos);
        float yaw = (float) (Mth.atan2(d.z, d.x) * (180 / Math.PI)) - 90f;
        float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * (180 / Math.PI));
        double eyeH = cam.getEyeHeight();
        double nx = pos.x, ny = pos.y - eyeH, nz = pos.z;

        if (snap) {
            cam.setPos(nx, ny, nz);
            cam.xo = nx; cam.yo = ny; cam.zo = nz;
            cam.xOld = nx; cam.yOld = ny; cam.zOld = nz;
            cam.setYRot(yaw); cam.yRotO = yaw;
            cam.setXRot(pitch); cam.xRotO = pitch;
            cam.yHeadRot = yaw; cam.yHeadRotO = yaw;
        } else {
            cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ();
            cam.xOld = cam.xo; cam.yOld = cam.yo; cam.zOld = cam.zo;
            cam.yRotO = cam.getYRot(); cam.xRotO = cam.getXRot(); cam.yHeadRotO = cam.yHeadRot;
            float smoothYaw = cam.getYRot() + Mth.wrapDegrees(yaw - cam.getYRot());
            cam.setPos(nx, ny, nz);
            cam.setYRot(smoothYaw);
            cam.setXRot(pitch);
            cam.yHeadRot = smoothYaw;
        }
    }

    private CinematicManager() {}
}
