package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.item.GrimoireItem;
import com.blackclovermod.magic.ClientFxState;
import com.blackclovermod.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.BookModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Rendu ANIMÉ des objets du mod, dans l'inventaire, en main, au sol et dans les cadres.
 *  - Grimoire : vrai livre qui s'ouvre, tourne ses pages et se referme (pages qui s'emballent quand on lance un sort).
 *  - Autres objets : leur modèle 3D (fichier *_3d.json) avec une animation propre à chacun.
 */
public class ModItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static ModItemRenderer instance;
    private static final ResourceLocation COVER = BlackCloverMod.id("textures/entity/grimoire_book_cover.png");
    private static final ResourceLocation[] DETAIL = {
            BlackCloverMod.id("textures/entity/grimoire_book_3.png"),
            BlackCloverMod.id("textures/entity/grimoire_book_4.png"),
            BlackCloverMod.id("textures/entity/grimoire_book_5.png")};
    private BookModel book;

    public static ModItemRenderer get() {
        if (instance == null) {
            Minecraft mc = Minecraft.getInstance();
            instance = new ModItemRenderer();
        }
        return instance;
    }

    private ModItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    private static float time() {
        Minecraft mc = Minecraft.getInstance();
        long t = mc.level != null ? mc.level.getGameTime() : (System.currentTimeMillis() / 50L);
        return t + mc.getFrameTime();
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (stack.getItem() instanceof GrimoireItem) {
            renderGrimoire(stack, ctx, ps, buf, light, overlay);
        } else {
            renderAnimated(stack, ctx, ps, buf, light, overlay);
        }
    }

    // ------------------------------------------------------------------
    // GRIMOIRE
    // ------------------------------------------------------------------
    private void renderGrimoire(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (book == null) book = new BookModel(Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.BOOK));
        float t = time();
        Minecraft mc = Minecraft.getInstance();
        boolean inHand = ctx.firstPerson() || ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND || ctx == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
        boolean casting = inHand && mc.player != null && ClientFxState.get(mc.player.getId()) != null;

        float open;
        float flip;
        if (inHand) {
            open = casting ? 1f : 0.85f + Mth.sin(t * 0.05f) * 0.08f;
            flip = casting ? 0.35f : 0.03f;
        } else if (ctx == ItemDisplayContext.GUI) {
            // cycle de 160 ticks : fermé -> s'ouvre -> pages qui tournent -> se referme
            float c = (t % 160f) / 160f;
            open = c < 0.55f ? 0f : c < 0.65f ? (c - 0.55f) / 0.1f : c < 0.9f ? 1f : 1f - (c - 0.9f) / 0.1f;
            open = Mth.clamp(open, 0f, 1f) * 0.9f;
            flip = 0.12f;
        } else {
            open = 0.6f + Mth.sin(t * 0.07f) * 0.25f;
            flip = 0.06f;
        }

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        if (ctx == ItemDisplayContext.GUI || ctx == ItemDisplayContext.GROUND || ctx == ItemDisplayContext.FIXED) {
            ps.translate(0, Mth.sin(t * 0.1f) * 0.03f, 0);
        }
        float s = inHand ? 1.35f : 1.45f;
        ps.scale(s, -s, -s);                               // le modèle de livre est dessiné "tête en bas" : on le redresse
        if (inHand) {
            ps.mulPose(Axis.YP.rotationDegrees(180f));     // reliure verticale, pages ouvertes face à la caméra
        } else {
            ps.mulPose(Axis.YP.rotationDegrees(90f));      // couverture tournée vers nous
        }
        // centrer le livre selon son ouverture (fermé, il dépasse d'un côté de la reliure)
        ps.translate(-0.19 * (1f - open), 0, 0);

        float f1 = Mth.frac(t * flip + 0.25f) * 1.6f - 0.3f;
        float f2 = Mth.frac(t * flip + 0.75f) * 1.6f - 0.3f;
        book.setupAnim(t, Mth.clamp(f1, 0f, 1f), Mth.clamp(f2, 0f, 1f), open);

        int leaves = GrimoireItem.leaves(stack);
        int c = GrimoireItem.color(stack);
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        int l = casting ? LightTexture.FULL_BRIGHT : light;
        book.renderToBuffer(ps, buf.getBuffer(RenderType.entityCutoutNoCull(COVER)), l, overlay, r, g, b, 1f);
        book.renderToBuffer(ps, ItemRenderer.getFoilBufferDirect(buf, RenderType.entityCutoutNoCull(DETAIL[Mth.clamp(leaves - 3, 0, 2)]), false, stack.hasFoil()),
                l, overlay, 1f, 1f, 1f, 1f);
        ps.popPose();
    }

    // ------------------------------------------------------------------
    // AUTRES OBJETS
    // ------------------------------------------------------------------
    private void renderAnimated(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        Item item = stack.getItem();
        ResourceLocation key = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item);
        if (key == null) return;
        BakedModel model = Minecraft.getInstance().getModelManager().getModel(BlackCloverMod.id("item/" + key.getPath() + "_3d"));
        float t = time();
        int l = light;

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        if (item == ModItems.MANA_CRYSTAL.get()) {                 // tourne sur lui-même et brille
            ps.translate(0, Mth.sin(t * 0.1f) * 0.04f, 0);
            ps.mulPose(Axis.YP.rotationDegrees(t * 3f));
            l = pulse(light, t, 0.15f);
        } else if (item == ModItems.DEMON_HEART.get()) {           // bat comme un cœur (double battement)
            float beat = heartbeat(t);
            ps.scale(1f + beat * 0.12f, 1f + beat * 0.12f, 1f + beat * 0.12f);
            ps.mulPose(Axis.ZP.rotationDegrees(beat * 3f));
            l = beat > 0.5f ? LightTexture.FULL_BRIGHT : light;
        } else if (item == ModItems.ELF_TEAR.get()) {              // flotte et scintille
            ps.translate(0, Mth.sin(t * 0.08f) * 0.05f, 0);
            float sc = 1f + Mth.sin(t * 0.2f) * 0.04f;
            ps.scale(sc, sc, sc);
            ps.mulPose(Axis.YP.rotationDegrees(Mth.sin(t * 0.03f) * 25f));
            l = LightTexture.FULL_BRIGHT;
        } else if (item == ModItems.DUNGEON_KEY.get()) {           // se balance
            ps.mulPose(Axis.ZP.rotationDegrees(Mth.sin(t * 0.09f) * 10f));
            l = pulse(light, t, 0.08f);
        } else if (item == ModItems.DEMON_FRAGMENT.get()) {        // tourne en tremblant
            ps.mulPose(Axis.YP.rotationDegrees(t * 1.5f));
            ps.translate((Math.random() - 0.5) * 0.01, (Math.random() - 0.5) * 0.01, 0);
            l = pulse(light, t, 0.2f);
        } else if (item == ModItems.ANCIENT_PAGE.get()) {          // la page ondule
            ps.mulPose(Axis.XP.rotationDegrees(Mth.sin(t * 0.12f) * 8f));
            ps.mulPose(Axis.YP.rotationDegrees(Mth.sin(t * 0.07f) * 10f));
        } else if (item == ModItems.TOWER_SUMMONS.get()) {         // le parchemin oscille, le sceau luit
            ps.translate(0, Mth.sin(t * 0.1f) * 0.02f, 0);
            ps.mulPose(Axis.ZP.rotationDegrees(Mth.sin(t * 0.06f) * 5f));
        }
        ps.translate(-0.5, -0.5, -0.5);
        Minecraft.getInstance().getItemRenderer().renderModelLists(model, stack, l, overlay, ps,
                ItemRenderer.getFoilBufferDirect(buf, Sheets.cutoutBlockSheet(), true, stack.hasFoil()));
        ps.popPose();
    }

    /** Fait varier la luminosité (effet "lueur" qui respire). */
    private static int pulse(int light, float t, float speed) {
        float k = (Mth.sin(t * speed) + 1f) * 0.5f;
        int block = Math.max(LightTexture.block(light), (int) (k * 15));
        return LightTexture.pack(block, LightTexture.sky(light));
    }

    /** Courbe d'un battement de cœur : deux coups rapides puis une pause. */
    private static float heartbeat(float t) {
        float c = (t % 24f) / 24f;
        if (c < 0.1f) return Mth.sin(c / 0.1f * Mth.PI);
        if (c > 0.18f && c < 0.28f) return Mth.sin((c - 0.18f) / 0.1f * Mth.PI) * 0.7f;
        return 0f;
    }
}
