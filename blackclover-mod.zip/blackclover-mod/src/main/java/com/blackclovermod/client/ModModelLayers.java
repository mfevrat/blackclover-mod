package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.magic.KnightOrder;
import net.minecraft.client.model.geom.ModelLayerLocation;

import java.util.EnumMap;
import java.util.Map;

public final class ModModelLayers {
    public static final ModelLayerLocation DUNGEON_GUARDIAN = new ModelLayerLocation(BlackCloverMod.id("dungeon_guardian"), "main");
    public static final ModelLayerLocation ELF_KING = new ModelLayerLocation(BlackCloverMod.id("elf_king"), "main");
    public static final ModelLayerLocation CREATOR = new ModelLayerLocation(BlackCloverMod.id("creator"), "main");
    public static final ModelLayerLocation ARCHDEMON = new ModelLayerLocation(BlackCloverMod.id("archdemon"), "main");

    private static final Map<KnightOrder, ModelLayerLocation> ARMOR = new EnumMap<>(KnightOrder.class);

    public static ModelLayerLocation armor(KnightOrder o) {
        return ARMOR.computeIfAbsent(o, k -> new ModelLayerLocation(BlackCloverMod.id("armor_" + k.id), "main"));
    }

    private ModModelLayers() {}
}
