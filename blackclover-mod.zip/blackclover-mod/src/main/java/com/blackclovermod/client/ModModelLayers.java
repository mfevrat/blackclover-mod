package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import net.minecraft.client.model.geom.ModelLayerLocation;

public final class ModModelLayers {
    public static final ModelLayerLocation DUNGEON_GUARDIAN = new ModelLayerLocation(BlackCloverMod.id("dungeon_guardian"), "main");
    public static final ModelLayerLocation ELF_KING = new ModelLayerLocation(BlackCloverMod.id("elf_king"), "main");
    public static final ModelLayerLocation ARCHDEMON = new ModelLayerLocation(BlackCloverMod.id("archdemon"), "main");

    private ModModelLayers() {}
}
