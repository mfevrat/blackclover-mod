package com.blackclovermod.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** Particule magique : animée, qui s'estompe, et qui brille dans le noir selon son style. */
public class MagicParticle extends TextureSheetParticle {
    public enum Style {
        //        couleur début      couleur fin       vie  taille  gravité  brille  animée  tourne
        FIRE   (0xFFE08A, 0xE0300E, 18, 1.0f, -0.010f, true,  true,  false),
        WATER  (0x9FD8FF, 0x2F7BFF, 22, 0.7f,  0.050f, true,  false, false),
        WIND   (0xF0FFF6, 0x8CFFC1, 12, 1.1f,  0.000f, true,  true,  false),
        LIGHTNING(0xFFFFFF, 0xFFE93B, 6, 1.0f, 0.000f, true,  true,  true),
        DARK   (0x8A40D0, 0x1A0A26, 26, 1.2f, -0.004f, false, true,  true),
        LIGHT  (0xFFFFFF, 0xFFE27A, 20, 0.8f,  0.000f, true,  false, true),
        THORN  (0xF4A6C8, 0x3FA34D, 34, 0.7f,  0.012f, false, false, true),
        ANTI   (0x2A2228, 0x0A0808, 32, 0.9f, -0.006f, false, true,  true),
        RUNE   (0x90F0FF, 0x2EA8FF, 34, 0.9f, -0.008f, true,  false, false),
        EARTH  (0x9A9488, 0x5E584F, 28, 0.8f,  0.050f, false, false, true);

        final int c0, c1, life; final float size, gravity; final boolean glow, animated, spin;
        Style(int c0, int c1, int life, float size, float gravity, boolean glow, boolean animated, boolean spin) {
            this.c0 = c0; this.c1 = c1; this.life = life; this.size = size; this.gravity = gravity;
            this.glow = glow; this.animated = animated; this.spin = spin;
        }
    }

    private final SpriteSet sprites;
    private final Style style;
    private final float baseSize;
    private final float spinSpeed;

    protected MagicParticle(ClientLevel level, double x, double y, double z, double dx, double dy, double dz, SpriteSet sprites, Style style) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.style = style;
        this.xd = dx; this.yd = dy; this.zd = dz;
        this.lifetime = (int) (style.life * (0.75f + random.nextFloat() * 0.5f));
        this.baseSize = 0.12f * style.size * (0.8f + random.nextFloat() * 0.5f);
        this.quadSize = baseSize;
        this.gravity = style.gravity;
        this.friction = 0.9f;
        this.hasPhysics = style == Style.WATER || style == Style.EARTH;
        this.spinSpeed = style.spin ? (random.nextFloat() - 0.5f) * 0.3f : 0f;
        this.roll = random.nextFloat() * Mth.TWO_PI;
        this.oRoll = roll;
        if (style.animated) setSpriteFromAge(sprites); else pickSprite(sprites);
        applyColor(0f);
    }

    private void applyColor(float k) {
        int a = style.c0, b = style.c1;
        setColor(Mth.lerp(k, ((a >> 16) & 255) / 255f, ((b >> 16) & 255) / 255f),
                Mth.lerp(k, ((a >> 8) & 255) / 255f, ((b >> 8) & 255) / 255f),
                Mth.lerp(k, (a & 255) / 255f, (b & 255) / 255f));
    }

    @Override
    public void tick() {
        super.tick();
        if (!isAlive()) return;
        float k = age / (float) lifetime;
        oRoll = roll;
        roll += spinSpeed;
        applyColor(k);
        alpha = k < 0.15f ? k / 0.15f : 1f - Mth.clamp((k - 0.6f) / 0.4f, 0f, 1f);
        switch (style) {
            case LIGHT -> quadSize = baseSize * (0.7f + 0.5f * Mth.abs(Mth.sin(age * 0.5f)));   // scintille
            case DARK, ANTI -> quadSize = baseSize * (1f + k * 0.8f);                           // s'étend comme une fumée
            case LIGHTNING -> { pickSprite(sprites); quadSize = baseSize * (0.8f + random.nextFloat() * 0.5f); }
            default -> quadSize = baseSize * (1f - k * 0.5f);
        }
        if (style.animated && style != Style.LIGHTNING) setSpriteFromAge(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return style.glow ? 0xF000F0 : super.getLightColor(partialTick);
    }

    public record Provider(SpriteSet sprites, Style style) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double dx, double dy, double dz) {
            return new MagicParticle(level, x, y, z, dx, dy, dz, sprites, style);
        }
    }
}
