package com.blackclovermod.client;

import com.blackclovermod.magic.PlayerAnimState;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

/**
 * Modèle du joueur capable de jouer les poses scénarisées du mod
 * (ascension vers la Tour, atterrissage, réception du grimoire, rituel, invocation d'épée...).
 * Les armures et la cape suivent automatiquement la pose.
 */
public class AnimatedPlayerModel extends PlayerModel<AbstractClientPlayer> {

    public AnimatedPlayerModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    private static float ease(float x) { x = Mth.clamp(x, 0f, 1f); return x * x * (3 - 2 * x); }

    @Override
    public void setupAnim(AbstractClientPlayer p, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
        super.setupAnim(p, limbSwing, limbAmount, age, headYaw, headPitch);
        // la main en vue 1re personne appelle setupAnim avec des zéros : on ne la touche pas
        if (limbSwing == 0 && limbAmount == 0 && age == 0 && headYaw == 0 && headPitch == 0) return;
        PlayerAnimState.Active a = PlayerAnimState.get(p.getId());
        if (a == null) return;
        float t = a.ticks();
        float dur = Math.max(1f, a.duration());
        float fadeOut = Mth.clamp((dur - t) / 6f, 0f, 1f);
        float in = ease(t / 8f) * fadeOut;

        switch (a.type()) {
            case PlayerAnimState.ASCEND -> {        // s'élève, bras écartés vers le ciel, tête en arrière
                float k = ease(t / dur);
                rightArm.xRot = -0.3f * in; leftArm.xRot = -0.3f * in;
                rightArm.zRot = (0.3f + 2.0f * k) * in; leftArm.zRot = -(0.3f + 2.0f * k) * in;
                head.xRot = -0.6f * in; body.xRot = -0.12f * in;
                rightLeg.xRot = 0.15f * in; leftLeg.xRot = 0.15f * in;
                rightLeg.zRot = 0.04f; leftLeg.zRot = -0.04f;
            }
            case PlayerAnimState.LANDING -> {       // descente puis atterrissage "super-héros"
                if (t < 40) {
                    float k = in;
                    rightLeg.xRot = -0.5f * k; leftLeg.xRot = 0.2f * k;
                    rightArm.zRot = 1.2f * k; leftArm.zRot = -1.2f * k;
                    head.xRot = 0.35f * k;
                } else {
                    float k = Mth.clamp(1f - (t - 48) / 12f, 0f, 1f) * fadeOut; // tient la pose puis se relève
                    float down = 4f * k;
                    head.y += down; body.y += down; rightArm.y += down; leftArm.y += down;
                    rightLeg.y += down; leftLeg.y += down;
                    rightLeg.xRot = -1.35f * k; leftLeg.xRot = 0.95f * k;
                    body.xRot = 0.45f * k; head.xRot = -0.2f * k;
                    rightArm.xRot = -0.25f * k; rightArm.zRot = 0.1f;
                    leftArm.xRot = 0.6f * k; leftArm.zRot = -0.9f * k;
                }
            }
            case PlayerAnimState.AWAIT -> {         // regarde autour de lui, mains légèrement ouvertes
                rightArm.zRot = 0.35f * in + Mth.sin(t * 0.08f) * 0.05f;
                leftArm.zRot = -0.35f * in - Mth.sin(t * 0.08f) * 0.05f;
                rightArm.xRot = -0.25f * in; leftArm.xRot = -0.25f * in;
                head.yRot += Mth.sin(t * 0.04f) * 0.5f * in;
                head.xRot += (-0.35f + Mth.sin(t * 0.06f) * 0.15f) * in;
            }
            case PlayerAnimState.RECEIVE -> {       // tend les deux mains vers le grimoire
                rightArm.xRot = -1.35f * in; leftArm.xRot = -1.35f * in;
                rightArm.yRot = -0.28f * in; leftArm.yRot = 0.28f * in;
                rightArm.zRot = 0f; leftArm.zRot = 0f;
                head.xRot = 0.15f * in;
            }
            case PlayerAnimState.TRIUMPH -> {       // poing levé vers le ciel
                rightArm.xRot = -3.0f * in; rightArm.zRot = -0.15f * in;
                leftArm.zRot = -0.5f * in;
                head.xRot = -0.45f * in; body.xRot = -0.08f * in;
            }
            case PlayerAnimState.RITUAL -> {        // lève l'offrande au-dessus de la tête, puis l'abat vers l'autel
                if (t < 60) {
                    rightArm.xRot = -2.9f * in; leftArm.xRot = -2.9f * in;
                    rightArm.zRot = 0.18f; leftArm.zRot = -0.18f;
                    head.xRot = -0.5f * in;
                } else {
                    float k = ease((t - 60) / 10f);
                    rightArm.xRot = Mth.lerp(k, -2.9f, -1.1f) * fadeOut; leftArm.xRot = Mth.lerp(k, -2.9f, -1.1f) * fadeOut;
                    body.xRot = 0.35f * k * fadeOut; head.xRot = 0.2f * k * fadeOut;
                    rightLeg.xRot = -0.3f * k * fadeOut; leftLeg.xRot = 0.3f * k * fadeOut;
                }
            }
            case PlayerAnimState.SWORD_SUMMON -> {  // tend le bras au ciel, saisit l'épée, l'abat
                if (t < 10) {
                    rightArm.xRot = -3.0f * in; rightArm.zRot = -0.1f;
                    head.xRot = -0.4f * in; leftArm.zRot = -0.6f * in;
                } else {
                    float k = ease((t - 10) / 6f);
                    rightArm.xRot = Mth.lerp(k, -3.0f, -0.9f) * fadeOut;
                    rightArm.yRot = -0.3f * k * fadeOut;
                    body.yRot = -0.25f * k * fadeOut;
                    leftArm.zRot = -0.6f * fadeOut;
                }
            }
            case PlayerAnimState.CAST -> {          // pousse les deux mains vers l'avant
                rightArm.xRot = -1.55f * in + head.xRot; leftArm.xRot = -1.55f * in + head.xRot;
                rightArm.yRot = -0.15f + head.yRot; leftArm.yRot = 0.15f + head.yRot;
                rightLeg.xRot = -0.35f * in; leftLeg.xRot = 0.35f * in;
            }
            default -> {}
        }
        hat.copyFrom(head);
        jacket.copyFrom(body);
        rightSleeve.copyFrom(rightArm);
        leftSleeve.copyFrom(leftArm);
        rightPants.copyFrom(rightLeg);
        leftPants.copyFrom(leftLeg);
    }
}
