package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.entity.boss.MagicBossEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Rendu des boss avec leur modèle 3D original + calque lumineux.
 * Une texture (et un calque lumineux) par phase : le design change quand le boss se transforme.
 * Pendant l'apparition : surgit du sol, descend du ciel ou s'assemble selon le boss.
 */
public class ModelBossRenderer<T extends MagicBossEntity, M extends HierarchicalModel<T>> extends MobRenderer<T, M> {
    private final ResourceLocation[] textures;
    private final ResourceLocation[] glows;
    private final float baseScale;

    /** name = nom de base de la texture ; phases = nombre de designs (une texture par phase). */
    public ModelBossRenderer(EntityRendererProvider.Context ctx, M model, String name, int phases, float scale) {
        super(ctx, model, 0.6f * scale);
        this.textures = new ResourceLocation[phases];
        this.glows = new ResourceLocation[phases];
        for (int i = 0; i < phases; i++) {
            String suffix = i == 0 ? "" : "_p" + (i + 1);
            textures[i] = BlackCloverMod.id("textures/entity/" + name + suffix + ".png");
            glows[i] = BlackCloverMod.id("textures/entity/" + name + suffix + "_glow.png");
        }
        this.baseScale = scale;
        addLayer(new GlowPhaseLayer());
    }

    /** Calque lumineux (yeux, runes, cristaux...) qui suit la phase du boss. */
    private class GlowPhaseLayer extends RenderLayer<T, M> {
        GlowPhaseLayer() {
            super(ModelBossRenderer.this);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, T e, float limbSwing, float limbAmount,
                           float partialTick, float age, float headYaw, float headPitch) {
            getParentModel().renderToBuffer(ps, buf.getBuffer(RenderType.eyes(glows[index(e)])), 0xF00000,
                    OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
        }
    }

    private int index(T e) {
        return Math.max(0, Math.min(textures.length - 1, e.phase() - 1));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return textures[index(entity)];
    }

    /** Pas de bascule sur le côté à la mort : le modèle joue sa propre animation d'effondrement. */
    @Override
    protected float getFlipDegrees(T entity) {
        return 0f;
    }

    @Override
    protected void scale(T entity, PoseStack ps, float partialTick) {
        float s = baseScale * entity.renderScaleMultiplier();
        ps.scale(s, s, s);
    }

    @Override
    public void render(T entity, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        int st = entity.spawnTicks();
        if (st > 0) {
            float prog = Math.max(0f, (st - partialTick) / MagicBossEntity.SPAWN_DURATION);
            switch (entity.spawnStyle()) {
                case 1 -> {                       // descend du ciel en planant
                    float e = prog * prog;
                    ps.translate(0, e * 16.0, 0);
                    ps.mulPose(Axis.YP.rotationDegrees(e * 360f));
                }
                case 2 -> {                       // invisible tant que les rochers ne sont pas assemblés
                    if (st > 22) {
                        ps.popPose();
                        return;
                    }
                    float s = 0.6f + 0.4f * (1f - (st - partialTick) / 22f);
                    ps.scale(s, s, s);
                }
                default -> ps.translate(0, -prog * 3.0 * baseScale, 0);  // surgit du sol
            }
        }
        super.render(entity, yaw, partialTick, ps, buf, light);
        ps.popPose();
    }
}
