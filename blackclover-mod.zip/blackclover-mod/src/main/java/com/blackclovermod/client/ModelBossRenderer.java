package com.blackclovermod.client;

import com.blackclovermod.entity.boss.MagicBossEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Rendu des boss avec leur modèle 3D original + calque lumineux.
 * Pendant l'apparition, le boss est dessiné plus bas : il "sort du sol".
 */
public class ModelBossRenderer<T extends MagicBossEntity, M extends HierarchicalModel<T>> extends MobRenderer<T, M> {
    private final ResourceLocation texture;
    private final float baseScale;

    public ModelBossRenderer(EntityRendererProvider.Context ctx, M model, ResourceLocation texture, ResourceLocation glow, float scale) {
        super(ctx, model, 0.6f * scale);
        this.texture = texture;
        this.baseScale = scale;
        if (glow != null) addLayer(new GlowLayer<>(this, glow));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, PoseStack ps, float partialTick) {
        float s = baseScale * entity.renderScaleMultiplier();
        ps.scale(s, s, s);
    }

    @Override
    public void render(T entity, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        int st = entity.spawnTicks();
        if (st > 0) {
            float prog = Math.max(0f, (st - partialTick) / MagicBossEntity.SPAWN_DURATION);
            ps.translate(0, -prog * 3.0 * baseScale, 0);
        }
        super.render(entity, yaw, partialTick, ps, buf, light);
        ps.popPose();
    }
}
