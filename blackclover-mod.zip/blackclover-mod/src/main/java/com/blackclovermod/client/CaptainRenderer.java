package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.order.CaptainEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Rendu des capitaines : apparence propre à chacun + tenue 3D de leur ordre + main levée pendant l'examen. */
public class CaptainRenderer extends HumanoidMobRenderer<CaptainEntity, CaptainRenderer.CaptainModel> {

    public static class CaptainModel extends HumanoidModel<CaptainEntity> {
        public CaptainModel(ModelPart root) { super(root); }

        @Override
        public void setupAnim(CaptainEntity e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
            super.setupAnim(e, limbSwing, limbAmount, age, headYaw, headPitch);
            rightArm.zRot = 0.05f; leftArm.zRot = -0.05f;
            rightArm.xRot = Mth.sin(age * 0.05f) * 0.05f; leftArm.xRot = -rightArm.xRot;
            if (e.isRaised()) {                       // le capitaine lève la main : "je le veux dans mon ordre !"
                rightArm.xRot = -2.9f + Mth.sin(age * 0.2f) * 0.05f;
                rightArm.zRot = -0.15f;
                head.xRot = -0.15f;
            }
        }
    }

    public CaptainRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new CaptainModel(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
        addLayer(new HumanoidArmorLayer<>(this, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(CaptainEntity e) {
        return BlackCloverMod.id("textures/entity/captain/" + e.order().id + ".png");
    }
}
