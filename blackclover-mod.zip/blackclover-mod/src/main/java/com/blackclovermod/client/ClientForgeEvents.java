package com.blackclovermod.client;

import com.blackclovermod.BlackCloverMod;
import com.blackclovermod.magic.ClientMagicData;
import com.blackclovermod.network.CastSpellPacket;
import com.blackclovermod.network.CycleSpellPacket;
import com.blackclovermod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BlackCloverMod.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private static final ResourceLocation CINE = BlackCloverMod.id("cinematic");

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            if (CinematicManager.active()) CinematicManager.stop();
            return;
        }
        CinematicManager.tick();
        boolean locked = CinematicManager.active();
        while (KeyBindings.CAST.consumeClick()) if (!locked) ModNetwork.toServer(new CastSpellPacket());
        while (KeyBindings.CYCLE.consumeClick()) if (!locked) ModNetwork.toServer(new CycleSpellPacket());
        if (!locked) while (KeyBindings.SKIP.consumeClick()) { /* rien à passer */ }
        ClientMagicData.tick();
    }

    /** Pendant une cinématique, le joueur ne bouge pas. */
    @SubscribeEvent
    public static void onInput(MovementInputUpdateEvent e) {
        if (!CinematicManager.active()) return;
        e.getInput().forwardImpulse = 0;
        e.getInput().leftImpulse = 0;
        e.getInput().up = e.getInput().down = e.getInput().left = e.getInput().right = false;
        e.getInput().jumping = false;
        e.getInput().shiftKeyDown = false;
    }

    /** Pas de main en premier plan pendant une cinématique. */
    @SubscribeEvent
    public static void onHand(RenderHandEvent e) {
        if (CinematicManager.active()) e.setCanceled(true);
    }

    /** On cache l'interface (sauf titres, barre d'action et nos bandes noires). */
    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Pre e) {
        if (!CinematicManager.active()) return;
        ResourceLocation id = e.getOverlay().id();
        if (id.equals(CINE) || id.equals(VanillaGuiOverlay.TITLE_TEXT.id()) || id.equals(VanillaGuiOverlay.RECORD_OVERLAY.id())
                || id.equals(VanillaGuiOverlay.CHAT_PANEL.id())) return;
        e.setCanceled(true);
    }

    private ClientForgeEvents() {}
}
