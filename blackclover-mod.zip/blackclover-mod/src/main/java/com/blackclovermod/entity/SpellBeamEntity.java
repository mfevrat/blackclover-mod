package com.blackclovermod.entity;

import com.blackclovermod.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * Rayon d'énergie 3D (colonne de lumière, éclair géant, rayon démoniaque...). Purement visuel.
 * Part de sa position, dans la direction donnée par pitch/yaw (pitch 0 = vers le haut).
 */
public class SpellBeamEntity extends Entity {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> LENGTH = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> WIDTH = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> PITCH = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> YAW = SynchedEntityData.defineId(SpellBeamEntity.class, EntityDataSerializers.FLOAT);

    public SpellBeamEntity(EntityType<? extends SpellBeamEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public SpellBeamEntity(Level level, double x, double y, double z, float length, float width, int color, int life, float pitch, float yaw) {
        this(ModEntities.SPELL_BEAM.get(), level);
        setPos(x, y, z);
        entityData.set(LENGTH, length);
        entityData.set(WIDTH, width);
        entityData.set(COLOR, color);
        entityData.set(LIFE, life);
        entityData.set(PITCH, pitch);
        entityData.set(YAW, yaw);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(COLOR, 0xFFFFFF);
        entityData.define(LENGTH, 10f);
        entityData.define(WIDTH, 1f);
        entityData.define(LIFE, 20);
        entityData.define(PITCH, 0f);
        entityData.define(YAW, 0f);
    }

    public int getColor() { return entityData.get(COLOR); }
    public float getLength() { return entityData.get(LENGTH); }
    public float getWidth() { return entityData.get(WIDTH); }
    public int getLife() { return entityData.get(LIFE); }
    public float getBeamPitch() { return entityData.get(PITCH); }
    public float getBeamYaw() { return entityData.get(YAW); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount >= getLife()) discard();
    }

    @Override
    public boolean shouldBeSaved() { return false; }

    @Override
    public boolean shouldRenderAtSqrDistance(double d) { return d < 160 * 160; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
