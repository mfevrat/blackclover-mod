package com.blackclovermod.entity;

import com.blackclovermod.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * Cercle magique 3D (texture lumineuse qui tourne). Purement visuel.
 * pitch 0 = à plat au sol ; pitch 90 = vertical, face à "yaw".
 * style : 0 = arcane, 1 = trèfle (grimoire), 2 = démoniaque.
 */
public class MagicCircleEntity extends Entity {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RADIUS = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> STYLE = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> PITCH = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> YAW = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> FOLLOW = SynchedEntityData.defineId(MagicCircleEntity.class, EntityDataSerializers.INT);

    public MagicCircleEntity(EntityType<? extends MagicCircleEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public MagicCircleEntity(Level level, double x, double y, double z, float radius, int color, int life, int style, float pitch, float yaw) {
        this(ModEntities.MAGIC_CIRCLE.get(), level);
        setPos(x, y, z);
        entityData.set(RADIUS, radius);
        entityData.set(COLOR, color);
        entityData.set(LIFE, life);
        entityData.set(STYLE, style);
        entityData.set(PITCH, pitch);
        entityData.set(YAW, yaw);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(COLOR, 0xFFD54A);
        entityData.define(RADIUS, 1.5f);
        entityData.define(LIFE, 20);
        entityData.define(STYLE, 0);
        entityData.define(PITCH, 0f);
        entityData.define(YAW, 0f);
        entityData.define(FOLLOW, -1);
    }

    public int getColor() { return entityData.get(COLOR); }
    public void setColor(int c) { entityData.set(COLOR, c); }
    public float getRadius() { return entityData.get(RADIUS); }
    public int getLife() { return entityData.get(LIFE); }
    public int getStyle() { return entityData.get(STYLE); }
    public float getCirclePitch() { return entityData.get(PITCH); }
    public float getCircleYaw() { return entityData.get(YAW); }
    /** Le cercle suit une entité (ex. sous les pieds du lanceur). */
    public MagicCircleEntity follow(Entity e) { entityData.set(FOLLOW, e.getId()); return this; }

    @Override
    public void tick() {
        super.tick();
        int f = entityData.get(FOLLOW);
        if (f >= 0) {
            Entity t = level().getEntity(f);
            if (t != null) setPos(t.getX(), t.getY() + 0.05, t.getZ());
        }
        if (!level().isClientSide && tickCount >= getLife()) discard();
    }

    @Override
    public boolean shouldBeSaved() { return false; }

    @Override
    public boolean shouldRenderAtSqrDistance(double d) { return d < 128 * 128; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
