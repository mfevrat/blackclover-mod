package com.blackclovermod.entity;

import com.blackclovermod.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkHooks;

/** Rocher runique décoratif (apparition du Gardien) : déplacé par le serveur, dessiné comme un bloc qui tourne. */
public class RockShardEntity extends Entity {
    private static final EntityDataAccessor<BlockState> BLOCK = SynchedEntityData.defineId(RockShardEntity.class, EntityDataSerializers.BLOCK_STATE);
    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(RockShardEntity.class, EntityDataSerializers.FLOAT);
    private int life;

    public RockShardEntity(EntityType<? extends RockShardEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public RockShardEntity(Level level, BlockState state, float scale) {
        this(ModEntities.ROCK_SHARD.get(), level);
        entityData.set(BLOCK, state);
        entityData.set(SCALE, scale);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(BLOCK, Blocks.MOSSY_COBBLESTONE.defaultBlockState());
        entityData.define(SCALE, 1f);
    }

    public BlockState getBlock() { return entityData.get(BLOCK); }
    public float getScale() { return entityData.get(SCALE); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && ++life > 200) discard();
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
