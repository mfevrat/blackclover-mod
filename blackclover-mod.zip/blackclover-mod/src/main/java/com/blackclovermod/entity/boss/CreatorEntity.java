package com.blackclovermod.entity.boss;

import com.blackclovermod.entity.MagicProjectileEntity;
import com.blackclovermod.entity.ProjectileKind;
import com.blackclovermod.magic.MagicData;
import com.blackclovermod.magic.MagicElement;
import com.blackclovermod.registry.ModItems;
import com.blackclovermod.registry.ModParticles;
import com.blackclovermod.util.Fx;
import com.blackclovermod.util.TaskScheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/**
 * BOSS FINAL : LE CRÉATEUR — démon antique colossal qui règne sur l'End.
 * Phase 1 : pluie d'étoiles noires, main du Créateur, pics de création, parole originelle.
 * Phase 2 (50 %) "Révélation" : ailes déployées, trou noir, engeances.
 * Phase 3 (25 %) "Démon originel" : rayon d'annihilation balayant l'arène.
 * Il résiste à la magie (-40 %) ; l'anti-magie lui inflige double dégâts.
 */
public class CreatorEntity extends MagicBossEntity {
    private static final DustParticleOptions VOID = new DustParticleOptions(new Vector3f(0.6f, 0.3f, 1f), 2f);
    private int minionCooldown = 0;

    public CreatorEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.PURPLE);
        setNoGravity(true);
        bossEvent.setDarkenScreen(true);
        bossEvent.setCreateWorldFog(true);
        this.xpReward = 1000;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1500).add(Attributes.ARMOR, 16).add(Attributes.ARMOR_TOUGHNESS, 8)
                .add(Attributes.ATTACK_DAMAGE, 24).add(Attributes.MOVEMENT_SPEED, 0.3).add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 64);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 48f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    @Override public MagicElement bossElement() { return MagicElement.DARKNESS; }
    @Override public String bossId() { return "creator"; }
    @Override protected int maxPhase() { return 3; }
    @Override public int spawnStyle() { return 1; }
    @Override public float renderScaleMultiplier() { return phase() >= 3 ? 1.1f : 1f; }

    @Override
    protected void spawnEffects(ServerLevel l, int k) {
        Vec3 c = position();
        if (k == 0) {
            Fx.beam(l, c, 60f, 6f, 0x8A3AD0, SPAWN_DURATION, 0f, 0f);
            Fx.circle(l, c.add(0, 0.05, 0), 12f, 0xA050FF, SPAWN_DURATION + 20, 2);
            Fx.circle(l, c.add(0, 0.03, 0), 10f, 0x120814, SPAWN_DURATION + 40, 3);
            playSound(SoundEvents.WITHER_SPAWN, 4f, 0.5f);
        }
        float prog = 1f - k / (float) SPAWN_DURATION;
        double y = c.y + prog * prog * 16;
        l.sendParticles(ModParticles.DARK.get(), c.x, y + 4, c.z, 10, 3, 3, 3, 0.02);
        l.sendParticles(ModParticles.RUNE.get(), c.x, y + 4, c.z, 3, 4, 3, 4, 0.02);
        if (k % 20 == 0) playSound(SoundEvents.WARDEN_HEARTBEAT, 4f, 0.4f);
    }

    @Override
    protected void bossTick(ServerLevel l, @Nullable LivingEntity target) {
        if (minionCooldown > 0) minionCooldown--;
        if (tickCount % 2 == 0) l.sendParticles(ModParticles.DARK.get(), getX(), getY() + 2, getZ(), 2, 1.5, 2, 1.5, 0.01);
        if (phase() >= 3 && tickCount % 3 == 0) l.sendParticles(ModParticles.FIRE.get(), getX(), getY() + 7.5, getZ(), 2, 1.2, 0.3, 1.2, 0.02);
        if (target != null) {      // plane autour de sa cible, toujours en hauteur
            double a = tickCount * 0.01;
            Vec3 desired = target.position().add(Math.cos(a) * 12, 5, Math.sin(a) * 12);
            Vec3 diff = desired.subtract(position());
            setDeltaMovement(getDeltaMovement().scale(0.88).add(diff.lengthSqr() > 1 ? diff.normalize().scale(0.05) : diff.scale(0.02)));
            float yaw = (float) (Mth.atan2(target.getZ() - getZ(), target.getX() - getX()) * (180 / Math.PI)) - 90f;
            setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
        } else {
            setDeltaMovement(getDeltaMovement().scale(0.8));
        }
    }

    @Override
    protected int performAttack(ServerLevel l, LivingEntity target) {
        int ph = phase();
        int roll = random.nextInt(ph >= 3 ? 7 : ph >= 2 ? 6 : 4);
        if (roll == 5 && minionCooldown > 0) roll = 0;
        switch (roll) {
            case 0 -> starRain(l, target);
            case 1 -> handOfCreation(l, target);
            case 2 -> creationSpikes(l);
            case 3 -> primordialWord(l);
            case 4 -> blackHole(l, target);
            case 5 -> { spawnMinions(l, target); minionCooldown = 500; }
            default -> annihilationBeam(l, target);
        }
        return 45 - ph * 6;
    }

    /** Pluie d'étoiles noires. */
    private void starRain(ServerLevel l, LivingEntity target) {
        playAnim(1);
        Fx.circle(l, target.position().add(0, 20, 0), 12f, 0xA050FF, 90, 2);
        playSound(SoundEvents.WITHER_SHOOT, 3f, 0.4f);
        TaskScheduler.repeat(80, k -> {
            if (!isAlive() || !target.isAlive() || k % 2 != 0) return;
            Vec3 spot = Fx.groundAt(l, target.position().add(random.nextGaussian() * 7, 1, random.nextGaussian() * 7));
            Fx.circle(l, spot.add(0, 0.05, 0), 1.4f, 0xA050FF, 26, 2);
            MagicProjectileEntity m = fireAt(ProjectileKind.DEMON_ORB, 12f, 1.0f, spot.add(random.nextGaussian() * 3, 20, random.nextGaussian() * 3), spot, 1.3f);
            m.setSecondsOnFire(10);
        });
    }

    /** Main du Créateur : un immense cercle se dessine sous la cible, puis une main d'énergie s'abat. */
    private void handOfCreation(ServerLevel l, LivingEntity target) {
        Vec3 spot = Fx.groundAt(l, target.position().add(0, 1, 0));
        Fx.circle(l, spot.add(0, 0.05, 0), 4.5f, 0xFF60A0, 28, 2);
        playSound(SoundEvents.ELDER_GUARDIAN_CURSE, 2f, 0.5f);
        TaskScheduler.later(22, () -> {
            if (!isAlive()) return;
            playAnim(2);
            Fx.beam(l, spot.add(0, 20, 0), 20f, 5f, 0xC060FF, 10, 180f, 0f);
            Fx.burst(l, ParticleTypes.EXPLOSION_EMITTER, spot.add(0, 0.5, 0), 2, 1, 0);
            Fx.ringOut(l, VOID, spot.add(0, 0.2, 0), 1, 80, 1.0);
            for (LivingEntity e : victimsAt(spot, 4.5)) {
                strikeDamage(e, 25f);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 1.0, 0));
                e.hurtMarked = true;
            }
            Fx.sound(l, spot, SoundEvents.GENERIC_EXPLODE, 3f, 0.5f);
        });
    }

    /** Pics de création : des colonnes d'énergie jaillissent du sol sous chaque joueur. */
    private void creationSpikes(ServerLevel l) {
        playAnim(1);
        for (ServerPlayer p : nearbyPlayers(48)) {
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2 + random.nextDouble();
                Vec3 s = Fx.groundAt(l, p.position().add(i == 0 ? 0 : Math.cos(a) * 3, 1, i == 0 ? 0 : Math.sin(a) * 3));
                Fx.circle(l, s.add(0, 0.05, 0), 1.5f, 0xA050FF, 24, 0);
                TaskScheduler.later(18 + i * 3, () -> {
                    if (!isAlive()) return;
                    Fx.beam(l, s, 8f, 1.2f, 0xB070FF, 16, 0f, 0f);
                    for (LivingEntity e : victimsAt(s, 1.8)) { strikeDamage(e, 14f); e.setDeltaMovement(e.getDeltaMovement().add(0, 0.8, 0)); e.hurtMarked = true; }
                    Fx.sound(l, s, SoundEvents.AMETHYST_BLOCK_BREAK, 2f, 0.5f);
                });
            }
        }
    }

    /** Parole originelle : une malédiction frappe tous les joueurs proches. */
    private void primordialWord(ServerLevel l) {
        playAnim(3);
        Component word = Component.translatable("curse.blackclover.creator").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC);
        for (ServerPlayer p : nearbyPlayers(48)) {
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
            p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0));
            Fx.title(p, Component.literal(""), word, 5, 50, 15);
            TaskScheduler.repeat(20, k -> Fx.ring(l, VOID, p.position().add(0, 0.1 + k * 0.1, 0), 1.3, 16));
        }
        playSound(SoundEvents.ENDER_DRAGON_GROWL, 4f, 0.4f);
    }

    private void blackHole(ServerLevel l, LivingEntity target) {
        playAnim(1);
        Vec3 c = target.position().add(0, 2, 0);
        Fx.circle(l, c, 5f, 0x8A1A5A, 90, 2, 90f, -getYRot());
        TaskScheduler.repeat(90, k -> {
            if (!isAlive()) return;
            Fx.converge(l, ModParticles.DARK.get(), c, 10, 7);
            for (LivingEntity e : victimsAt(c, 14)) {
                e.setDeltaMovement(e.getDeltaMovement().add(c.subtract(e.position()).normalize().scale(0.1)));
                e.hurtMarked = true;
                if (k % 10 == 0 && e.distanceToSqr(c) < 6) strikeDamage(e, 8f);
            }
            if (k == 89) { Fx.burst(l, ParticleTypes.EXPLOSION_EMITTER, c, 2, 1, 0); for (LivingEntity e : victimsAt(c, 6)) strikeDamage(e, 14f); }
        });
    }

    private void spawnMinions(ServerLevel l, LivingEntity target) {
        playAnim(3);
        for (int i = 0; i < 3; i++) {
            Vex v = EntityType.VEX.create(l);
            if (v == null) continue;
            v.moveTo(getX() + (i - 1) * 3, getY() + 4, getZ(), 0f, 0f);
            v.setLimitedLife(700);
            v.setCustomName(Component.translatable("entity.blackclover.creator_spawn"));
            v.setTarget(target);
            l.addFreshEntity(v);
            Fx.burst(l, ModParticles.DARK.get(), v.position(), 30, 0.5, 0.05);
        }
    }

    /** Rayon d'annihilation (phase 3) : un rayon balaie l'arène pendant 3 secondes. */
    private void annihilationBeam(ServerLevel l, LivingEntity target) {
        playAnim(1);
        Vec3 eye = position().add(0, 6.5, 0);
        Vec3 toT = target.position().subtract(eye);
        float baseYaw = (float) Math.toDegrees(Math.atan2(toT.x, toT.z));
        playSound(SoundEvents.BEACON_POWER_SELECT, 4f, 0.5f);
        TaskScheduler.repeat(60, k -> {
            if (!isAlive()) return;
            float yaw = baseYaw - 70 + k * (140f / 60f);
            Vec3 dir = new Vec3(Math.sin(Math.toRadians(yaw)), -0.25, Math.cos(Math.toRadians(yaw))).normalize();
            if (k % 3 == 0) {
                float[] ang = Fx.beamAngles(dir);
                Fx.beam(l, eye, 32f, 2.2f, 0xFF4060, 4, ang[0], ang[1]);
            }
            if (k % 5 == 0) {
                for (LivingEntity e : victimsAt(eye, 34)) {
                    Vec3 rel = e.position().add(0, 1, 0).subtract(eye);
                    double along = rel.dot(dir);
                    if (along > 0 && rel.subtract(dir.scale(along)).length() < 2.5) strikeDamage(e, 9f);
                }
            }
        });
    }

    @Override
    protected void onPhaseChange(ServerLevel l, int phase) {
        playSound(phase == 2 ? SoundEvents.WITHER_SPAWN : SoundEvents.ENDER_DRAGON_GROWL, 4f, 0.5f);
        for (ServerPlayer p : nearbyPlayers(48)) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
        heal(getMaxHealth() * 0.03f);
    }

    @Override
    protected float modifyDamage(DamageSource source, float amount) {
        Entity attacker = source.getEntity();
        if (attacker instanceof Player p && MagicData.hasGrimoire(p) && MagicData.element(p) == MagicElement.ANTI) return amount * 2f;
        if (source.getDirectEntity() instanceof MagicProjectileEntity) return amount * 0.6f;
        return amount;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) { return false; }

    @Override
    protected void dropBossLoot() {
        spawnAtLocation(new ItemStack(ModItems.ORIGIN_HEART.get()));
        spawnAtLocation(new ItemStack(ModItems.ANCIENT_PAGE.get(), 5));
        spawnAtLocation(new ItemStack(ModItems.MANA_CRYSTAL.get(), 8));
        spawnAtLocation(new ItemStack(Items.NETHER_STAR, 2));
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.WARDEN_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.WITHER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENDER_DRAGON_DEATH; }
}
