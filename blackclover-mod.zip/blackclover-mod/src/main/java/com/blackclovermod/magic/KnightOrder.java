package com.blackclovermod.magic;

import com.blackclovermod.item.OrderArmorItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import org.jetbrains.annotations.Nullable;

/**
 * Les 5 ORDRES DE CHEVALIERS-MAGES (créations originales du mod).
 * Porter la capuche + la robe d'un même ordre donne son bonus.
 */
public enum KnightOrder {
    ONYX_RAVENS("onyx_ravens", 0x9B4DD6, Items.BLACK_WOOL),          // +25 % puissance des sorts
    AZURE_STAGS("azure_stags", 0x4F86D9, Items.BLUE_WOOL),           // +50 % régénération de mana
    SCARLET_PHOENIX("scarlet_phoenix", 0xE04A2A, Items.RED_WOOL),    // immunité au feu, -20 % de recharge
    JADE_SERPENTS("jade_serpents", 0x3FB56A, Items.GREEN_WOOL),      // Vitesse I, -20 % de coût en mana
    SILVER_OWLS("silver_owls", 0xC8CCD8, Items.WHITE_WOOL);          // Vision nocturne, +40 mana max

    public final String id;
    public final int color;
    public final Item wool;

    KnightOrder(String id, int color, Item wool) {
        this.id = id;
        this.color = color;
        this.wool = wool;
    }

    public MutableComponent displayName() {
        return Component.translatable("order.blackclover." + id).withStyle(s -> s.withColor(color));
    }

    public Component bonusText() {
        return Component.translatable("order.blackclover." + id + ".bonus").withStyle(ChatFormatting.GRAY);
    }

    /** L'ordre dont le joueur porte l'ensemble complet (capuche + robe), ou null. */
    @Nullable
    public static KnightOrder fullSet(Player p) {
        if (p.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof OrderArmorItem head
                && p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof OrderArmorItem chest
                && head.order == chest.order) return head.order;
        return null;
    }

    public static boolean isWearing(Player p, KnightOrder o) {
        return fullSet(p) == o;
    }
}
