package com.blackclovermod.magic;

import com.blackclovermod.registry.ModParticles;
import com.blackclovermod.item.AntiSwordItem;
import com.blackclovermod.util.Fx;
import com.blackclovermod.util.PlayerAnims;
import com.blackclovermod.util.TaskScheduler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * Invocation des épées d'anti-magie : l'épée remplace temporairement l'objet de la main du joueur.
 * L'objet d'origine est mis de côté et rendu quand l'épée retourne dans le grimoire
 * (après 30 s, si on la lâche, à la déconnexion ou à la mort).
 */
public final class AntiSwords {

    /** Animation complète : le grimoire s'ouvre, un cercle démoniaque apparaît, l'épée en sort et arrive dans la main. */
    public static boolean summonWithFx(ServerPlayer p, Item sword) {
        ServerLevel l = p.serverLevel();
        PlayerAnims.play(p, PlayerAnimState.SWORD_SUMMON, 22);
        Vec3 above = p.position().add(0, 3.2, 0);
        Fx.circle(l, above, 1.6f, 0xC01818, 14, 2);
        Fx.beam(l, above, 2.0f, 0.5f, 0xC01818, 10, 180f, 0f);
        TaskScheduler.repeat(10, k -> {
            Fx.converge(l, ModParticles.ANTI.get(), p.position().add(0, 2.6, 0), 5, 1.6);
            Fx.burst(l, MagicElement.ANTI.dust(2f), p.position().add(0, 2.6 + k * 0.05, 0), 3, 0.2, 0);
        });
        Fx.sound(l, p.position(), SoundEvents.WITHER_SHOOT, 0.6f, 0.5f);
        TaskScheduler.later(10, () -> {
            if (!p.isAlive()) return;
            give(p, sword);
            Fx.burst(l, ModParticles.ANTI.get(), p.position().add(0, 1.2, 0), 40, 0.4, 0.08);
            Fx.ringOut(l, MagicElement.ANTI.dust(2.2f), p.position().add(0, 0.2, 0), 0.6, 30, 0.4);
            Fx.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.5f);
            Fx.sound(l, p.position(), SoundEvents.ANVIL_LAND, 0.4f, 0.8f);
        });
        return true;
    }

    private static CompoundTag data(ServerPlayer p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains("PlayerPersisted", 10)) pd.put("PlayerPersisted", new CompoundTag());
        return pd.getCompound("PlayerPersisted");
    }

    public static void give(ServerPlayer p, Item sword) {
        dismiss(p, false);
        Inventory inv = p.getInventory();
        int slot = inv.selected;
        ItemStack prev = inv.getItem(slot);
        CompoundTag d = data(p);
        d.put("bc_SwordBackup", prev.save(new CompoundTag()));
        d.putInt("bc_SwordSlot", slot);
        ItemStack s = new ItemStack(sword);
        s.getOrCreateTag().putLong("Expire", p.level().getGameTime() + AntiSwordItem.LIFETIME);
        inv.setItem(slot, s);
    }

    /** Fait disparaître toutes les épées et rend l'objet mis de côté. */
    public static void dismiss(ServerPlayer p, boolean fx) {
        Inventory inv = p.getInventory();
        boolean had = false;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof AntiSwordItem) { inv.setItem(i, ItemStack.EMPTY); had = true; }
        }
        if (p.containerMenu.getCarried().getItem() instanceof AntiSwordItem) { p.containerMenu.setCarried(ItemStack.EMPTY); had = true; }
        ItemStack backup = takeBackup(p);
        if (!backup.isEmpty()) {
            int slot = data(p).getInt("bc_SwordSlot");
            if (inv.getItem(slot).isEmpty()) inv.setItem(slot, backup);
            else if (!inv.add(backup)) p.drop(backup, false);
        }
        if (had && fx) {
            Fx.burst(p.serverLevel(), ModParticles.ANTI.get(), p.position().add(0, 1, 0), 25, 0.3, 0.05);
            Fx.sound(p.level(), p.position(), SoundEvents.FIRE_EXTINGUISH, 0.6f, 0.6f);
        }
    }

    /** Retire et renvoie l'objet mis de côté (vide s'il n'y en a pas). */
    public static ItemStack takeBackup(ServerPlayer p) {
        CompoundTag d = data(p);
        if (!d.contains("bc_SwordBackup", 10)) return ItemStack.EMPTY;
        ItemStack s = ItemStack.of(d.getCompound("bc_SwordBackup"));
        d.remove("bc_SwordBackup");
        return s;
    }

    private AntiSwords() {}
}
