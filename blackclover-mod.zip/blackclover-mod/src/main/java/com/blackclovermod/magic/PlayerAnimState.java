package com.blackclovermod.magic;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Côté client : quelle pose scénarisée chaque joueur est en train de jouer. */
public final class PlayerAnimState {
    public static final int ASCEND = 0, LANDING = 1, AWAIT = 2, RECEIVE = 3, TRIUMPH = 4, RITUAL = 5, SWORD_SUMMON = 6, CAST = 7;

    public record Active(int type, long start, long end) {
        public float ticks() { return (System.currentTimeMillis() - start) / 50f; }
        public float duration() { return (end - start) / 50f; }
    }

    private static final Map<Integer, Active> MAP = new ConcurrentHashMap<>();

    public static void play(int entityId, int type, int ticks) {
        long now = System.currentTimeMillis();
        MAP.put(entityId, new Active(type, now, now + ticks * 50L));
    }

    public static Active get(int entityId) {
        Active a = MAP.get(entityId);
        if (a != null && System.currentTimeMillis() > a.end) { MAP.remove(entityId); return null; }
        return a;
    }

    private PlayerAnimState() {}
}
