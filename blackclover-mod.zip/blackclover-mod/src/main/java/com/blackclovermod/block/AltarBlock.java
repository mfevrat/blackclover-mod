package com.blackclovermod.block;

import com.blackclovermod.entity.boss.MagicBossEntity;
import com.blackclovermod.item.BossSummonItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.function.Supplier;

/**
 * Autel d'invocation, présent au cœur de chaque structure de boss.
 * Clic droit avec le bon objet → rituel → le boss apparaît au centre de l'arène (dans la direction de l'autel).
 */
public class AltarBlock extends HorizontalDirectionalBlock {
    private static final VoxelShape SHAPE = Shapes.or(Block.box(1, 0, 1, 15, 3, 15), Block.box(4, 3, 4, 12, 10, 12), Block.box(2, 10, 2, 14, 13, 14));
    private final Supplier<? extends EntityType<? extends MagicBossEntity>> boss;
    public final int color;

    public AltarBlock(Properties props, Supplier<? extends EntityType<? extends MagicBossEntity>> boss, int color) {
        super(props);
        this.boss = boss;
        this.color = color;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH));
    }

    public EntityType<? extends MagicBossEntity> bossType() { return boss.get(); }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof BossSummonItem summon)) {
            if (!level.isClientSide && hand == InteractionHand.MAIN_HAND)
                player.displayClientMessage(Component.translatable("msg.blackclover.altar_hint").withStyle(ChatFormatting.GRAY), true);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (summon.bossType() != bossType()) {
            player.displayClientMessage(Component.translatable("msg.blackclover.altar_wrong").withStyle(ChatFormatting.RED), true);
            return InteractionResult.FAIL;
        }
        if (AltarRitual.start((ServerLevel) level, pos, state.getValue(FACING), this, (ServerPlayer) player)) {
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.FAIL;
    }
}
