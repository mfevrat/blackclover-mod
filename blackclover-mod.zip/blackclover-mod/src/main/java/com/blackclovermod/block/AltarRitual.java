package com.blackclovermod.block;

import com.blackclovermod.entity.boss.MagicBossEntity;
import com.blackclovermod.util.Fx;
import com.blackclovermod.util.TaskScheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/**
 * Rituel d'invocation (5 secondes) :
 * l'autel s'allume, un immense cercle se dessine au centre de l'arène, quatre colonnes de lumière
 * s'élèvent une par une, l'énergie converge... puis le boss surgit du sol.
 */
public final class AltarRitual {
    public static final int DURATION = 100;
    private static final Set<BlockPos> ACTIVE = new HashSet<>();

    public static boolean start(ServerLevel l, BlockPos altar, Direction facing, AltarBlock block, ServerPlayer player) {
        if (l.getDifficulty() == Difficulty.PEACEFUL) {
            player.displayClientMessage(Component.translatable("msg.blackclover.peaceful").withStyle(ChatFormatting.RED), true);
            return false;
        }
        if (ACTIVE.contains(altar)) return false;
        Vec3 center = Fx.groundAt(l, Vec3.atBottomCenterOf(altar.relative(facing, 7)).add(0, 2, 0));
        if (!l.getEntitiesOfClass(MagicBossEntity.class, new AABB(center, center).inflate(48)).isEmpty()) {
            player.displayClientMessage(Component.translatable("msg.blackclover.altar_busy").withStyle(ChatFormatting.YELLOW), true);
            return false;
        }
        ACTIVE.add(altar.immutable());
        int col = block.color;
        Vec3 top = Vec3.atCenterOf(altar).add(0, 0.6, 0);
        Fx.circle(l, center.add(0, 0.05, 0), 8.5f, col, DURATION + 10, 2);
        Fx.beam(l, top, 30f, 0.7f, col, DURATION, 0f, 0f);
        Fx.sound(l, top, SoundEvents.BEACON_ACTIVATE, 3f, 0.6f);
        for (ServerPlayer p : l.getPlayers(p -> p.distanceToSqr(center) < 64 * 64)) {
            Fx.title(p, Component.literal(""), Component.translatable("msg.blackclover.ritual").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), 10, 60, 20);
        }
        Vec3[] corners = new Vec3[4];
        for (int i = 0; i < 4; i++) {
            double a = i * Math.PI / 2 + Math.PI / 4;
            corners[i] = Fx.groundAt(l, center.add(Math.cos(a) * 7, 2, Math.sin(a) * 7));
        }
        TaskScheduler.repeat(DURATION, t -> {
            if (t % 15 == 0 && t / 15 < 4) {                 // les colonnes s'allument une à une
                Vec3 c = corners[t / 15];
                Fx.beam(l, c, 18f, 1.2f, col, DURATION - t, 0f, 0f);
                Fx.circle(l, c.add(0, 0.05, 0), 1.6f, col, DURATION - t, 0);
                Fx.sound(l, c, SoundEvents.AMETHYST_BLOCK_CHIME, 2.5f, 0.5f + t * 0.01f);
            }
            Fx.converge(l, ParticleTypes.ENCHANT, center.add(0, 1, 0), 10, 6);
            if (t > 40) Fx.converge(l, ParticleTypes.END_ROD, center.add(0, 1, 0), 3, 5);
            if (t % 20 == 0) Fx.sound(l, center, SoundEvents.WARDEN_HEARTBEAT, 3f, 0.5f + t * 0.005f);
            Fx.line(l, ParticleTypes.ENCHANT, top, center.add(0, 1, 0), 0.6);
            if (t == DURATION - 1) {
                ACTIVE.remove(altar);
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l);
                if (bolt != null) {
                    bolt.moveTo(center);
                    bolt.setVisualOnly(true);
                    l.addFreshEntity(bolt);
                }
                MagicBossEntity boss = block.bossType().create(l);
                if (boss == null) return;
                float yaw = facing.getOpposite().toYRot();
                boss.moveTo(center.x, center.y, center.z, yaw, 0f);
                boss.setYHeadRot(yaw);
                boss.yBodyRot = yaw;
                boss.startSpawnAnimation();
                l.addFreshEntity(boss);
            }
        });
        return true;
    }

    public static void clear() {
        ACTIVE.clear();
    }

    private AltarRitual() {}
}
