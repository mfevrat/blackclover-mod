"""Armures d'ordre en 3D : un modèle par ordre (accessoires uniques) + texture 128x128."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from modelgen import Model
HERE=os.path.dirname(os.path.abspath(__file__))
JAVA=os.path.join(HERE,'../src/main/java/com/blackclovermod/client/model/')
TEX=os.path.join(HERE,'../src/main/resources/assets/blackclover/textures/models/armor/')

ORDERS={  # couleur principale, bordure, métal, emblème
 "onyx_ravens":((36,32,42),(150,60,200),(120,120,135),(200,170,255)),
 "azure_stags":((38,72,150),(205,210,225),(200,205,220),(235,240,255)),
 "scarlet_phoenix":((150,28,26),(235,180,50),(230,180,60),(255,210,90)),
 "jade_serpents":((32,105,66),(190,140,70),(180,140,70),(170,240,170)),
 "silver_owls":((222,222,228),(110,120,145),(160,165,180),(80,90,120)),
}
def build(oid):
    main,trim,metal,emb=ORDERS[oid]
    m=Model(hash(oid)%1000)
    # --- pièces obligatoires du modèle humanoïde (positions vanilla) ---
    m.part("head","root",(0,0,0),(0,0,0),[(-4,-8,-4,8,8,8,'fab',0,1.0)])
    m.part("hat","root",(0,0,0),(0,0,0),[])
    m.part("body","root",(0,0,0),(0,0,0),[(-4,0,-2,8,12,4,'fab',0,1.01)])
    m.part("right_arm","root",(-5,2,0),(0,0,0),[(-3,-2,-2,4,12,4,'fab',0,1.0)])
    m.part("left_arm","root",(5,2,0),(0,0,0),[(-1,-2,-2,4,12,4,'fab',0,1.0)])
    m.part("right_leg","root",(-1.9,12,0),(0,0,0),[])
    m.part("left_leg","root",(1.9,12,0),(0,0,0),[])
    # --- capuche ---
    m.part("hood_brim","head",(0,-8.6,-4.6),(12,0,0),[(-4.5,0,-1.2,9,2,2,'trim')])
    m.part("hood_drape","head",(0,-1,4.6),(10,0,0),[(-4.5,0,-1,9,5,2,'fab')])
    m.part("hood_side_r","head",(-4.8,-6,-3.6),(0,0,0),[(-0.8,0,0,1,7,2,'fab')])
    m.part("hood_side_l","head",(4.8,-6,-3.6),(0,0,0),[(-0.2,0,0,1,7,2,'fab')])
    # --- robe ---
    m.part("mantle","body",(0,0,0),(0,0,0),[(-5.5,-1,-3.2,11,3,6.4 and 6,'fab2')])
    m.part("collar","body",(0,-0.5,2.6),(-20,0,0),[(-4.5,-3,0,9,3,1,'trim')])
    m.part("belt","body",(0,9,0),(0,0,0),[(-4.5,0,-2.7,9,2,5,'leather'),(-1,-0.2,-3.3,2,2,1,'metal')])
    m.part("emblem","body",(0,3.5,-3.2),(0,0,45),[(-1.5,-1.5,-0.5,3,3,1,'emb')])
    m.part("sash","body",(2.5,0.5,-3.05),(0,0,-28),[(-1,0,0,2,13,0,'trim')])
    m.part("tail_front","body",(0,11,-2.6),(-6,0,0),[(-3.5,0,-0.5,7,7,1,'fab'),(-3.5,6,-0.6,7,1,1,'trim')])
    m.part("tail_back","body",(0,11,2.6),(8,0,0),[(-4,0,-0.5,8,9,1,'fab'),(-4,8,-0.6,8,1,1,'trim')])
    m.part("tail_r","body",(-4.4,11,0),(0,0,8),[(-0.5,0,-2,1,6,4,'fab2')])
    m.part("tail_l","body",(4.4,11,0),(0,0,-8),[(-0.5,0,-2,1,6,4,'fab2')])
    # --- épaulettes & manches ---
    for side,s,arm in (("r",-1,"right_arm"),("l",1,"left_arm")):
        m.part(f"pauldron_{side}",arm,(s*1,-2.6,0),(0,0,s*-18),[(-3,-1,-3,6,3,6,'metal'),(-2.5,1.5,-2.8,5,1,5.6 and 5,'trim')])
        m.part(f"cuff_{side}",arm,(s*1,8,0),(0,0,0),[(-2.6,0,-2.6,5,2,5,'trim')])
    # --- accessoires uniques ---
    if oid=="onyx_ravens":
        m.part("beak","head",(0,-8.4,-5.4),(25,0,0),[(-1,0,-2,2,1,2,'metal')])
        for i,(x,rz) in enumerate([(-1.5,-15),(0,0),(1.5,15)]):
            m.part(f"plume_{i}","head",(x,-9,1),(-35,0,rz),[(-0.5,-7,0,1,7,0,'feather')])
        m.part("feather_mantle","body",(0,0,3),(15,0,0),[(-5,-1,0,10,7,0,'feather')])
    elif oid=="azure_stags":
        for side,s in (("r",-1),("l",1)):
            m.chain(f"antler_{side}","head",(s*3,-8.5,-1),[(-10,0,s*40),(-20,0,-s*25),(-25,0,s*10)],[(1,3,1),(1,3,1),(1,3,1)],'metal',down=False)
            m.part(f"tine_{side}0",f"antler_{side}_1",(0,-2,0),(-40,0,s*45),[(-0.5,-3,-0.5,1,3,1,'metal')])
            m.part(f"tine_{side}1",f"antler_{side}_2",(0,-2,0),(-30,0,-s*40),[(-0.5,-2,-0.5,1,2,1,'metal')])
    elif oid=="scarlet_phoenix":
        for i,(z,hh) in enumerate([(-3,3),(-1.5,5),(0,6),(1.5,5),(3,4)]):
            m.part(f"crest_{i}","head",(0,-9,z),(-20+i*8,0,0),[(-0.5,-hh,-0.5,1,hh,1,'flame',1)])
        m.chain("plume","head",(0,-5,4.5),[(40,0,0),(20,0,0),(15,0,0)],[(3,4,0),(3,4,0),(2,4,0)],'flame',glow=1)
    elif oid=="jade_serpents":
        for side,s in (("r",-1),("l",1)):
            m.part(f"cobra_{side}","head",(s*4.6,-7,1),(0,s*-25,s*15),[(min(0,s*4),0,-0.5,4,8,1,'fab2'),(min(0,s*4),0,-0.6,4,1,1,'trim')])
            m.part(f"fang_{side}","hood_brim",(s*1.5,2,-1),(0,0,0),[(-0.5,0,-0.5,1,2,1,'bone')])
        m.part("scale_crest","head",(0,-9,-2),(-10,0,0),[(-1,-1,0,2,1,7,'trim')])
    elif oid=="silver_owls":
        for side,s in (("r",-1),("l",1)):
            m.part(f"tuft_{side}","head",(s*3,-9,-1),(-15,0,s*30),[(-1,-4,-0.5,2,4,1,'feather')])
        m.part("owl_mantle","body",(0,-0.5,-3.4),(0,0,0),[(-5,0,0,10,4,0,'feather')])
        m.part("owl_mantle_back","body",(0,-0.5,3.4),(0,0,0),[(-5,0,0,10,6,0,'feather')])
    mats={'fab':{'c':main,'n':8,'p':'fabric'},'fab2':{'c':tuple(int(v*0.82) for v in main),'n':6,'p':'fabric'},
          'trim':{'c':trim,'n':6,'p':'metal'},'metal':{'c':metal,'n':8,'p':'metal'},'emb':{'c':emb,'n':4,'edge':False},
          'leather':{'c':(90,60,40),'n':8},'feather':{'c':tuple(min(255,int(v*1.15)) for v in main),'n':10,'p':'feather'},
          'flame':{'c':(255,140,40),'n':20,'p':'feather'},'bone':{'c':(235,230,215),'n':4}}
    def face(px,gp,part,f,x0,y0,w,h):
        if part=='head' and f=='front':       # visage ouvert dans la capuche
            for xx in range(x0+1,x0+w-1):
                for yy in range(y0+2,y0+h):
                    px[xx,yy]=(0,0,0,0)
        if part=='body' and f=='back':
            for yy in range(y0+2,y0+h-2): px[x0+w//2,yy]=trim+(255,)
    code,img,glow=m.build(mats,(128,128),face)
    img.save(TEX+oid+'_armor.png')
    return code

methods=[]
for oid in ORDERS:
    code=build(oid)
    name=''.join(w.capitalize() for w in oid.split('_'))
    methods.append(f'''    public static LayerDefinition create{name}() {{
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
{chr(10).join(code)}
        return LayerDefinition.create(mesh, 128, 128);
    }}
''')
java=f'''package com.blackclovermod.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.world.entity.LivingEntity;

/**
 * Armures d'ordre en 3D (capuche avec visière et drapé, épaulettes, ceinture, pans de robe, accessoire unique).
 * Généré par gen/armor_v3.py.
 */
public class OrderArmorModel extends HumanoidModel<LivingEntity> {{

    public OrderArmorModel(ModelPart root) {{
        super(root);
    }}

{chr(10).join(methods)}}}
'''
open(JAVA+'OrderArmorModel.java','w').write(java)
print("ok")
