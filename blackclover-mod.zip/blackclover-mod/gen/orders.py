import json, random, sys
sys.path.insert(0,'.')
from PIL import Image
random.seed(11)
ROOT='../src/main/resources/assets/blackclover/'
ARM=ROOT+'textures/models/armor/'; CAPE=ROOT+'textures/entity/cape/'
import os; os.makedirs(ARM,exist_ok=True); os.makedirs(CAPE,exist_ok=True)

ORDERS = {  # id: (couleur principale, couleur bordure, couleur emblème)
 "onyx_ravens":  ((34,30,40),  (150,60,200), (200,170,255)),
 "azure_stags":  ((35,70,150), (205,210,225),(235,240,255)),
 "scarlet_phoenix":((150,25,25),(235,180,50),(255,210,90)),
 "jade_serpents":((30,105,65), (190,140,70), (170,240,170)),
 "silver_owls":  ((225,225,230),(120,130,150),(80,90,120)),
}
# Emblèmes 7x7 (1 = pixel)
EMB = {
 "onyx_ravens":["0011000","0111100","1111110","0111111","0011110","0010100","0100010"],
 "azure_stags":["1010101","1010101","0111110","0011100","0111110","0011100","0001000"],
 "scarlet_phoenix":["1001001","1101011","0111110","0011100","0111110","1101011","0001000"],
 "jade_serpents":["0011110","0100000","0011100","0000010","0111100","1000000","0111110"],
 "silver_owls":["1100011","1111111","1011101","1111111","0111110","0110110","0011100"],
}
def n(c,a=10): return tuple(max(0,min(255,v+random.randint(-a,a))) for v in c)+(255,)

def emblem(px,ox,oy,order,col):
    for y,row in enumerate(EMB[order]):
        for x,ch in enumerate(row):
            if ch=='1': px[ox+x,oy+y]=col+(255,)

for oid,(main,trim,embc) in ORDERS.items():
    # ---------- Armure (layer_1 : capuche + robe) ----------
    im=Image.new('RGBA',(64,32),(0,0,0,0)); px=im.load()
    def fill(x0,y0,w,h,c,a=10):
        for x in range(x0,x0+w):
            for y in range(y0,y0+h): px[x,y]=n(c,a)
    # tête (casque) : on laisse le visage ouvert sur la face avant
    fill(0,0,32,16,main); 
    for x in range(9,15):
        for y in range(10,16): px[x,y]=(0,0,0,0)
    # capuche (calque "hat" 32..64) : bord
    fill(32,0,32,16,main)
    for x in range(40,48): px[x,8]=trim+(255,); px[x,15]=trim+(255,)
    for x in range(41,47):
        for y in range(10,16): px[x,y]=(0,0,0,0)
    # corps (robe)
    fill(16,16,24,16,main)
    for y in range(20,32): px[23,y]=trim+(255,); px[24,y]=trim+(255,)
    for x in range(20,28): px[x,20]=trim+(255,); px[x,31]=trim+(255,)
    emblem(px,20,22,oid,embc)
    # bras
    fill(40,16,16,16,main)
    for x in range(40,56): px[x,30]=trim+(255,); px[x,31]=trim+(255,)
    im.save(ARM+oid+'_layer_1.png')
    # layer_2 vide (pas de jambières)
    Image.new('RGBA',(64,32),(0,0,0,0)).save(ARM+oid+'_layer_2.png')

    # ---------- Cape (format cape vanilla 64x32) ----------
    c=Image.new('RGBA',(64,32),(0,0,0,0)); cp=c.load()
    for x in range(0,22):
        for y in range(0,17): cp[x,y]=n(main,8)
    for x in range(1,11): cp[x,16]=trim+(255,); cp[x,1]=trim+(255,)
    for x in range(12,22): cp[x,16]=trim+(255,); cp[x,1]=trim+(255,)
    for y in range(1,17): cp[1,y]=trim+(255,); cp[10,y]=trim+(255,); cp[12,y]=trim+(255,); cp[21,y]=trim+(255,)
    emblem(cp,2,5,oid,embc); emblem(cp,13,5,oid,embc)
    c.save(CAPE+oid+'.png')
print("ok")
