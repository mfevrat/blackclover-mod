"""Génère pour chaque boss : une classe Java (HierarchicalModel) + texture 128x128 + texture lumineuse.
Chaque partie : (nom, parent, pivot(x,y,z), rotation(x,y,z) en degrés, [cubes]) ; cube = (x,y,z,w,h,d, matériau, glow?)"""
import random, math
from PIL import Image
random.seed(21)
JAVA='../src/main/java/com/blackclovermod/client/model/'
TEX='../src/main/resources/assets/blackclover/textures/entity/'
import os; os.makedirs(JAVA,exist_ok=True)
TW=TH=128

class Packer:
    def __init__(s): s.x=0; s.y=0; s.row=0
    def place(s,w,h):
        if s.x+w>TW: s.x=0; s.y+=s.row; s.row=0
        p=(s.x,s.y); s.x+=w; s.row=max(s.row,h)
        if s.y+h>TH: raise Exception("texture pleine")
        return p

def clamp(v): return max(0,min(255,int(v)))

def generate(cls, texname, parts, mats, anim_code, face_paint=None, size=128):
    global TW,TH
    TW=TH=size
    pk=Packer(); img=Image.new('RGBA',(TW,TH),(0,0,0,0)); glow=Image.new('RGBA',(TW,TH),(0,0,0,0))
    px=img.load(); gp=glow.load()
    lines=[]; fields=[]; lookups=[]
    var={'root':'root'}
    for (name,parent,pivot,rot,cubes) in parts:
        cb="CubeListBuilder.create()"
        for (x,y,z,w,h,d,mat,gl) in cubes:
            u,v=pk.place(2*d+2*w if w+d>0 else 1, d+h if d+h>0 else 1)
            cb+=f".texOffs({u}, {v}).addBox({x}F, {y}F, {z}F, {w}F, {h}F, {d}F)"
            paint(px,gp,u,v,w,h,d,mats[mat],gl,name,face_paint)
        rx,ry,rz=[f"{math.radians(a):.4f}F" for a in rot]
        pose=f"PartPose.offsetAndRotation({pivot[0]}F, {pivot[1]}F, {pivot[2]}F, {rx}, {ry}, {rz})"
        lines.append(f'        PartDefinition {name} = {var[parent]}.addOrReplaceChild("{name}", {cb}, {pose});')
        var[name]=name
        fields.append(f"    public final ModelPart {name};")
        lookups.append((name,parent))
    img.save(TEX+texname+'.png'); glow.save(TEX+texname+'_glow.png')
    # constructeur
    ctor=[]
    for (name,parent) in lookups:
        src='root' if parent=='root' else 'this.'+parent
        ctor.append(f'        this.{name} = {src}.getChild("{name}");')
    java=f'''package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL généré automatiquement (voir gen/bossmodels.py). Les animations sont dans setupAnim. */
public class {cls}<T extends MagicBossEntity> extends HierarchicalModel<T> {{
    private final ModelPart root;
{chr(10).join(fields)}

    public {cls}(ModelPart root) {{
        this.root = root;
{chr(10).join(ctor)}
    }}

    public static LayerDefinition createBodyLayer() {{
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
{chr(10).join(lines)}
        return LayerDefinition.create(mesh, {TW}, {TH});
    }}

    @Override
    public ModelPart root() {{ return root; }}

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {{
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);           // ticks depuis le début de l'animation
        float breathe = Mth.sin(age * 0.08F);
{anim_code}
    }}
}}
'''
    open(JAVA+cls+'.java','w').write(java)

def paint(px,gp,u,v,w,h,d,mat,gl,part,face_paint):
    base,noise,dark=mat
    faces={'top':(u+d,v,w,d,1.15),'bottom':(u+d+w,v,w,d,0.7),'right':(u,v+d,d,h,0.85),
           'front':(u+d,v+d,w,h,1.0),'left':(u+d+w,v+d,d,h,0.85),'back':(u+2*d+w,v+d,w,h,0.8)}
    for fname,(x0,y0,fw,fh,f) in faces.items():
        for x in range(x0,x0+fw):
            for y in range(y0,y0+fh):
                k=random.randint(-noise,noise)
                grad=1.0-0.18*((y-y0)/max(1,fh-1)) if fname in('front','back','left','right') else 1
                edge=0.8 if (x in(x0,x0+fw-1) or y in(y0,y0+fh-1)) and fw>2 and fh>2 else 1
                c=[clamp((ch+k)*f*grad*edge) for ch in base]
                if dark and random.random()<dark[1]: c=list(dark[0])
                px[x,y]=(*c,255)
                if gl: gp[x,y]=(clamp(c[0]*1.2),clamp(c[1]*1.2),clamp(c[2]*1.2),255)
        if face_paint: face_paint(px,gp,part,fname,x0,y0,fw,fh)

# =====================================================================
# 1) GARDIEN DU DONJON — colosse de pierre runique
# =====================================================================
STONE=((125,125,132),12,((70,110,60),0.10)); DSTONE=((88,88,96),10,None)
RUNE=((70,220,255),15,None); MOSS=((70,115,55),15,None); CRY=((110,240,255),20,None)
def guardian_face(px,gp,part,f,x0,y0,w,h):
    if part=='head' and f=='front':
        for ex in (x0+1,x0+w-3):
            for dx in range(2):
                px[ex+dx,y0+3]=(30,30,35,255); gp[ex+dx,y0+3]=(90,240,255,255)
    if part=='body' and f=='front' and w>=18:
        for y in range(y0+3,y0+h-3): gp[x0+w//2,y]=(70,220,255,255); px[x0+w//2,y]=(55,55,60,255)
        for x in range(x0+5,x0+w-5): gp[x,y0+h//2]=(70,220,255,255); px[x,y0+h//2]=(55,55,60,255)
generate("DungeonGuardianModel","dungeon_guardian",[
 ("body","root",(0,4,0),(8,0,0),[(-10,-20,-5,20,18,10,'stone',0),(-7,-2,-4,14,6,8,'dstone',0),(-6,-22,2,12,4,4,'moss',0)]),
 ("core","body",(0,-12,-5),(0,0,0),[(-2,-2,-1,4,4,1,'rune',1)]),
 ("head","body",(0,-20,-2),(0,0,0),[(-4,-7,-4,8,7,8,'stone',0),(-5,-8,-4.5,10,2,3,'dstone',0)]),
 ("right_arm","body",(-12,-16,0),(0,0,0),[(-5,-3,-4,7,22,8,'stone',0),(-6,17,-4.5,9,8,9,'dstone',0)]),
 ("right_crystal","right_arm",(-2,-3,0),(0,0,-20),[(-1.5,-6,-1.5,3,6,3,'cry',1)]),
 ("left_arm","body",(12,-16,0),(0,0,0),[(-2,-3,-4,7,22,8,'stone',0),(-3,17,-4.5,9,8,9,'dstone',0)]),
 ("left_crystal","left_arm",(2,-3,0),(0,0,20),[(-1.5,-6,-1.5,3,6,3,'cry',1)]),
 ("right_leg","root",(-5,6,0),(0,0,0),[(-3.5,0,-3.5,7,18,7,'stone',0)]),
 ("left_leg","root",(5,6,0),(0,0,0),[(-3.5,0,-3.5,7,18,7,'stone',0)]),
],{'stone':STONE,'dstone':DSTONE,'rune':RUNE,'moss':MOSS,'cry':CRY},'''
        this.head.yRot = headYaw * Mth.DEG_TO_RAD * 0.6F;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD * 0.5F;
        this.body.y += breathe * 0.4F;
        this.right_leg.xRot = Mth.cos(limbSwing * 0.5F) * 1.0F * limbAmount;
        this.left_leg.xRot = Mth.cos(limbSwing * 0.5F + Mth.PI) * 1.0F * limbAmount;
        this.right_arm.xRot = Mth.cos(limbSwing * 0.5F + Mth.PI) * 0.6F * limbAmount;
        this.left_arm.xRot = Mth.cos(limbSwing * 0.5F) * 0.6F * limbAmount;
        this.right_arm.zRot = 0.08F + breathe * 0.03F;
        this.left_arm.zRot = -0.08F - breathe * 0.03F;
        if (anim == 1 && at < 26) {            // FRAPPE SISMIQUE : bras levés puis abattus
            float up = at < 14 ? at / 14F : 1F - (at - 14) / 4F;
            up = Mth.clamp(up, -0.3F, 1F);
            this.right_arm.xRot = -2.8F * up;
            this.left_arm.xRot = -2.8F * up;
            this.body.xRot = 0.14F - 0.35F * up + (at > 14 ? 0.5F : 0F);
        } else if (anim == 2 && at < 16) {     // LANCER DE ROCHER
            float k = at / 16F;
            this.right_arm.xRot = k < 0.5F ? -3.0F * (k * 2) : -3.0F + 4.2F * ((k - 0.5F) * 2);
        } else if (anim == 3 && at < 30) {     // RUGISSEMENT
            float k = Mth.sin(at / 30F * Mth.PI);
            this.head.xRot = -0.6F * k;
            this.right_arm.zRot = 1.2F * k;
            this.left_arm.zRot = -1.2F * k;
        }
        this.core.xScale = this.core.yScale = 1F + Mth.sin(age * 0.2F) * 0.15F;
''',guardian_face)

# =====================================================================
# 2) ROI ELFE SPECTRAL — mage élancé, couronne, halo et 4 ailes de lumière
# =====================================================================
SKIN=((238,214,196),5,None); ROBE=((245,243,236),6,((228,188,82),0.04)); GOLDM=((232,188,70),12,None)
HAIR=((246,226,150),10,None); WINGM=((255,236,160),18,None); HALO=((255,245,190),5,None); SASH=((90,170,200),8,None)
def elf_face(px,gp,part,f,x0,y0,w,h):
    if part=='head' and f=='front':
        for x in range(x0,x0+w): px[x,y0]=(246,226,150,255); px[x,y0+1]=(246,226,150,255)
        for ex in (x0+1,x0+w-3):
            px[ex,y0+4]=(255,240,150,255); px[ex+1,y0+4]=(255,240,150,255)
            gp[ex,y0+4]=(255,240,150,255); gp[ex+1,y0+4]=(255,240,150,255)
        px[x0+w//2,y0+6]=(210,180,165,255)
generate("ElfKingModel","elf_king",[
 ("body","root",(0,-14,0),(0,0,0),[(-4.5,0,-2.5,9,13,5,'robe',0),(-5,-1,-3,10,3,6,'gold',0),(-1,1,-2.8,2,12,1,'sash',0)]),
 ("skirt","body",(0,12,0),(0,0,0),[(-5.5,0,-3.5,11,15,7,'robe',0),(-6,14,-4,12,2,8,'gold',0)]),
 ("head","body",(0,-1,0),(0,0,0),[(-4,-8,-4,8,8,8,'skin',0),(-4.5,-8.5,1,9,11,4,'hair',0)]),
 ("crown","head",(0,-8,0),(0,0,0),[(-4.5,-2,-4.5,9,2,9,'gold',1),(-0.5,-5,-4.6,1,3,1,'gold',1),(-3.5,-4,-4.6,1,2,1,'gold',1),(2.5,-4,-4.6,1,2,1,'gold',1)]),
 ("halo","head",(0,-13,2),(-20,0,0),[(-5,-0.5,-5,10,1,1,'halo',1),(-5,-0.5,4,10,1,1,'halo',1),(-5,-0.5,-4,1,1,8,'halo',1),(4,-0.5,-4,1,1,8,'halo',1)]),
 ("right_ear","head",(-4,-4,0),(0,-25,-15),[(-4,-1,-0.5,4,2,1,'skin',0)]),
 ("left_ear","head",(4,-4,0),(0,25,15),[(0,-1,-0.5,4,2,1,'skin',0)]),
 ("right_arm","body",(-6,1,0),(0,0,0),[(-2,-1,-2,3,11,4,'robe',0),(-3,8,-3,5,6,6,'robe',0),(-1.5,13,-1.5,2,2,3,'skin',0)]),
 ("left_arm","body",(6,1,0),(0,0,0),[(-1,-1,-2,3,11,4,'robe',0),(-2,8,-3,5,6,6,'robe',0),(-0.5,13,-1.5,2,2,3,'skin',0)]),
 ("right_wing_up","body",(-2,2,3),(0,0,0),[(-18,-14,0,18,16,0,'wing',1)]),
 ("right_wing_low","body",(-2,7,3),(0,0,0),[(-13,0,0,13,11,0,'wing',1)]),
 ("left_wing_up","body",(2,2,3),(0,0,0),[(0,-14,0,18,16,0,'wing',1)]),
 ("left_wing_low","body",(2,7,3),(0,0,0),[(0,0,0,13,11,0,'wing',1)]),
],{'skin':SKIN,'robe':ROBE,'gold':GOLDM,'hair':HAIR,'wing':WINGM,'halo':HALO,'sash':SASH},'''
        this.head.yRot = headYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.body.y += Mth.sin(age * 0.06F) * 1.5F;           // lévitation
        float flap = Mth.sin(age * 0.15F) * 0.25F;
        this.right_wing_up.yRot = 0.55F + flap;  this.right_wing_low.yRot = 0.45F + flap * 0.8F;
        this.left_wing_up.yRot = -0.55F - flap;  this.left_wing_low.yRot = -0.45F - flap * 0.8F;
        this.right_wing_up.zRot = -0.15F; this.left_wing_up.zRot = 0.15F;
        this.right_wing_low.zRot = 0.25F; this.left_wing_low.zRot = -0.25F;
        this.skirt.xRot = 0.05F + breathe * 0.03F;
        this.right_arm.zRot = 0.1F + breathe * 0.05F; this.left_arm.zRot = -0.1F - breathe * 0.05F;
        this.halo.yRot = age * 0.05F;
        if (anim == 1 && at < 40) {            // PLUIE D'ÉPÉES : bras au ciel, ailes déployées
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.9F * k; this.left_arm.xRot = -2.9F * k;
            this.right_arm.zRot = 0.4F * k;  this.left_arm.zRot = -0.4F * k;
            this.right_wing_up.yRot = 0.2F; this.left_wing_up.yRot = -0.2F;
        } else if (anim == 2 && at < 40) {     // JUGEMENT : désigne le sol
            float k = Mth.clamp(at / 6F, 0F, 1F);
            this.right_arm.xRot = -1.4F * k; this.left_arm.xRot = -0.3F * k;
            this.head.xRot += 0.3F * k;
        } else if (anim == 3 && at < 10) {     // TÉLÉPORTATION : repli des ailes
            float k = 1F - at / 10F;
            this.right_wing_up.yRot += 0.9F * k; this.left_wing_up.yRot -= 0.9F * k;
        }
''',elf_face)

# =====================================================================
# 3) ARCHIDÉMON MORVATH — cornes, ailes de chauve-souris, queue, griffes
# =====================================================================
DSKIN=((34,28,36),8,((120,12,12),0.06)); DSKIN2=((52,40,50),8,None); HORN=((210,200,185),10,((90,80,70),0.15))
CLAW=((230,225,215),6,None); MEMB=((70,14,20),12,None); EYE=((255,40,30),0,None); SIGIL=((230,30,25),10,None)
def demon_face(px,gp,part,f,x0,y0,w,h):
    if part=='head' and f=='front':
        for ex in (x0+1,x0+w-3):
            for dx in range(2):
                px[ex+dx,y0+4]=(255,30,20,255); gp[ex+dx,y0+4]=(255,40,30,255)
        for x in range(x0+2,x0+w-2): px[x,y0+7]=(15,5,8,255)
        for x in (x0+2,x0+w-3): px[x,y0+8]=(235,230,220,255)
    if part=='body' and f=='front' and w>=14:
        for i in range(6):
            for (xx,yy) in ((x0+3+i,y0+3+i),(x0+w-4-i,y0+3+i)):
                gp[xx,yy]=(230,30,25,255); px[xx,yy]=(120,10,10,255)
generate("ArchdemonModel","archdemon",[
 ("body","root",(0,2,0),(10,0,0),[(-8,-20,-4.5,16,13,9,'skin',0),(-5.5,-7,-3.5,11,8,7,'skin2',0)]),
 ("head","body",(0,-20,-1),(0,0,0),[(-4.5,-9,-4.5,9,9,9,'skin',0),(-3.5,-2,-5.5,7,3,2,'skin2',0)]),
 ("right_horn","head",(-3.5,-8,0),(-20,0,-35),[(-1.5,-5,-1.5,3,5,3,'horn',0)]),
 ("right_horn2","right_horn",(0,-5,0),(-30,0,25),[(-1,-5,-1,2,5,2,'horn',0)]),
 ("right_horn3","right_horn2",(0,-5,0),(-30,0,20),[(-0.5,-3,-0.5,1,3,1,'horn',1)]),
 ("left_horn","head",(3.5,-8,0),(-20,0,35),[(-1.5,-5,-1.5,3,5,3,'horn',0)]),
 ("left_horn2","left_horn",(0,-5,0),(-30,0,-25),[(-1,-5,-1,2,5,2,'horn',0)]),
 ("left_horn3","left_horn2",(0,-5,0),(-30,0,-20),[(-0.5,-3,-0.5,1,3,1,'horn',1)]),
 ("right_arm","body",(-10,-17,0),(0,0,0),[(-3,-2,-3,5,13,6,'skin',0)]),
 ("right_forearm","right_arm",(-0.5,11,0),(-15,0,0),[(-2.5,0,-2.5,5,12,5,'skin2',0),(-3,11,-2.5,1,4,1,'claw',0),(-1,11,-2.5,1,5,1,'claw',0),(1,11,-2.5,1,4,1,'claw',0)]),
 ("left_arm","body",(10,-17,0),(0,0,0),[(-2,-2,-3,5,13,6,'skin',0)]),
 ("left_forearm","left_arm",(0.5,11,0),(-15,0,0),[(-2.5,0,-2.5,5,12,5,'skin2',0),(-2,11,-2.5,1,4,1,'claw',0),(0,11,-2.5,1,5,1,'claw',0),(2,11,-2.5,1,4,1,'claw',0)]),
 ("right_wing","body",(-3,-17,4),(0,0,0),[(-20,-1,-1,20,2,2,'skin2',0),(-20,1,0,20,20,0,'memb',0)]),
 ("right_wing_tip","right_wing",(-20,0,0),(0,0,0),[(-16,-1,-1,16,2,2,'skin2',0),(-16,1,0,16,16,0,'memb',0),(-17,-2,-0.5,1,3,1,'claw',0)]),
 ("left_wing","body",(3,-17,4),(0,0,0),[(0,-1,-1,20,2,2,'skin2',0),(0,1,0,20,20,0,'memb',0)]),
 ("left_wing_tip","left_wing",(20,0,0),(0,0,0),[(0,-1,-1,16,2,2,'skin2',0),(0,1,0,16,16,0,'memb',0),(16,-2,-0.5,1,3,1,'claw',0)]),
 ("tail","body",(0,0,3),(55,0,0),[(-1.5,0,-1.5,3,9,3,'skin',0)]),
 ("tail2","tail",(0,9,0),(20,0,0),[(-1,0,-1,2,9,2,'skin',0)]),
 ("tail3","tail2",(0,9,0),(20,0,0),[(-0.5,0,-0.5,1,7,1,'skin2',0),(-2,6,-0.5,4,3,1,'sigil',1)]),
 ("right_leg","root",(-4.5,1,0),(-15,0,0),[(-2.5,0,-3,5,12,6,'skin',0)]),
 ("right_shin","right_leg",(0,12,-1),(40,0,0),[(-2,0,-2,4,10,4,'skin2',0),(-2.5,9,-4,5,2,5,'claw',0)]),
 ("left_leg","root",(4.5,1,0),(-15,0,0),[(-2.5,0,-3,5,12,6,'skin',0)]),
 ("left_shin","left_leg",(0,12,-1),(40,0,0),[(-2,0,-2,4,10,4,'skin2',0),(-2.5,9,-4,5,2,5,'claw',0)]),
],{'skin':DSKIN,'skin2':DSKIN2,'horn':HORN,'claw':CLAW,'memb':MEMB,'eye':EYE,'sigil':SIGIL},'''
        this.head.yRot = headYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.body.xRot = 0.17F + breathe * 0.03F;
        boolean spread = e.phase() >= 2;
        float flap = Mth.sin(age * (spread ? 0.18F : 0.1F)) * (spread ? 0.35F : 0.15F);
        float fold = spread ? 0.25F : 0.75F;
        this.right_wing.yRot = fold + flap;  this.left_wing.yRot = -fold - flap;
        this.right_wing.zRot = -0.3F + flap * 0.5F; this.left_wing.zRot = 0.3F - flap * 0.5F;
        this.right_wing_tip.yRot = spread ? 0.3F + flap : 1.2F; this.left_wing_tip.yRot = spread ? -0.3F - flap : -1.2F;
        this.tail.zRot = Mth.sin(age * 0.1F) * 0.3F;
        this.tail2.zRot = Mth.sin(age * 0.1F - 0.8F) * 0.35F;
        this.tail3.zRot = Mth.sin(age * 0.1F - 1.6F) * 0.4F;
        this.right_leg.xRot = -0.26F + Mth.cos(limbSwing * 0.6F) * 0.9F * limbAmount;
        this.left_leg.xRot = -0.26F + Mth.cos(limbSwing * 0.6F + Mth.PI) * 0.9F * limbAmount;
        this.right_arm.xRot = Mth.cos(limbSwing * 0.6F + Mth.PI) * 0.5F * limbAmount;
        this.left_arm.xRot = Mth.cos(limbSwing * 0.6F) * 0.5F * limbAmount;
        this.right_arm.zRot = 0.15F; this.left_arm.zRot = -0.15F;
        if (anim == 1 && at < 30) {            // INCANTATION : bras écartés vers le ciel
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.2F * k; this.left_arm.xRot = -2.2F * k;
            this.right_arm.zRot = 0.7F * k;  this.left_arm.zRot = -0.7F * k;
            this.head.xRot -= 0.4F * k;
        } else if (anim == 2 && at < 14) {     // GRIFFE
            float k = at / 14F;
            this.right_arm.xRot = k < 0.4F ? -2.6F * (k / 0.4F) : -2.6F + 3.6F * ((k - 0.4F) / 0.6F);
            this.right_arm.yRot = -0.5F * k;
        } else if (anim == 3 && at < 40) {     // RUGISSEMENT DE TRANSFORMATION
            float k = Mth.sin(Mth.clamp(at / 40F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.8F * k;
            this.right_arm.zRot = 1.3F * k; this.left_arm.zRot = -1.3F * k;
            this.right_wing.yRot = 0.1F; this.left_wing.yRot = -0.1F;
            this.right_wing_tip.yRot = 0.1F; this.left_wing_tip.yRot = -0.1F;
        }
''',demon_face,256)
print("ok")
