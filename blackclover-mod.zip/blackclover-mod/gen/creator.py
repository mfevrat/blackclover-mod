"""Boss final : LE CRÉATEUR — démon antique colossal (design original)."""
import math, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from modelgen import Model, boss_class
HERE=os.path.dirname(os.path.abspath(__file__))
JAVA=os.path.join(HERE,'../src/main/java/com/blackclovermod/client/model/')
TEX=os.path.join(HERE,'../src/main/resources/assets/blackclover/textures/entity/')
m=Model(99)
m.part("torso","root",(0,-10,0),(6,0,0),[(-9,-14,-5,18,14,10,'skin'),(-6,0,-4,12,6,8,'skin2')])
for i in range(4): m.part(f"rib_{i}","torso",(0,-12+i*3,-5.1),(0,0,0),[(-7,-0.5,-0.5,14,1,1,'sigil',1)])
for i in range(5): m.part(f"spine_{i}","torso",(0,-13+i*3,5),(-45,0,0),[(-1,-4,-1,2,4,2,'bone')])
for i in range(10):
    a=i*2*math.pi/10
    m.part(f"shroud_{i}","torso",(math.sin(a)*5,5,-math.cos(a)*3.5),(10,math.degrees(math.atan2(math.sin(a),-math.cos(a))),0),
           [(-3,0,0,6,22,1,'shroud'),(-3,21,0,6,1,1,'sigil',1)])
m.groups['shroud']=[f"shroud_{i}" for i in range(10)]
m.part("neck","torso",(0,-14,-1),(-10,0,0),[(-3,-3,-3,6,3,6,'skin2')])
m.part("head","neck",(0,-3,-0.5),(0,0,0),[(-5,-9,-5,10,9,10,'bone'),(-5.5,-6,-5.6,11,2,2,'bone2'),(-3,-3,-6.8,6,3,2,'bone')])
m.part("jaw","head",(0,-0.5,-1),(0,0,0),[(-4,0,-6,8,3,7,'bone2'),(-3.5,-1,-6,7,1,1,'claw')])
m.part("third_eye","head",(0,-7.5,-5.3),(0,0,0),[(-1,-1,0,2,2,0,'eye',1)])
for i in range(7):
    a=-75+i*25
    hh=[3,4,5,6,5,4,3][i]
    m.chain(f"crown{i}","head",(math.sin(math.radians(a))*4.5,-9,-math.cos(math.radians(a))*3+1),[(-10,0,a*0.5),(-15,0,a*0.2),(-15,0,0)],
            [(2,hh,2),(1,hh,1),(1,2,1)],'horn',down=False)
for side,s in (("right",-1),("left",1)):
    m.chain(f"{side}_greathorn","head",(s*4.5,-6,2),[(-40,0,s*70),(-25,0,s*15),(-25,0,0),(-30,0,-s*15),(-30,0,-s*20),(-25,0,-s*25)],
            [(4,5,4),(3,5,3),(3,5,3),(2,5,2),(2,4,2),(1,4,1)],'horn',down=False)
    m.part(f"{side}_pauldron","torso",(s*10,-12,0),(0,0,s*20),[(-4,-4,-4,8,5,8,'bone')])
    for i in range(3): m.part(f"{side}_pspike_{i}",f"{side}_pauldron",(0,-4,-2+i*2),(0,0,s*30),[(-0.5,-6,-0.5,1,6,1,'horn')])
    m.part(f"{side}_arm","torso",(s*11,-11,0),(0,0,0),[(-3,-1,-3,6,14,6,'skin')])
    m.part(f"{side}_forearm",f"{side}_arm",(0,13,0),(-20,0,0),[(-3,0,-3,6,12,6,'skin2')])
    m.part(f"{side}_hand",f"{side}_forearm",(0,12,0),(0,0,0),[(-2.5,0,-2.5,5,3,5,'skin')])
    for i in range(4):
        m.part(f"{side}_claw_{i}",f"{side}_hand",(-1.8+i*1.2,3,-1.8),(-20,0,(i-1.5)*8),[(-0.5,0,-0.5,1,6,1,'claw')])
    m.part(f"{side}_lowarm","torso",(s*8,-3,-1),(-30,0,s*10),[(-2,-1,-2,4,10,4,'skin2')])
    m.part(f"{side}_orb",f"{side}_lowarm",(0,11,0),(45,0,45),[(-1.5,-1.5,-1.5,3,3,3,'void',1)])
    for w,(y,L1,L2,mh,ang) in enumerate([(-12,12,16,10,20),(-7,10,13,8,0),(-2,8,10,6,-20)]):
        root=f"{side}_wing{w}"
        m.part(root,"torso",(s*4,y,5),(0,0,s*-ang),[(min(0,s*L1),-1,-1,L1,2,2,'bone2'),(min(0,s*L1),1,0,L1,mh,0,'memb')])
        m.part(f"{root}_tip",root,(s*L1,0,0),(0,0,0),[(min(0,s*L2),-1,-1,L2,2,2,'bone2'),(min(0,s*L2),1,0,L2,mh+2,0,'memb'),(min(0,s*(L2+1)),-2,-0.5,1,3,1,'claw')])
    m.groups[f"{side}_wings"]=[f"{side}_wing{w}" for w in range(3)]
    m.groups[f"{side}_wingtips"]=[f"{side}_wing{w}_tip" for w in range(3)]
m.part("halo","torso",(0,-26,6),(0,0,0),[])
for i in range(16):
    a=i*2*math.pi/16
    m.part(f"halo_{i}","halo",(math.cos(a)*9,math.sin(a)*9,0),(0,0,math.degrees(a)+90),[(-2,-0.5,-0.5,4,1,1,'void',1)])
for i in range(6): m.part(f"orbit_{i}","root",(0,-18,0),(45,45,0),[(-1.5,-1.5,-1.5,3,3,3,'rune',1)])
m.groups['orbits']=[f"orbit_{i}" for i in range(6)]
# phase 2 : cornes royales + épines dorsales flamboyantes
for i in range(4):
    a=-45+i*30
    m.chain(f"p2_royal{i}","head",(math.sin(math.radians(a))*3,-9,-math.cos(math.radians(a))*1.5+2),[(-35,0,a*0.6),(-20,0,a*0.2),(-10,0,0)],[(2,6,2),(1,6,1),(1,4,1)],'gold',glow=1,down=False)
for i in range(5): m.part(f"p2_flame_{i}","torso",(0,-13+i*3,6),(-50,0,0),[(-1,-7,-0.5,2,7,1,'sigil',1)])
# phase 3 : couronne de flammes et yeux sur le torse, lames sur les bras
for i in range(9):
    a=-80+i*20
    m.part(f"p3_fire_{i}","head",(math.sin(math.radians(a))*5,-9.5,-math.cos(math.radians(a))*3.5+1),(-10,0,a*0.4),[(-0.5,-8+abs(i-4),-0.5,1,8-abs(i-4),1,'fire',1)])
m.part("p3_chest_eyes","torso",(0,-8,-5.2),(0,0,0),[(-5,-0.5,0,2,1,0,'eye',1),(3,-0.5,0,2,1,0,'eye',1),(-1,2,0,2,1,0,'eye',1)])
for side,s in (("right",-1),("left",1)):
    for i in range(3): m.part(f"p3_blade_{side}{i}",f"{side}_forearm",(s*3,2+i*3.5,0),(0,0,s*-55),[(-0.5,-7,-1,1,7,2,'fire',1)])
MATS={'skin':{'c':(40,34,48),'n':8,'p':'scales','accent':((120,60,200),0.05)},'skin2':{'c':(58,48,66),'n':8,'p':'scales'},
      'bone':{'c':(222,214,198),'n':10,'p':'bone'},'bone2':{'c':(84,70,86),'n':8,'p':'bone'},'horn':{'c':(30,26,32),'n':8,'p':'bone','accent':((140,60,220),0.1)},
      'claw':{'c':(236,230,220),'n':5},'memb':{'c':(56,22,72),'n':10,'p':'membrane','edge':False},'sigil':{'c':(170,80,255),'n':10,'edge':False},
      'eye':{'c':(220,120,255),'n':0,'edge':False},'void':{'c':(150,70,240),'n':8,'p':'crystal'},'rune':{'c':(190,120,255),'n':10,'p':'crystal'},
      'shroud':{'c':(26,20,32),'n':6,'p':'fabric','accent':((120,60,200),0.04)},'gold':{'c':(240,190,70),'n':10,'p':'metal'},'fire':{'c':(255,140,60),'n':14,'p':'flame','edge':False}}
P2=dict(MATS); P2['skin']={'c':(46,30,46),'n':8,'p':'scales','accent':((255,190,80),0.10),'accent_glow':True}
P2['memb']={'c':(110,40,90),'n':10,'p':'membrane','edge':False}; P2['sigil']={'c':(255,190,80),'n':10,'edge':False}
P3=dict(P2); P3['skin']={'c':(80,14,22),'n':10,'p':'scales','accent':((255,110,50),0.18),'accent_glow':True}
P3['skin2']={'c':(54,12,18),'n':8,'p':'scales','accent':((255,90,40),0.1),'accent_glow':True}
P3['memb']={'c':(190,40,30),'n':12,'p':'membrane','edge':False}; P3['shroud']={'c':(40,8,12),'n':8,'p':'fabric','accent':((255,90,40),0.08),'accent_glow':True}
def face(px,gp,part,f,x0,y0,w,h):
    if part=='head' and f=='front' and w>=10:
        for ex in (x0+2,x0+w-4):
            for dx in range(2):
                for dy in range(2): px[ex+dx,y0+3+dy]=(210,110,255,255); gp[ex+dx,y0+3+dy]=(220,130,255,255)
A='''
        float hover = Mth.sin(age * 0.05F) * 2F;
        this.torso.y += hover + death * 10F;
        this.torso.xRot += breathe * 0.03F - hurt * 0.2F + death * 0.5F;
        this.head.yRot = yawR * 0.7F; this.head.xRot = pitchR * 0.5F;
        this.jaw.xRot = 0.1F + Mth.sin(age * 0.04F) * 0.06F;
        boolean open = e.phase() >= 2;
        for (int i = 0; i < 3; i++) {
            float f = Mth.sin(age * 0.1F - i * 0.5F) * 0.25F;
            float spread = (open ? 0.15F : 0.55F) * (1F - death * 0.5F);
            this.right_wings[i].yRot = spread + f; this.left_wings[i].yRot = -spread - f;
            this.right_wingtips[i].yRot = (open ? 0.2F : 0.9F) + f * 0.6F; this.left_wingtips[i].yRot = -(open ? 0.2F : 0.9F) - f * 0.6F;
        }
        for (int i = 0; i < this.shroud.length; i++) this.shroud[i].xRot += Mth.sin(age * 0.08F + i) * 0.08F;
        this.halo.zRot = age * 0.02F;
        for (int i = 0; i < 6; i++) {
            float a = age * 0.04F + i * Mth.PI / 3F;
            this.orbits[i].x = Mth.cos(a) * 18F; this.orbits[i].z = Mth.sin(a) * 18F;
            this.orbits[i].y = -18F + Mth.sin(age * 0.08F + i) * 4F + hover; this.orbits[i].yRot = age * 0.1F;
        }
        this.right_arm.zRot = 0.2F + breathe * 0.04F; this.left_arm.zRot = -0.2F - breathe * 0.04F;
        this.right_lowarm.xRot += Mth.sin(age * 0.06F) * 0.1F; this.left_lowarm.xRot -= Mth.sin(age * 0.06F) * 0.1F;
        if (anim == 1 && at < 35) {            // incantation : les quatre bras s'élèvent
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.4F * k; this.left_arm.xRot = -2.4F * k;
            this.right_arm.zRot = 0.6F * k; this.left_arm.zRot = -0.6F * k;
            this.right_lowarm.xRot = -1.6F * k; this.left_lowarm.xRot = -1.6F * k;
            this.jaw.xRot = 0.6F * k; this.head.xRot -= 0.3F * k;
        } else if (anim == 2 && at < 20) {     // main du Créateur : abat le bras
            float k = at / 20F;
            this.right_arm.xRot = k < 0.45F ? -2.9F * (k / 0.45F) : -2.9F + 3.6F * ((k - 0.45F) / 0.55F);
            this.torso.yRot = -0.3F * k;
        } else if (anim == 3 && at < 45) {     // rugissement
            float k = Mth.sin(Mth.clamp(at / 45F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.8F * k; this.jaw.xRot = 1.0F * k;
            this.right_arm.zRot = 1.4F * k; this.left_arm.zRot = -1.4F * k;
            for (int i = 0; i < 3; i++) { this.right_wings[i].yRot = 0F; this.left_wings[i].yRot = 0F; this.right_wingtips[i].yRot = 0F; this.left_wingtips[i].yRot = 0F; }
        }
'''
print("créateur", len(m.parts), "pièces", boss_class("CreatorModel",m,MATS,A,TEX+'creator',face,JAVA,[P2,P3]))
