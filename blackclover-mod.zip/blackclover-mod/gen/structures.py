"""Génère les 3 structures d'invocation (.nbt) + toute la génération de monde (JSON)."""
import gzip, struct, math, random, json, os
HERE=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(HERE,'../src/main/resources/data/blackclover/')

# ---------------- Écrivain NBT minimal ----------------
class L:  # liste typée
    def __init__(s,tid,items): s.tid,s.items=tid,items
def _name(n): b=n.encode('utf-8'); return struct.pack('>H',len(b))+b
def _payload(v):
    if isinstance(v,bool): return struct.pack('>b',int(v))
    if isinstance(v,int): return struct.pack('>i',v)
    if isinstance(v,str): return _name(v)
    if isinstance(v,dict):
        out=b''
        for k,x in v.items(): out+=bytes([_tid(x)])+_name(k)+_payload(x)
        return out+b'\x00'
    if isinstance(v,L): return bytes([v.tid])+struct.pack('>i',len(v.items))+b''.join(_payload(i) for i in v.items)
    raise TypeError(v)
def _tid(v):
    if isinstance(v,bool): return 1
    if isinstance(v,int): return 3
    if isinstance(v,str): return 8
    if isinstance(v,L): return 9
    if isinstance(v,dict): return 10
def write_nbt(path,root):
    with gzip.open(path,'wb') as f: f.write(b'\x0a'+_name('')+_payload(root))

class Struct:
    def __init__(s,sx,sy,sz): s.size=(sx,sy,sz); s.blocks={}; s.nbt={}
    def set(s,x,y,z,name,props=None,nbt=None):
        if 0<=x<s.size[0] and 0<=y<s.size[1] and 0<=z<s.size[2]:
            s.blocks[(x,y,z)]=(name,tuple(sorted((props or {}).items())))
            if nbt: s.nbt[(x,y,z)]=nbt
            else: s.nbt.pop((x,y,z),None)
    def get(s,x,y,z): return s.blocks.get((x,y,z),(None,))[0]
    def save(s,path):
        pal=[]; idx={}
        blocks=[]
        for pos,st in s.blocks.items():
            if st not in idx: idx[st]=len(pal); pal.append(st)
            b={'pos':L(3,list(pos)),'state':idx[st]}
            if pos in s.nbt: b['nbt']=s.nbt[pos]
            blocks.append(b)
        palette=[{'Name':n,**({'Properties':dict(p)} if p else {})} for n,p in pal]
        write_nbt(path,{'DataVersion':3465,'size':L(3,list(s.size)),'palette':L(10,palette),'blocks':L(10,blocks),'entities':L(0,[])})
        return len(blocks)

def chest(st,x,y,z,facing,loot):
    st.set(x,y,z,'minecraft:chest',{'facing':facing,'type':'single','waterlogged':'false'},{'id':'minecraft:chest','LootTable':loot})

# =====================================================================
# A) RUINES DU DONJON (Gardien) — 25 x 14 x 25
# =====================================================================
r=random.Random(1)
S=Struct(25,14,25); C=12
for x in range(25):
    for z in range(25):
        d=math.hypot(x-C,z-C)
        if d>12.4: continue
        k=r.random()
        b='minecraft:stone_bricks' if k<0.45 else 'minecraft:mossy_stone_bricks' if k<0.72 else 'minecraft:cracked_stone_bricks' if k<0.93 else 'minecraft:mossy_cobblestone'
        if 5.4<d<6.4: b='minecraft:chiseled_stone_bricks'
        if d<1.5: b='minecraft:polished_andesite'
        if 2.5<d<3.3 and (x+z)%2==0: b='minecraft:sea_lantern'
        S.set(x,0,z,b)
        for y in range(1,14): S.set(x,y,z,'minecraft:air')
for i in range(8):
    a=i*math.pi/4+math.pi/8
    px,pz=round(C+math.cos(a)*10),round(C+math.sin(a)*10)
    h=r.randint(3,9)
    for y in range(1,h+1):
        S.set(px,y,pz,'minecraft:mossy_stone_bricks' if r.random()<0.4 else 'minecraft:stone_bricks')
    if h>=6: S.set(px,h+1,pz,'minecraft:soul_lantern',{'hanging':'false','waterlogged':'false'})
    else: S.set(px,h+1,pz,'minecraft:mossy_cobblestone_wall',{'east':'none','north':'none','south':'none','west':'none','up':'true','waterlogged':'false'})
    if r.random()<0.6: S.set(px+1,1,pz,'minecraft:cobweb')
for i in range(70):          # restes de murailles
    a=r.random()*2*math.pi
    if math.cos(a)<-0.5 and abs(math.sin(a))<0.4: continue
    x,z=round(C+math.cos(a)*12),round(C+math.sin(a)*12)
    for y in range(1,r.randint(1,4)): S.set(x,y,z,'minecraft:stone_bricks' if r.random()<0.6 else 'minecraft:cracked_stone_bricks')
for x in range(9,16):        # estrade de l'autel (au nord)
    for z in range(2,8): S.set(x,1,z,'minecraft:polished_andesite' if (x in(9,15) or z in(2,7)) else 'minecraft:chiseled_stone_bricks')
S.set(12,2,5,'blackclover:guardian_altar',{'facing':'south'})
chest(S,10,2,3,'south','blackclover:chests/dungeon_ruins'); chest(S,14,2,3,'south','blackclover:chests/dungeon_ruins')
for (x,z) in [(9,2),(15,2),(9,7),(15,7)]:
    S.set(x,2,z,'minecraft:stone_brick_wall',{'east':'none','north':'none','south':'none','west':'none','up':'true','waterlogged':'false'})
    S.set(x,3,z,'minecraft:soul_lantern',{'hanging':'false','waterlogged':'false'})
nA=S.save(DATA+'structures/dungeon_ruins.nbt')

# =====================================================================
# B) SANCTUAIRE ELFIQUE (Roi Elfe) — 27 x 16 x 27
# =====================================================================
r=random.Random(2)
S=Struct(27,16,27); C=13
flowers=['minecraft:lily_of_the_valley','minecraft:azure_bluet','minecraft:oxeye_daisy','minecraft:allium','minecraft:cornflower']
for x in range(27):
    for z in range(27):
        d=math.hypot(x-C,z-C)
        if d>13.4: continue
        if d>11.5:
            S.set(x,0,z,'minecraft:grass_block',{'snowy':'false'})
            for y in range(1,16): S.set(x,y,z,'minecraft:air')
            if r.random()<0.45: S.set(x,1,z,r.choice(flowers))
            continue
        b='minecraft:calcite' if r.random()<0.55 else 'minecraft:smooth_quartz'
        if 4.6<d<5.5 or 8.6<d<9.4: b='minecraft:quartz_bricks'
        if 8.9<d<9.1 or (d<4.6 and (abs(x-C)==abs(z-C))): b='minecraft:gold_block'
        if d<1.2: b='minecraft:glowstone'
        S.set(x,0,z,b)
        for y in range(1,16): S.set(x,y,z,'minecraft:air')
for i in range(8):
    a=i*math.pi/4
    px,pz=round(C+math.cos(a)*10),round(C+math.sin(a)*10)
    for y in range(1,10): S.set(px,y,pz,'minecraft:quartz_pillar',{'axis':'y'})
    S.set(px,10,pz,'minecraft:glowstone')
    for dx in (-1,0,1):
        for dz in (-1,0,1):
            for y in (10,11):
                if (dx,dz,y)!=(0,0,10) and r.random()<0.85:
                    S.set(px+dx,y,pz+dz,'minecraft:cherry_leaves',{'distance':'7','persistent':'true','waterlogged':'false'})
    S.set(px,1,pz+1 if i%2 else pz-1,'minecraft:amethyst_cluster',{'facing':'up','waterlogged':'false'})
for x in range(10,17):
    for z in range(3,9):
        S.set(x,1,z,'minecraft:smooth_quartz' if (x in(10,16) or z in(3,8)) else 'minecraft:quartz_bricks')
S.set(13,2,6,'blackclover:elf_altar',{'facing':'south'})
chest(S,11,2,4,'south','blackclover:chests/elf_sanctuary'); chest(S,15,2,4,'south','blackclover:chests/elf_sanctuary')
for (x,z) in [(10,3),(16,3),(10,8),(16,8)]: S.set(x,2,z,'minecraft:end_rod',{'facing':'up'})
nB=S.save(DATA+'structures/elf_sanctuary.nbt')

# =====================================================================
# C) PORTAIL DÉMONIAQUE (Archidémon, Nether, au-dessus de la mer de lave) — 29 x 24 x 29
# =====================================================================
r=random.Random(3)
S=Struct(29,24,29); C=14; F=11
for x in range(29):
    for z in range(29):
        d=math.hypot(x-C,z-C)
        if d>14.4: continue
        k=r.random()
        b='minecraft:blackstone' if k<0.38 else 'minecraft:polished_blackstone_bricks' if k<0.78 else 'minecraft:cracked_polished_blackstone_bricks' if k<0.9 else 'minecraft:magma_block'
        if 7<d<8: b='minecraft:crying_obsidian'
        if d<3 and (x==C or z==C): b='minecraft:shroomlight'
        if d<1: b='minecraft:crying_obsidian'
        S.set(x,F,z,b)
        for y in range(F+1,24): S.set(x,y,z,'minecraft:air')
for i in range(6):           # piliers de soutien plongeant dans la lave
    a=i*math.pi/3
    px,pz=round(C+math.cos(a)*9),round(C+math.sin(a)*9)
    for y in range(0,F):
        for dx in (0,1):
            for dz in (0,1): S.set(px+dx,y,pz+dz,'minecraft:polished_blackstone')
for i in range(6):           # pics d'obsidienne
    a=i*math.pi/3+math.pi/6
    cx,cz=C+math.cos(a)*11.5,C+math.sin(a)*11.5
    for h in range(10):
        rad=1.6*(1-h/10)+0.3
        for x in range(int(cx-2),int(cx+3)):
            for z in range(int(cz-2),int(cz+3)):
                if math.hypot(x-cx,z-cz)<=rad: S.set(x,F+1+h,z,'minecraft:crying_obsidian' if r.random()<0.3 else 'minecraft:obsidian')
for (x,z) in [(C-6,C-6),(C+6,C-6),(C-6,C+6),(C+6,C+6)]:   # braseros de feu des âmes
    S.set(x,F+1,z,'minecraft:polished_blackstone_bricks'); S.set(x,F+2,z,'minecraft:soul_soil'); S.set(x,F+3,z,'minecraft:soul_fire')
for x in range(10,19):       # la porte démoniaque derrière l'autel
    for y in range(F+1,F+12):
        edge = x in (10,18) or y in (F+1,F+11)
        if edge: S.set(x,y,2,'minecraft:crying_obsidian' if (x+y)%3==0 else 'minecraft:obsidian')
        else: S.set(x,y,2,'minecraft:red_stained_glass')
for x in range(11,18):
    for z in range(4,9): S.set(x,F+1,z,'minecraft:polished_blackstone' if (x in(11,17) or z in(4,8)) else 'minecraft:polished_blackstone_bricks')
S.set(C,F+2,6,'blackclover:demon_altar',{'facing':'south'})
chest(S,12,F+2,5,'south','blackclover:chests/demon_gate'); chest(S,16,F+2,5,'south','blackclover:chests/demon_gate')
nC=S.save(DATA+'structures/demon_gate.nbt')
if __name__=="__main__": print("blocs :",nA,nB,nC)

# ---------------- Génération de monde ----------------
def dump(p,o):
    os.makedirs(os.path.dirname(p),exist_ok=True); json.dump(o,open(p,'w'),indent=1)
BIOMES={
 'dungeon_ruins':["minecraft:plains","minecraft:forest","minecraft:taiga","minecraft:savanna","minecraft:dark_forest","minecraft:snowy_plains","minecraft:meadow","minecraft:windswept_hills"],
 'elf_sanctuary':["minecraft:forest","minecraft:birch_forest","minecraft:old_growth_birch_forest","minecraft:flower_forest","minecraft:cherry_grove","minecraft:meadow"],
 'demon_gate':["#minecraft:is_nether"],
}
PLACE={'dungeon_ruins':(32,12,918273645),'elf_sanctuary':(40,16,192837465),'demon_gate':(26,9,564738291)}
for n in BIOMES:
    dump(DATA+f'tags/worldgen/biome/has_{n}.json',{"values":BIOMES[n]})
    dump(DATA+f'tags/worldgen/structure/{n}.json',{"values":["blackclover:"+n]})
    nether = n=='demon_gate'
    st={"type":"minecraft:jigsaw","biomes":"#blackclover:has_"+n,"step":"surface_structures","spawn_overrides":{},
        "terrain_adaptation":"none" if nether else "beard_box","start_pool":f"blackclover:{n}/start","size":1,
        "start_height":{"absolute":21 if nether else 0},"max_distance_from_center":80,"use_expansion_hack":False}
    if not nether: st["project_start_to_heightmap"]="WORLD_SURFACE_WG"
    dump(DATA+f'worldgen/structure/{n}.json',st)
    sp,se,sa=PLACE[n]
    dump(DATA+f'worldgen/structure_set/{n}.json',{"structures":[{"structure":"blackclover:"+n,"weight":1}],
         "placement":{"type":"minecraft:random_spread","spacing":sp,"separation":se,"salt":sa}})
    dump(DATA+f'worldgen/template_pool/{n}/start.json',{"fallback":"minecraft:empty","elements":[{"weight":1,"element":{
         "element_type":"minecraft:single_pool_element","location":"blackclover:"+n,"projection":"rigid","processors":"minecraft:empty"}}]})
# coffres
def item(n,w,lo=1,hi=1):
    e={"type":"minecraft:item","name":n,"weight":w}
    if hi>1: e["functions"]=[{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":lo,"max":hi}}]
    return e
LOOT={
 'dungeon_ruins':[item("blackclover:mana_crystal",5,1,2),item("blackclover:tower_summons",3),item("minecraft:iron_ingot",8,2,5),item("minecraft:gold_ingot",6,1,3),item("minecraft:ender_pearl",4,1,2),item("minecraft:book",6,1,3),item("minecraft:lapis_lazuli",6,3,8)],
 'elf_sanctuary':[item("blackclover:mana_crystal",8,1,3),item("blackclover:ancient_page",4),item("minecraft:golden_apple",3),item("minecraft:amethyst_shard",6,2,5),item("minecraft:glowstone_dust",6,2,6),item("minecraft:ghast_tear",3)],
 'demon_gate':[item("blackclover:ancient_page",5,1,2),item("blackclover:mana_crystal",6,2,4),item("minecraft:netherite_scrap",2),item("minecraft:gold_block",3),item("minecraft:enchanted_golden_apple",1),item("minecraft:crying_obsidian",5,2,5)],
}
for n,entries in LOOT.items():
    dump(DATA+f'loot_tables/chests/{n}.json',{"type":"minecraft:chest","pools":[{"rolls":{"type":"minecraft:uniform","min":3,"max":6},"entries":entries}]})
print("ok")
