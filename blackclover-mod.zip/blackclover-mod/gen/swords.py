"""Modèles 3D des 4 épées d'anti-magie (designs originaux)."""
import json, os, random
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__))
ROOT=os.path.join(HERE,'../src/main/resources/assets/blackclover/')
random.seed(17)
def shade(c,f): return tuple(max(0,min(255,int(v*f))) for v in c)
DISPLAY={
 "gui":{"rotation":[0,0,0],"translation":[0,0,0],"scale":[0.8,0.8,0.8]},
 "ground":{"rotation":[0,0,0],"translation":[0,2,0],"scale":[0.5,0.5,0.5]},
 "fixed":{"rotation":[0,180,0],"translation":[0,0,0],"scale":[0.8,0.8,0.8]},
 "thirdperson_righthand":{"rotation":[0,-90,55],"translation":[0,4,0.5],"scale":[0.85,0.85,0.85]},
 "thirdperson_lefthand":{"rotation":[0,90,-55],"translation":[0,4,0.5],"scale":[0.85,0.85,0.85]},
 "firstperson_righthand":{"rotation":[0,-90,25],"translation":[1.13,3.2,1.13],"scale":[0.68,0.68,0.68]},
 "firstperson_lefthand":{"rotation":[0,90,-25],"translation":[1.13,3.2,1.13],"scale":[0.68,0.68,0.68]}}
def build(name, mats, els, gui_scale=0.8):
    names=list(mats); img=Image.new('RGBA',(16,16)); px=img.load(); cell={}
    for i,m in enumerate(names):
        cx,cy=(i%4)*4,(i//4)*4; cell[m]=(cx,cy); col,noise=mats[m]
        for x in range(4):
            for y in range(4):
                n=random.randint(-noise,noise); e=0.85 if (x in(0,3) or y in(0,3)) and noise>0 else 1
                px[cx+x,cy+y]=(*shade(tuple(v+n for v in col),e),255)
    img.save(ROOT+'textures/item/'+name+'.png')
    out=[]
    for fr,to,m in els:
        cx,cy=cell[m]; face={"uv":[cx+0.5,cy+0.5,cx+3.5,cy+3.5],"texture":"#t"}
        out.append({"from":fr,"to":to,"rotation":{"angle":-45,"axis":"z","origin":[8,8,8]},
                    "faces":{d:dict(face) for d in ("north","south","east","west","up","down")}})
    d=json.loads(json.dumps(DISPLAY)); d["gui"]["scale"]=[gui_scale]*3
    json.dump({"textures":{"t":"blackclover:item/"+name,"particle":"blackclover:item/"+name},"elements":out,"display":d},
              open(ROOT+'models/item/'+name+'.json','w'),indent=1)

BLACK=(28,26,30); STEEL=(70,68,76); EDGE=(150,148,158); RED=(210,30,30); LEATHER=(70,40,30); GOLD=(200,160,70)
# Épée du Démon : lame massive, brute, ébréchée
build("demon_slayer_sword",{"b":(BLACK,8),"e":(EDGE,10),"r":(RED,8),"m":(STEEL,8),"g":(LEATHER,6)},[
 ([7,-3,7.25],[9,-1.5,8.75],"m"),([7.4,-1.5,7.5],[8.6,3,8.5],"g"),([5,3,7.2],[11,4.2,8.8],"m"),([7.5,3.2,6.9],[8.5,4,9.1],"r"),
 ([5.5,4.2,7.6],[10.5,17,8.4],"b"),([5,5,7.7],[5.5,16,8.3],"e"),([10.5,5,7.7],[11,16,8.3],"e"),
 ([6.5,17,7.6],[9.5,19,8.4],"b"),([7.5,19,7.7],[8.5,20.5,8.3],"e"),
 ([7.6,6,8.4],[8.4,15,8.55],"r"),([7.6,6,7.45],[8.4,15,7.6],"r"),
 ([4.6,9,7.75],[5.1,10.2,8.25],"b"),([10.9,12,7.75],[11.4,13,8.25],"b")],0.75)
# Épée du Habitacle : élégante, lame évidée qui "contient" la magie
build("demon_dweller_sword",{"b":((45,44,52),6),"e":((230,230,236),6),"h":((60,20,90),8),"m":(STEEL,8),"g":((40,30,50),6)},[
 ([7.5,-2.5,7.5],[8.5,3,8.5],"g"),([7.2,-3.5,7.2],[8.8,-2.5,8.8],"m"),
 ([5.5,3,7.4],[10.5,4,8.6],"m"),([5,3.5,7.5],[5.8,5.5,8.5],"m"),([10.2,3.5,7.5],[11,5.5,8.5],"m"),
 ([6.8,4,7.65],[9.2,18,8.35],"b"),([9.2,5,7.7],[9.6,17,8.3],"e"),([6.4,5,7.7],[6.8,17,8.3],"e"),
 ([7.6,6,7.6],[8.4,15,8.4],"h"),([7.3,18,7.7],[8.7,19.5,8.3],"e")],0.8)
# Épée du Destructeur : lame dentelée, veines rouges, garde à pointes
build("demon_destroyer_sword",{"b":(BLACK,10),"r":((235,35,25),10),"s":((90,84,96),10),"m":(STEEL,8),"g":(LEATHER,6)},[
 ([7,-3.5,7.1],[9,-1.8,8.9],"s"),([7.4,-1.8,7.5],[8.6,3,8.5],"g"),
 ([5,3,7.3],[11,4.5,8.7],"m"),([4.2,3.5,7.6],[5,5.2,8.4],"s"),([11,3.5,7.6],[11.8,5.2,8.4],"s"),
 ([6.5,4.5,7.6],[9.5,17.5,8.4],"b"),([7.7,5,8.4],[8.3,17,8.55],"r"),([7.7,5,7.45],[8.3,17,7.6],"r"),
 ([5.6,6,7.7],[6.5,7.4,8.3],"s"),([9.5,7.5,7.7],[10.4,8.9,8.3],"s"),([5.6,10,7.7],[6.5,11.4,8.3],"s"),
 ([9.5,11.5,7.7],[10.4,12.9,8.3],"s"),([5.6,14,7.7],[6.5,15.2,8.3],"s"),([7,17.5,7.7],[9,19.5,8.3],"b"),([7.6,19.5,7.8],[8.4,20.8,8.2],"r")],0.75)
# Sabre du Démon : katana noir à lame fine et légèrement courbée
build("demon_slasher_katana",{"b":((22,22,26),6),"e":((215,215,225),6),"t":(GOLD,8),"g":((20,20,24),4),"w":((210,205,195),4)},[
 ([7.6,-4,7.6],[8.4,3,8.4],"g"),([7.55,-3,7.55],[8.45,-2.4,8.45],"w"),([7.55,-1,7.55],[8.45,-0.4,8.45],"w"),([7.55,1,7.55],[8.45,1.6,8.45],"w"),
 ([6.5,3,6.5],[9.5,3.6,9.5],"t"),([7.5,3.6,7.6],[8.5,4.4,8.4],"t"),
 ([7.6,4.4,7.75],[8.6,9,8.25],"b"),([8.6,4.6,7.8],[8.85,9,8.2],"e"),
 ([7.8,9,7.75],[8.8,13.5,8.25],"b"),([8.8,9,7.8],[9.05,13.5,8.2],"e"),
 ([8.05,13.5,7.75],[9.05,17.5,8.25],"b"),([9.05,13.5,7.8],[9.3,17.5,8.2],"e"),
 ([8.35,17.5,7.8],[9.2,19.8,8.2],"e")],0.85)
print("ok")
