import math, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from modelgen import Model, boss_class
HERE=os.path.dirname(os.path.abspath(__file__))
JAVA=os.path.join(HERE,'../src/main/java/com/blackclovermod/client/model/')
TEX=os.path.join(HERE,'../src/main/resources/assets/blackclover/textures/entity/')

def eyes(part_name, color, y_off=3, glow=True, spacing=None):
    def fp(px,gp,part,f,x0,y0,w,h):
        if part==part_name and f=='front' and w>=4:
            for ex in (x0+1, x0+w-3):
                for dx in range(2):
                    px[ex+dx,y0+y_off]=color+(255,)
                    if glow: gp[ex+dx,y0+y_off]=color+(255,)
    return fp
def combine(*fs):
    def fp(*a):
        for f in fs: f(*a)
    return fp

# =====================================================================
# GARDIEN DU DONJON v3 — colosse de pierre runique
# =====================================================================
g=Model(11)
g.part("pelvis","root",(0,4,0),(0,0,0),[(-7,-2,-4.5,14,5,9,'stone')])
g.part("waist","pelvis",(0,-2,0),(0,0,0),[(-6,-5,-4,12,5,8,'stone2')])
g.part("chest","waist",(0,-5,0),(8,0,0),[(-10,-12,-5.5,20,12,11,'stone'),(-7,-10,-6.5,14,8,1,'stone2'),(-8,-13,2,16,6,5,'moss')])
g.part("core","chest",(0,-6,-6.6),(0,0,0),[(-2,-2,-1,4,4,1,'rune',1)])
for i,(x,y) in enumerate([(-3.5,-6),(3.5,-6),(0,-9.5),(0,-2.5)]):
    g.part(f"rune_{i}","chest",(x,y,-6.7),(0,0,45),[(-0.5,-0.5,-0.5,1,1,1,'rune',1)])
for i,(x,z,rx,rz,hh) in enumerate([(-5,3,-25,-20,7),(0,4,-35,0,10),(5,3,-25,20,7),(-2.5,5,-45,-10,5),(2.5,5,-45,10,5)]):
    g.part(f"back_crystal_{i}","chest",(x,-12,z),(rx,0,rz),[(-1.5,-hh,-1.5,3,hh,3,'crystal',1)])
for i,x in enumerate([-6,-1,4]):
    g.chain(f"vine{i}","chest",(x,-1,5.5),[(5,0,0),(5,0,0),(5,0,0)],[(1,4,1)]*3,'vine')
g.groups['vines']=[f"vine{i}_{k}" for i in range(3) for k in range(3)]
g.part("head","chest",(0,-12,-3),(0,0,0),[(-4,-6,-4.5,8,7,8,'stone'),(-5,-6.5,-5.5,10,2,3,'stone2'),(-3,-3.5,-4.6,6,1,0,'rune',1)])
g.part("jaw","head",(0,0.5,-1),(0,0,0),[(-3.5,0,-3.5,7,2,6,'stone2')])
g.part("head_crystal_l","head",(2.5,-6,0),(-20,0,25),[(-1,-4,-1,2,4,2,'crystal',1)])
g.part("head_crystal_r","head",(-2.5,-6,0),(-20,0,-25),[(-1,-4,-1,2,4,2,'crystal',1)])
for side,s in (("right",-1),("left",1)):
    g.part(f"{side}_shoulder","chest",(s*11,-10,0),(0,0,0),[(-4.5,-4,-5,9,8,10,'stone'),(-4,-5,-4,8,1,8,'moss')])
    for i,(dx,rz,hh) in enumerate([(-2,-20,6),(1,5,8),(3,25,5)]):
        g.part(f"{side}_sh_crystal_{i}",f"{side}_shoulder",(dx*s,-4,0),(-10,0,rz*s),[(-1,-hh,-1,2,hh,2,'crystal',1)])
    g.part(f"{side}_arm",f"{side}_shoulder",(s*1,3,0),(0,0,0),[(-3.5,0,-3.5,7,10,7,'stone')])
    g.part(f"{side}_elbow",f"{side}_arm",(0,10,0),(0,0,0),[(-4,-1.5,-4,8,3,8,'stone2')])
    g.part(f"{side}_forearm",f"{side}_arm",(0,10,0),(0,0,0),[(-4.5,0,-4.5,9,11,9,'stone'),(-4.5,5,-4.5,9,1,9,'rune',1,0.05)])
    g.part(f"{side}_hand",f"{side}_forearm",(0,11,0),(0,0,0),[(-4,0,-4,8,5,8,'stone2')])
    for i in range(3):
        g.part(f"{side}_finger_{i}",f"{side}_hand",(-2.7+i*2.7,5,-2.5),(0,0,0),[(-1,0,-1,2,3,3,'stone')])
    g.part(f"{side}_thigh","pelvis",(s*4.5,1,0),(0,0,0),[(-3.5,0,-3.5,7,9,7,'stone')])
    g.part(f"{side}_shin",f"{side}_thigh",(0,9,0),(0,0,0),[(-3,0,-3,6,8,6,'stone2'),(-3.5,-1,-4,7,3,3,'stone')])
    g.part(f"{side}_foot",f"{side}_shin",(0,8,0),(0,0,0),[(-3.5,0,-5,7,2,8,'stone')])
for i,(x,z,rx,rz,hh) in enumerate([(-6,4,-30,-30,12),(6,4,-30,30,12),(0,5,-45,0,14)]):
    g.part(f"p2_crystal_{i}","chest",(x,-12,z),(rx,0,rz),[(-2,-hh,-2,4,hh,4,'crystal',1)])
for side in ("right","left"):
    for i in range(2):
        g.part(f"p2_spike_{side}{i}",f"{side}_forearm",(0,3+i*4,4.5),(40,0,0),[(-1,-4,-1,2,4,2,'crystal',1)])
for i in range(6):
    a=i*60
    g.part(f"p2_ring_{i}","chest",(math.cos(math.radians(a))*4,-6+math.sin(math.radians(a))*4,-6.8),(0,0,a),[(-0.5,-1,-0.5,1,2,1,'rune',1)])
GM={'stone':{'c':(122,122,130),'n':12,'p':'stone','accent':((80,112,62),0.07)},
    'stone2':{'c':(92,92,100),'n':10,'p':'stone'},'moss':{'c':(72,118,56),'n':16,'p':'hair'},
    'rune':{'c':(80,225,255),'n':10,'edge':False},'crystal':{'c':(120,235,255),'n':18,'p':'crystal'},
    'vine':{'c':(60,110,45),'n':14,'p':'hair'}}
def guard_face(px,gp,part,f,x0,y0,w,h):
    if part=='chest' and f=='front' and w>=20:
        for yy in range(y0+2,y0+h-2): gp[x0+w//2,yy]=(70,220,255,255); px[x0+w//2,yy]=(55,55,62,255)
GA='''
        this.head.yRot = yawR * 0.6F; this.head.xRot = pitchR * 0.5F;
        float walk = limbSwing * 0.45F, amt = Math.min(limbAmount, 1F);
        this.pelvis.y += Math.abs(Mth.sin(walk)) * -1.2F * amt + breathe * 0.3F;
        this.chest.zRot = Mth.sin(walk) * 0.08F * amt;
        this.chest.xRot += breathe * 0.03F - hurt * 0.25F;
        this.right_thigh.xRot = Mth.cos(walk) * 0.8F * amt;
        this.left_thigh.xRot = Mth.cos(walk + Mth.PI) * 0.8F * amt;
        this.right_shin.xRot = Math.max(0F, -Mth.cos(walk) * 0.9F) * amt;
        this.left_shin.xRot = Math.max(0F, Mth.cos(walk) * 0.9F) * amt;
        this.right_shoulder.xRot = Mth.cos(walk + Mth.PI) * 0.5F * amt;
        this.left_shoulder.xRot = Mth.cos(walk) * 0.5F * amt;
        this.right_forearm.xRot = -0.25F - Math.max(0F, Mth.cos(walk)) * 0.4F * amt;
        this.left_forearm.xRot = -0.25F - Math.max(0F, -Mth.cos(walk)) * 0.4F * amt;
        this.right_shoulder.zRot = 0.06F + breathe * 0.02F; this.left_shoulder.zRot = -0.06F - breathe * 0.02F;
        for (int i = 0; i < this.vines.length; i++) this.vines[i].xRot += Mth.sin(age * 0.07F + i * 0.6F) * 0.15F + amt * 0.3F;
        float glow = 1F + Mth.sin(age * 0.2F) * 0.15F;
        this.core.xScale = glow; this.core.yScale = glow;
        if (anim == 1 && at < 28) {            // FRAPPE SISMIQUE
            float up = at < 14 ? at / 14F : Mth.clamp(1F - (at - 14) / 3F, -0.4F, 1F);
            this.right_shoulder.xRot = -2.7F * up; this.left_shoulder.xRot = -2.7F * up;
            this.right_forearm.xRot = -0.6F * up; this.left_forearm.xRot = -0.6F * up;
            this.chest.xRot += -0.3F * up + (at > 14 ? 0.55F : 0F);
            if (at > 14) { this.right_thigh.xRot = -0.5F; this.left_thigh.xRot = -0.5F; this.right_shin.xRot = 0.8F; this.left_shin.xRot = 0.8F; this.pelvis.y += 3F; }
            this.jaw.xRot = 0.4F * Math.max(0F, up);
        } else if (anim == 2 && at < 16) {     // LANCER
            float k = at / 16F;
            this.right_shoulder.xRot = k < 0.5F ? -3.0F * (k * 2) : -3.0F + 4.0F * ((k - 0.5F) * 2);
            this.chest.yRot = (k < 0.5F ? 0.4F : -0.3F);
        } else if (anim == 3 && at < 34) {     // RUGISSEMENT
            float k = Mth.sin(Mth.clamp(at / 34F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.7F * k; this.jaw.xRot = 0.6F * k;
            this.right_shoulder.zRot = 1.1F * k; this.left_shoulder.zRot = -1.1F * k;
            this.chest.xRot -= 0.3F * k;
        }
        if (death > 0F) {                      // s'agenouille puis s'effondre
            this.pelvis.y += 9F * death;
            this.right_thigh.xRot = -1.4F * death; this.left_thigh.xRot = -1.4F * death;
            this.right_shin.xRot = 1.6F * death; this.left_shin.xRot = 1.6F * death;
            this.chest.xRot += 0.9F * death; this.head.xRot = 0.5F * death;
            this.right_shoulder.xRot = -0.4F * death; this.left_shoulder.xRot = -0.4F * death;
        }
'''
GM2=dict(GM); GM2['stone']={'c':(96,98,110),'n':12,'p':'stone','accent':((80,235,255),0.12),'accent_glow':True}
GM2['stone2']={'c':(70,72,84),'n':10,'p':'stone','accent':((80,235,255),0.08),'accent_glow':True}
s=boss_class("DungeonGuardianModel",g,GM,GA,TEX+'dungeon_guardian',combine(eyes('head',(90,240,255),4),guard_face),JAVA,[GM2])
print("gardien",len(g.parts),"pièces",s)

# =====================================================================
# ROI ELFE SPECTRAL v3
# =====================================================================
e=Model(12)
e.part("body","root",(0,-14,0),(0,0,0),[(-4,0,-2.5,8,12,5,'robe'),(-3.5,1,-3,7,5,1,'gold'),(-4.5,10,-3,9,2,6,'sash')])
e.part("collar","body",(0,0,1.5),(-15,0,0),[(-5,-5,0,10,6,1,'robe2')])
e.part("head","body",(0,-0.5,0),(0,0,0),[(-3.5,-7,-3.5,7,7,7,'skin'),(-4,-7.5,-4,8,2,8,'hair'),(-4,-6,2,8,6,2,'hair')])
for i,x in enumerate([-3,-1,1,3]):
    e.chain(f"hair{i}","head",(x,-1,3.5),[(10,0,0),(8,0,0),(6,0,0)],[(2,4,1)]*3,'hair')
e.groups['hair']=[f"hair{i}_{k}" for i in range(4) for k in range(3)]
e.part("right_ear","head",(-3.5,-3.5,0),(0,-25,-20),[(-5,-1,-0.5,5,2,1,'skin')])
e.part("left_ear","head",(3.5,-3.5,0),(0,25,20),[(0,-1,-0.5,5,2,1,'skin')])
e.part("crown","head",(0,-7.5,0),(0,0,0),[(-4,-1.5,-4,8,2,8,'gold',1),(-0.5,-3,-4.7,1,1,1,'gem',1)])
for i,(x,hh) in enumerate([(-3.5,2),(-2,3),(-0.5,5),(1,3),(2.5,2)]):
    e.part(f"crown_spike_{i}","crown",(x+0.5,-1.5,-4),(-10,0,0),[(-0.5,-hh,-0.5,1,hh,1,'gold',1)])
e.part("halo","head",(0,-11,3),(-25,0,0),[])
for i in range(10):
    a=i*2*math.pi/10
    e.part(f"halo_{i}","halo",(math.cos(a)*5,0,math.sin(a)*5),(0,-math.degrees(a)+90,0),[(-1.5,-0.5,-0.5,3,1,1,'halo',1)])
for side,s in (("right",-1),("left",1)):
    e.part(f"{side}_pauldron","body",(s*4,1,0),(0,0,s*20),[(-2+s*0,-2,-3,4,3,6,'gold',1)])
    e.part(f"{side}_arm","body",(s*5,1.5,0),(0,0,0),[(-1.5,-1,-1.5,3,7,3,'robe')])
    e.part(f"{side}_forearm",f"{side}_arm",(0,6,0),(0,0,0),[(-1.5,0,-1.5,3,5,3,'robe')])
    e.part(f"{side}_sleeve",f"{side}_forearm",(0,2,0),(15,0,0),[(-2.5,0,-2.5,5,5,5,'robe2'),(-2.5,4,-2.5,5,1,5,'gold')])
    e.part(f"{side}_hand",f"{side}_forearm",(0,5,0),(0,0,0),[(-1,0,-1,2,2,2,'skin'),(-1,2,-1,1,2,1,'skin'),(0,2,-1,1,2,1,'skin')])
    e.part(f"{side}_wing","body",(s*2,2,3),(0,s*-30,0),[])
    lens=[18,21,20,17,13,9]
    for i,L in enumerate(lens):
        ang=-10+i*16
        if s<0: e.part(f"{side}_feather_{i}",f"{side}_wing",(0,0,0),(0,0,ang),[(-L,-1.5,0,L,3,0,'feather',1)])
        else:   e.part(f"{side}_feather_{i}",f"{side}_wing",(0,0,0),(0,0,-ang),[(0,-1.5,0,L,3,0,'feather',1)])
    e.groups[f"{side}_feathers"]=[f"{side}_feather_{i}" for i in range(6)]
for i in range(8):
    a=i*2*math.pi/8
    e.part(f"skirt_{i}","body",(math.sin(a)*3.6,12,-math.cos(a)*2.6),(12,math.degrees(math.atan2(math.sin(a),-math.cos(a))),0),
           [(-2.5,0,0,5,16,1,'robe'),(-2.5,15,0,5,1,1,'gold')])
e.groups['skirt']=[f"skirt_{i}" for i in range(8)]
for side,sgn in (("right",-1),("left",1)):
    e.part(f"p2_{side}_wing","body",(sgn*2,-1,3),(0,sgn*-20,0),[])
    for i,L in enumerate([24,27,25,21]):
        ang=20+i*14
        if sgn<0: e.part(f"p2_{side}_feather_{i}",f"p2_{side}_wing",(0,0,0),(0,0,ang),[(-L,-2,0,L,4,0,'feather',1)])
        else: e.part(f"p2_{side}_feather_{i}",f"p2_{side}_wing",(0,0,0),(0,0,-ang),[(0,-2,0,L,4,0,'feather',1)])
e.part("p2_halo","head",(0,-12,4),(-25,0,0),[])
for i in range(14):
    a=i*2*math.pi/14
    e.part(f"p2_halo_{i}","p2_halo",(math.cos(a)*8,0,math.sin(a)*8),(0,-math.degrees(a)+90,0),[(-2,-0.5,-0.5,4,1,1,'halo',1)])
e.chain("cape","body",(0,0,2.8),[(8,0,0),(6,0,0),(6,0,0)],[(9,6,1)]*3,'cape',offset_z=0.5)
e.groups['cape_chain']=["cape_0","cape_1","cape_2"]
for i in range(4):
    e.part(f"orb_{i}","root",(0,-6,0),(45,0,45),[(-1,-1,-1,2,2,2,'gem',1)])
e.groups['orbs']=[f"orb_{i}" for i in range(4)]
EM={'skin':{'c':(238,214,196),'n':4},'robe':{'c':(246,244,238),'n':5,'p':'fabric','accent':((230,190,80),0.02)},
    'robe2':{'c':(225,228,238),'n':5,'p':'fabric'},'gold':{'c':(232,188,70),'n':12,'p':'metal'},
    'hair':{'c':(246,226,150),'n':10,'p':'hair'},'gem':{'c':(140,230,255),'n':10,'p':'crystal'},
    'halo':{'c':(255,245,190),'n':4,'edge':False},'feather':{'c':(255,236,170),'n':12,'p':'feather'},
    'sash':{'c':(80,165,200),'n':8,'p':'fabric'},'cape':{'c':(70,130,190),'n':8,'p':'fabric'}}
EA='''
        this.head.yRot = yawR; this.head.xRot = pitchR;
        float fall = death * 12F;
        this.body.y += Mth.sin(age * 0.06F) * 1.5F * (1F - death) + fall;
        this.body.xRot = -hurt * 0.2F + death * 0.4F;
        float flap = Mth.sin(age * 0.14F);
        float spread = 1F - death * 0.8F;
        this.right_wing.yRot += 0.15F + flap * 0.2F; this.left_wing.yRot -= 0.15F + flap * 0.2F;
        for (int i = 0; i < 6; i++) {
            float f = Mth.sin(age * 0.14F - i * 0.35F) * 0.08F;
            this.right_feathers[i].zRot = this.right_feathers[i].zRot * spread + f;
            this.left_feathers[i].zRot = this.left_feathers[i].zRot * spread - f;
        }
        for (int i = 0; i < this.skirt.length; i++) this.skirt[i].xRot += Mth.sin(age * 0.09F + i * 0.8F) * 0.06F;
        for (int i = 0; i < 3; i++) this.cape_chain[i].xRot += 0.08F + Mth.sin(age * 0.08F - i * 0.7F) * 0.08F;
        for (int i = 0; i < this.hair.length; i++) this.hair[i].xRot += Mth.sin(age * 0.07F - (i % 3) * 0.6F) * 0.07F;
        this.halo.yRot = age * 0.04F;
        for (int i = 0; i < 4; i++) {
            float a = age * 0.05F + i * Mth.HALF_PI;
            this.orbs[i].x = Mth.cos(a) * 11F; this.orbs[i].z = Mth.sin(a) * 11F;
            this.orbs[i].y = -6F + Mth.sin(age * 0.1F + i) * 2F + fall; this.orbs[i].yRot = age * 0.1F;
        }
        this.right_arm.zRot = 0.12F + breathe * 0.05F; this.left_arm.zRot = -0.12F - breathe * 0.05F;
        this.right_forearm.xRot = -0.3F; this.left_forearm.xRot = -0.3F;
        if (anim == 1 && at < 40) {            // PLUIE D'ÉPÉES : bras au ciel, ailes déployées
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.9F * k; this.left_arm.xRot = -2.9F * k;
            this.right_arm.zRot = 0.45F * k; this.left_arm.zRot = -0.45F * k;
            this.right_forearm.xRot = 0F; this.left_forearm.xRot = 0F;
            for (int i = 0; i < 6; i++) { this.right_feathers[i].zRot *= 1F + 0.4F * k; this.left_feathers[i].zRot *= 1F + 0.4F * k; }
            this.head.xRot = -0.4F * k;
        } else if (anim == 2 && at < 40) {     // JUGEMENT : désigne la cible
            float k = Mth.clamp(at / 6F, 0F, 1F);
            this.right_arm.xRot = -1.5F * k; this.right_forearm.xRot = 0F;
            this.left_arm.xRot = -0.4F * k; this.head.xRot += 0.25F * k;
        } else if (anim == 3 && at < 12) {     // TÉLÉPORTATION : les ailes se referment
            float k = 1F - at / 12F;
            this.right_wing.yRot += 1.0F * k; this.left_wing.yRot -= 1.0F * k;
        }
'''
EM2=dict(EM); EM2['robe']={'c':(255,242,204),'n':5,'p':'fabric','accent':((255,215,90),0.05),'accent_glow':True}
EM2['feather']={'c':(255,222,120),'n':12,'p':'feather'}; EM2['hair']={'c':(255,250,230),'n':8,'p':'hair'}
EM2['cape']={'c':(240,190,70),'n':8,'p':'fabric'}
s=boss_class("ElfKingModel",e,EM,EA+"""
        this.p2_halo.yRot = -age * 0.03F;
        float f2 = Mth.sin(age * 0.12F) * 0.15F;
        this.p2_right_wing.yRot += f2; this.p2_left_wing.yRot -= f2;""",TEX+'elf_king',eyes('head',(255,235,140),4),JAVA,[EM2])
print("elfe",len(e.parts),"pièces",s)

# =====================================================================
# ARCHIDÉMON MORVATH v3
# =====================================================================
d=Model(13)
d.part("hips","root",(0,-3,0),(0,0,0),[(-5,-3,-3.5,10,5,7,'skin'),(-3,1,-4,6,7,1,'cloth'),(-3.5,1,3,7,6,1,'cloth')])
d.part("abdomen","hips",(0,-3,0),(10,0,0),[(-4.5,-6,-3,9,6,6,'skin2')])
d.part("chest","abdomen",(0,-6,0),(10,0,0),[(-7.5,-11,-4.5,15,11,9,'skin')])
for i in range(3):
    d.part(f"rib_{i}","chest",(0,-8.5+i*2.8,-4.6),(0,0,0),[(-5.5,-0.5,-0.5,11,1,1,'sigil',1)])
for i in range(5):
    d.part(f"spine_{i}","chest",(0,-10+i*2.6,4.5),(-50,0,0),[(-0.5,-3+i*0.3,-0.5,1,3,1,'bone')])
d.part("neck","chest",(0,-11,-1),(-10,0,0),[(-2.5,-3,-2.5,5,3,5,'skin2')])
d.part("head","neck",(0,-3,-0.5),(0,0,0),[(-4,-7,-4,8,7,8,'skin'),(-4.5,-5,-4.8,9,2,2,'skin2'),(-2.5,-3,-6,5,3,2,'skin'),(-2.5,0,-6,5,1,1,'bone'),(-0.5,-6.2,-4.3,1,2,0,'eye',1)])
d.part("jaw","head",(0,-0.5,-1),(0,0,0),[(-3,0,-5,6,2,6,'skin2'),(-2.5,-1,-5,5,1,1,'bone')])
for side,s in (("right",-1),("left",1)):
    d.chain(f"{side}_horn","head",(s*3.5,-6,-1),[(0,0,s*55),(-25,0,s*10),(-25,0,s*5),(-30,0,-s*10),(-30,0,-s*15),(-25,0,-s*20)],
            [(3,4,3),(3,4,3),(2,4,2),(2,4,2),(1,4,1),(1,3,1)],'horn',down=False,group=f"{side}_horn_chain")
    d.part(f"{side}_horn_tip",f"{side}_horn_5",(0,-3,0),(0,0,0),[(-0.5,-2,-0.5,1,2,1,'sigil',1)])
    d.chain(f"{side}_hornb","head",(s*2.5,-6.5,2.5),[(-60,0,s*20),(-30,0,0)],[(2,3,2),(1,3,1)],'horn',down=False)
    d.part(f"{side}_pauldron","chest",(s*8,-9,0),(0,0,s*15),[(-3,-3,-3.5,6,4,7,'bone')])
    for i,(dz,rx) in enumerate([(-2,-20),(0,0),(2,20)]):
        d.part(f"{side}_spike_{i}",f"{side}_pauldron",(s*1,-3,dz),(rx,0,s*25),[(-0.5,-4,-0.5,1,4,1,'bone')])
    d.part(f"{side}_arm","chest",(s*9,-8,0),(0,0,0),[(-2.5,-1,-2.5,5,11,5,'skin')])
    d.part(f"{side}_forearm",f"{side}_arm",(0,10,0),(-20,0,0),[(-2.5,0,-2.5,5,10,5,'skin2'),(-0.5,2,2,1,3,2,'bone')])
    d.part(f"{side}_hand",f"{side}_forearm",(0,10,0),(0,0,0),[(-2,0,-2,4,3,4,'skin')])
    for i in range(4):
        d.part(f"{side}_finger_{i}",f"{side}_hand",(-1.5+i*1.0,3,-1.5),(-10,0,(i-1.5)*6),[(-0.5,0,-0.5,1,3,1,'skin2')])
        d.part(f"{side}_claw_{i}",f"{side}_finger_{i}",(0,3,0),(-25,0,0),[(-0.5,0,-0.5,1,3,1,'claw')])
    d.groups[f"{side}_fingers"]=[f"{side}_finger_{i}" for i in range(4)]
    # aile de chauve-souris : humérus, avant-bras, 4 doigts + membranes
    d.part(f"{side}_wing","chest",(s*3,-9,4),(0,0,0),[(min(0,s*8),-1,-1,8,2,2,'bone2'),(min(0,s*8),1,0,8,9,0,'memb')])
    d.part(f"{side}_wing_fore",f"{side}_wing",(s*8,0,0),(0,0,0),[(min(0,s*10),-1,-1,10,2,2,'bone2'),(min(0,s*10),1,0,10,12,0,'memb')])
    for i,(L,ang) in enumerate([(14,15),(16,-12),(14,-38),(11,-62)]):
        a=ang if s<0 else -ang
        d.part(f"{side}_wfinger_{i}",f"{side}_wing_fore",(s*10,0,0),(0,0,a),
               [(min(0,s*L),-0.5,-0.5,L,1,1,'bone2'),(min(0,s*L),0.5,0,L,7 if i<3 else 6,0,'memb')])
    d.groups[f"{side}_wfingers"]=[f"{side}_wfinger_{i}" for i in range(4)]
    d.part(f"{side}_thigh","hips",(s*3.5,1,0),(-25,0,0),[(-2.5,0,-3,5,11,6,'skin')])
    d.part(f"{side}_shin",f"{side}_thigh",(0,11,-1),(55,0,0),[(-2,0,-2,4,10,4,'skin2'),(-0.5,1,-3,1,3,1,'bone')])
    d.part(f"{side}_ankle",f"{side}_shin",(0,10,0),(-45,0,0),[(-1.5,0,-1.5,3,6,3,'skin')])
    d.part(f"{side}_foot",f"{side}_ankle",(0,6,0),(15,0,0),[(-2.5,0,-4,5,2,6,'skin2'),(-2.5,0.5,-5.5,1,1,2,'claw'),(-0.5,0.5,-5.5,1,1,2,'claw'),(1.5,0.5,-5.5,1,1,2,'claw')])
for side,sg in (("right",-1),("left",1)):
    d.chain(f"p2_{side}_horn","head",(sg*4,-3,1),[(30,0,sg*80),(20,0,sg*20),(25,0,sg*10),(30,0,-sg*10),(30,0,-sg*15)],
            [(3,4,3),(3,4,3),(2,4,2),(2,3,2),(1,3,1)],'horn',down=False)
    for i in range(3):
        d.part(f"p3_blade_{side}{i}",f"{side}_forearm",(sg*2.5,2+i*3,0),(0,0,sg*-60),[(-0.5,-5,-1,1,5,2,'sigil',1)])
for i in range(7):
    a=-60+i*20
    d.part(f"p3_flame_{i}","head",(math.sin(math.radians(a))*3.5,-7,-math.cos(math.radians(a))*2+1),(-15,0,a*0.4),[(-0.5,-6+abs(i-3),-0.5,1,6-abs(i-3),1,'sigil',1)])
d.part("p3_eyes","head",(0,-4.5,-4.4),(0,0,0),[(-3.5,-0.5,0,7,1,0,'eye',1)])
sizes=[(3,5,3),(3,5,3),(2,5,2),(2,5,2),(2,4,2),(1,4,1),(1,4,1),(1,3,1)]
d.chain("tail","hips",(0,0,3),[(50,0,0)]+[(12,0,0)]*7,sizes,'skin',group='tail_chain')
d.part("tail_blade","tail_7",(0,3,0),(0,0,0),[(-2,0,-0.5,4,3,1,'sigil',1),(-1,3,-0.5,2,2,1,'sigil',1)])
DM={'skin':{'c':(36,30,38),'n':8,'p':'scales','accent':((125,14,14),0.05)},'skin2':{'c':(54,42,52),'n':8,'p':'scales'},
    'bone':{'c':(214,204,188),'n':10,'p':'bone'},'bone2':{'c':(70,56,66),'n':8,'p':'bone'},
    'horn':{'c':(205,196,180),'n':10,'p':'bone','accent':((90,80,70),0.12)},'claw':{'c':(232,226,214),'n':6},
    'memb':{'c':(92,16,24),'n':10,'p':'membrane','edge':False},'sigil':{'c':(240,40,30),'n':10,'edge':False},
    'eye':{'c':(255,60,40),'n':0,'edge':False},'cloth':{'c':(60,20,30),'n':8,'p':'fabric'}}
def demon_face(px,gp,part,f,x0,y0,w,h):
    if part=='chest' and f=='front' and w>=15:
        for i in range(7):
            for (xx,yy) in ((x0+3+i,y0+2+i),(x0+w-4-i,y0+2+i)):
                gp[xx,yy]=(230,30,25,255); px[xx,yy]=(120,10,10,255)
DA='''
        this.head.yRot = yawR * 0.8F; this.head.xRot = pitchR * 0.6F;
        boolean spread = e.phase() >= 2;
        float walk = limbSwing * 0.55F, amt = Math.min(limbAmount, 1F);
        this.chest.xRot += breathe * 0.04F - hurt * 0.3F;
        this.chest.zRot = Mth.sin(walk) * 0.06F * amt;
        this.jaw.xRot = 0.08F + Mth.sin(age * 0.05F) * 0.05F;
        float flap = Mth.sin(age * (spread ? 0.16F : 0.09F));
        float open = spread ? 1F : 0.35F;
        this.right_wing.yRot = 0.9F - open * 0.75F + flap * 0.25F; this.left_wing.yRot = -0.9F + open * 0.75F - flap * 0.25F;
        this.right_wing.zRot = -0.25F + flap * 0.15F; this.left_wing.zRot = 0.25F - flap * 0.15F;
        this.right_wing_fore.yRot = 1.4F * (1F - open) + flap * 0.15F; this.left_wing_fore.yRot = -1.4F * (1F - open) - flap * 0.15F;
        for (int i = 0; i < 4; i++) {
            this.right_wfingers[i].zRot *= 0.4F + 0.6F * open; this.left_wfingers[i].zRot *= 0.4F + 0.6F * open;
        }
        for (int i = 0; i < this.tail_chain.length; i++) {
            this.tail_chain[i].yRot = Mth.sin(age * 0.09F - i * 0.5F) * 0.18F;
            this.tail_chain[i].xRot += Mth.sin(age * 0.06F - i * 0.4F) * 0.04F - death * 0.15F;
        }
        this.right_thigh.xRot += Mth.cos(walk) * 0.8F * amt; this.left_thigh.xRot += Mth.cos(walk + Mth.PI) * 0.8F * amt;
        this.right_shin.xRot += Math.max(0F, Mth.cos(walk)) * 0.4F * amt; this.left_shin.xRot += Math.max(0F, -Mth.cos(walk)) * 0.4F * amt;
        this.right_arm.xRot = Mth.cos(walk + Mth.PI) * 0.5F * amt; this.left_arm.xRot = Mth.cos(walk) * 0.5F * amt;
        this.right_arm.zRot = 0.18F + breathe * 0.04F; this.left_arm.zRot = -0.18F - breathe * 0.04F;
        for (int i = 0; i < 4; i++) {
            float c = Mth.sin(age * 0.1F + i) * 0.1F;
            this.right_fingers[i].xRot += c; this.left_fingers[i].xRot += c;
        }
        if (anim == 1 && at < 30) {            // INCANTATION : bras au ciel, gueule ouverte
            float k = Mth.clamp(at / 8F, 0F, 1F);
            this.right_arm.xRot = -2.3F * k; this.left_arm.xRot = -2.3F * k;
            this.right_arm.zRot = 0.6F * k; this.left_arm.zRot = -0.6F * k;
            this.right_forearm.xRot = -0.1F; this.left_forearm.xRot = -0.1F;
            this.head.xRot -= 0.35F * k; this.jaw.xRot = 0.7F * k;
            for (int i = 0; i < 4; i++) { this.right_fingers[i].zRot *= 3F; this.left_fingers[i].zRot *= 3F; }
        } else if (anim == 2 && at < 14) {     // GRIFFE
            float k = at / 14F;
            this.right_arm.xRot = k < 0.4F ? -2.8F * (k / 0.4F) : -2.8F + 3.8F * ((k - 0.4F) / 0.6F);
            this.right_arm.yRot = -0.6F * k; this.chest.yRot = -0.35F * k;
            this.jaw.xRot = 0.4F;
        } else if (anim == 3 && at < 40) {     // RUGISSEMENT DE TRANSFORMATION
            float k = Mth.sin(Mth.clamp(at / 40F, 0F, 1F) * Mth.PI);
            this.head.xRot = -0.9F * k; this.jaw.xRot = 0.95F * k;
            this.right_arm.zRot = 1.3F * k; this.left_arm.zRot = -1.3F * k;
            this.right_wing.yRot = 0.05F; this.left_wing.yRot = -0.05F;
            this.right_wing_fore.yRot = 0F; this.left_wing_fore.yRot = 0F;
            this.chest.xRot -= 0.4F * k;
        }
        if (death > 0F) {                      // s'effondre à genoux, ailes pendantes
            this.hips.y += 10F * death;
            this.right_thigh.xRot -= 1.0F * death; this.left_thigh.xRot -= 1.0F * death;
            this.right_shin.xRot += 0.8F * death; this.left_shin.xRot += 0.8F * death;
            this.chest.xRot += 0.8F * death; this.head.xRot = 0.6F * death; this.jaw.xRot = 0.6F * death;
            this.right_wing.zRot += 0.9F * death; this.left_wing.zRot -= 0.9F * death;
            this.right_arm.xRot = -0.3F * death; this.left_arm.xRot = -0.3F * death;
        }
'''
DM2=dict(DM); DM2['skin']={'c':(40,28,38),'n':8,'p':'scales','accent':((220,30,25),0.10),'accent_glow':True}
DM2['memb']={'c':(130,20,30),'n':10,'p':'membrane','edge':False}
DM3=dict(DM2); DM3['skin']={'c':(70,12,16),'n':10,'p':'scales','accent':((255,120,40),0.16),'accent_glow':True}
DM3['skin2']={'c':(48,10,14),'n':8,'p':'scales','accent':((255,90,30),0.10),'accent_glow':True}
DM3['memb']={'c':(200,40,30),'n':12,'p':'membrane','edge':False}
s=boss_class("ArchdemonModel",d,DM,DA,TEX+'archdemon',combine(eyes('head',(255,40,30),3),demon_face),JAVA,[DM2,DM3])
print("démon",len(d.parts),"pièces",s)
