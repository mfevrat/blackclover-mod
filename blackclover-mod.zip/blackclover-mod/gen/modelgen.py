"""Générateur de modèles Minecraft (Java) + textures peintes.
Utilisé pour les boss (v3) et les armures d'ordre."""
import math, random
from PIL import Image

def clamp(v): return max(0, min(255, int(v)))

# ---------------- Motifs de peinture ----------------
def pat_plain(c,x,y,w,h,face,rnd): return c
def pat_stone(c,x,y,w,h,face,rnd):
    k=1.0
    if rnd.random()<0.06: k=0.6                       # fissures
    if (x*7+y*13)%11==0: k*=0.85
    return tuple(v*k for v in c)
def pat_scales(c,x,y,w,h,face,rnd):
    k=0.78 if (y%3==0) or ((x+(y//3)%2*2)%4==0 and y%3==1) else 1.0
    return tuple(v*k for v in c)
def pat_fabric(c,x,y,w,h,face,rnd):
    k=1.0-0.12*((x%3)==0)                            # plis verticaux
    k*=1.0-0.15*(y/max(1,h-1)) if face in('front','back','left','right') else 1
    return tuple(v*k for v in c)
def pat_metal(c,x,y,w,h,face,rnd):
    k=1.25 if (x+y)%5==0 else (0.85 if y==h-1 else 1.0)
    return tuple(v*k for v in c)
def pat_membrane(c,x,y,w,h,face,rnd):
    k=0.65 if (x%5==0 or (x+y)%7==0) else 1.0           # veines
    k*=0.8+0.3*(y/max(1,h-1))
    return tuple(v*k for v in c)
def pat_feather(c,x,y,w,h,face,rnd):
    k=1.0
    if y==h//2: k=1.25                                    # rachis
    k*=0.75+0.35*(x/max(1,w-1))
    if (x+y)%4==0: k*=0.9
    return tuple(v*k for v in c)
def pat_bone(c,x,y,w,h,face,rnd):
    k=0.85 if (y%4==0) else 1.0
    return tuple(v*k for v in c)
def pat_crystal(c,x,y,w,h,face,rnd):
    k=1.35 if (x==y or x==w-1-y) else 1.0
    return tuple(v*k for v in c)
def pat_hair(c,x,y,w,h,face,rnd):
    k=0.85 if x%2==0 else 1.05
    return tuple(v*k for v in c)
PATTERNS={'plain':pat_plain,'stone':pat_stone,'scales':pat_scales,'fabric':pat_fabric,'metal':pat_metal,
          'membrane':pat_membrane,'feather':pat_feather,'bone':pat_bone,'crystal':pat_crystal,'hair':pat_hair}

class Model:
    def __init__(self, seed=1):
        self.parts=[]; self.groups={}; self.rnd=random.Random(seed); self.names=set()
    def part(self,name,parent,pivot=(0,0,0),rot=(0,0,0),cubes=()):
        assert name not in self.names, name
        self.names.add(name)
        self.parts.append((name,parent,pivot,rot,list(cubes))); return name
    def chain(self,prefix,parent,pivot,rots,sizes,mat,glow=0,down=True,group=None,offset_z=0.0):
        """Chaîne de segments (queue, corne, cheveux...). sizes=[(w,h,d)], rots=[(rx,ry,rz)] en degrés."""
        names=[]; par=parent; pv=pivot
        for i,((w,h,d),r) in enumerate(zip(sizes,rots)):
            y0 = 0 if down else -h
            n=self.part(f"{prefix}_{i}",par,pv,r,[(-w/2,y0,-d/2+offset_z,w,h,d,mat,glow)])
            names.append(n); par=n; pv=(0,h if down else -h,0)
        if group: self.groups[group]=names
        return names

    # ---------------- Écriture Java + texture ----------------
    def build(self, mats, size=(256,256), face_paint=None):
        tw,th=size
        img=Image.new('RGBA',(tw,th),(0,0,0,0)); glow=Image.new('RGBA',(tw,th),(0,0,0,0))
        px,gp=img.load(),glow.load()
        x=y=row=0
        code=[]
        for (name,parent,pivot,rot,cubes) in self.parts:
            cb="CubeListBuilder.create()"
            for c in cubes:
                cx,cy,cz,w,h,d,mat=c[:7]; gl=c[7] if len(c)>7 else 0; infl=c[8] if len(c)>8 else 0
                fw,fh=max(1,2*d+2*w),max(1,d+h)
                if x+fw>tw: x=0; y+=row; row=0
                if y+fh>th: raise OverflowError
                u,v=x,y; x+=fw; row=max(row,fh)
                deform=f", new CubeDeformation({infl}F)" if infl else ""
                cb+=f".texOffs({u}, {v}).addBox({cx}F, {cy}F, {cz}F, {w}F, {h}F, {d}F{deform})"
                self._paint(px,gp,u,v,w,h,d,mats[mat],gl,name,face_paint)
            rx,ry,rz=[f"{math.radians(a):.4f}F" for a in rot]
            pv=[f"{p:.3f}F" for p in pivot]
            src='root' if parent=='root' else 'p_'+parent
            code.append(f'        PartDefinition p_{name} = {src}.addOrReplaceChild("{name}", {cb}, PartPose.offsetAndRotation({pv[0]}, {pv[1]}, {pv[2]}, {rx}, {ry}, {rz}));')
        return code,img,glow

    def _paint(self,px,gp,u,v,w,h,d,mat,gl,part,face_paint):
        base=mat['c']; noise=mat.get('n',8); pat=PATTERNS[mat.get('p','plain')]; rnd=self.rnd
        faces={'top':(u+d,v,w,d,1.12),'bottom':(u+d+w,v,w,d,0.7),'right':(u,v+d,d,h,0.86),
               'front':(u+d,v+d,w,h,1.0),'left':(u+d+w,v+d,d,h,0.86),'back':(u+2*d+w,v+d,w,h,0.8)}
        for fname,(x0,y0,fw,fh,f) in faces.items():
            for xx in range(x0,x0+fw):
                for yy in range(y0,y0+fh):
                    lx,ly=xx-x0,yy-y0
                    c=pat(base,lx,ly,fw,fh,fname,rnd)
                    k=rnd.randint(-noise,noise)
                    edge=0.82 if (lx in(0,fw-1) or ly in(0,fh-1)) and fw>2 and fh>2 and mat.get('edge',True) else 1
                    col=tuple(clamp((ch+k)*f*edge) for ch in c)
                    if 'accent' in mat and rnd.random()<mat['accent'][1]: col=mat['accent'][0]
                    px[xx,yy]=(*col,255)
                    if gl: gp[xx,yy]=(clamp(col[0]*1.25),clamp(col[1]*1.25),clamp(col[2]*1.25),255)
            if face_paint: face_paint(px,gp,part,fname,x0,y0,fw,fh)

def find_size(model,mats,face_paint=None):
    for s in [(128,128),(256,128),(256,256),(512,256),(512,512)]:
        try:
            model.rnd=random.Random(7)
            return s,model.build(mats,s,face_paint)
        except OverflowError: pass
    raise Exception("modèle trop grand")

def boss_class(cls, model, mats, anim, texpath, face_paint=None, java_dir=None):
    size,(code,img,glow)=find_size(model,mats,face_paint)
    img.save(texpath+'.png'); glow.save(texpath+'_glow.png')
    fields=[f"    public final ModelPart {n};" for (n,*_) in model.parts]
    gfields=[f"    public final ModelPart[] {g};" for g in model.groups]
    ctor=[]
    for (n,parent,*_) in model.parts:
        src='root' if parent=='root' else 'this.'+parent
        ctor.append(f'        this.{n} = {src}.getChild("{n}");')
    for g,names in model.groups.items():
        ctor.append(f"        this.{g} = new ModelPart[]{{{', '.join('this.'+n for n in names)}}};")
    java=f'''package com.blackclovermod.client.model;

import com.blackclovermod.entity.boss.MagicBossEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Modèle 3D ORIGINAL ({len(model.parts)} pièces), généré par gen/bosses_v3.py. Les animations sont dans setupAnim. */
public class {cls}<T extends MagicBossEntity> extends HierarchicalModel<T> {{
    private final ModelPart root;
{chr(10).join(fields)}
{chr(10).join(gfields)}

    public {cls}(ModelPart root) {{
        this.root = root;
{chr(10).join(ctor)}
    }}

    public static LayerDefinition createBodyLayer() {{
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
{chr(10).join(code)}
        return LayerDefinition.create(mesh, {size[0]}, {size[1]});
    }}

    @Override
    public ModelPart root() {{ return root; }}

    @Override
    public void setupAnim(T e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {{
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        int anim = e.animId();
        float at = e.animTime(pt);
        float breathe = Mth.sin(age * 0.08F);
        float hurt = e.hurtTime > 0 ? Mth.sin((e.hurtTime - pt) / 10F * Mth.PI) : 0F;
        float death = e.deathTime > 0 ? Mth.clamp((e.deathTime + pt) / 40F, 0F, 1F) : 0F;
        float yawR = headYaw * Mth.DEG_TO_RAD, pitchR = headPitch * Mth.DEG_TO_RAD;
{anim}
    }}
}}
'''
    open(java_dir+cls+'.java','w').write(java)
    return size
