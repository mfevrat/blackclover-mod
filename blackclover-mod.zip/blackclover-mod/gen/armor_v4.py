"""Tenues d'ordre v4 : formes travaillées + textures brodées. Un modèle par ordre."""
import os, sys, math, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from modelgen import Model
HERE=os.path.dirname(os.path.abspath(__file__))
JAVA=os.path.join(HERE,'../src/main/java/com/blackclovermod/client/model/')
TEX=os.path.join(HERE,'../src/main/resources/assets/blackclover/textures/models/armor/')

#          principal       sombre         doublure        broderie       métal          emblème        plumes/accent  motif
ORDERS={
 "onyx_ravens":   ((74,60,96),  (46,38,62),  (140,72,196), (222,182,86),(168,168,184),(205,165,255),(66,56,88),  "raven"),
 "azure_stags":   ((44,92,178), (28,60,124), (232,234,242),(220,224,238),(196,204,222),(255,255,255),(240,240,248),'filigree'),
 "scarlet_phoenix":((176,36,30),(112,20,18), (252,206,96), (244,192,62),(228,178,72), (255,224,130),(255,150,40), 'flame'),
 "jade_serpents": ((38,124,78), (22,82,50),  (226,206,152),(196,146,72),(176,134,72), (182,250,182),(60,150,90),  'scales'),
 "silver_owls":   ((224,226,234),(160,166,184),(92,104,136),(112,124,156),(184,190,206),(72,84,124), (200,190,170),'owl'),
}

def build(oid):
    main,dark,lining,gold,metal,emb,acc,motif=ORDERS[oid]
    m=Model(abs(hash(oid))%1000)
    # ---- pièces obligatoires du modèle humanoïde ----
    m.part("head","root",(0,0,0),(0,0,0),[(-4,-8,-4,8,8,8,'hood',0,1.0)])
    m.part("hat","root",(0,0,0),(0,0,0),[])
    m.part("body","root",(0,0,0),(0,0,0),[(-4,0,-2,8,12,4,'coat',0,1.02)])
    m.part("right_arm","root",(-5,2,0),(0,0,0),[(-3,-2,-2,4,12,4,'sleeve',0,1.0)])
    m.part("left_arm","root",(5,2,0),(0,0,0),[(-1,-2,-2,4,12,4,'sleeve',0,1.0)])
    m.part("right_leg","root",(-1.9,12,0),(0,0,0),[])
    m.part("left_leg","root",(1.9,12,0),(0,0,0),[])
    # ---- capuche ----
    m.part("hood_peak","head",(0,-8.6,2.5),(-40,0,0),[(-3,-3,-1.5,6,4,3,'hood')])
    m.part("hood_rim_top","head",(0,-8.4,-5.15),(0,0,0),[(-4.5,0,0,9,1,1,'gold')])
    m.part("hood_rim_r","head",(-4.5,-8,-5.15),(0,0,0),[(0,0,0,1,7,1,'gold')])
    m.part("hood_rim_l","head",(3.5,-8,-5.15),(0,0,0),[(0,0,0,1,7,1,'gold')])
    m.part("hood_drape","head",(0,-1.5,4.6),(12,0,0),[(-4.5,0,-1,9,5,2,'hood')])
    m.part("hood_drape2","hood_drape",(0,5,0),(10,0,0),[(-4,0,-1,8,3,2,'hood')])
    # ---- manteau ----
    m.part("capelet","body",(0,-0.5,0),(0,0,0),[(-5.5,0,-3.4,11,5,7,'cape')])
    m.part("collar_back","body",(0,-0.2,2.6),(-18,0,0),[(-4.5,-3.5,0,9,4,1,'lining')])
    m.part("collar_r","body",(-2.6,-0.2,-3.3),(0,0,0),[(-2,-2,0,3,3,1,'lining')])
    m.part("collar_l","body",(2.6,-0.2,-3.3),(0,0,0),[(-1,-2,0,3,3,1,'lining')])
    m.part("lapel_r","body",(-1.1,4.5,-3.15),(0,0,0),[(-1,0,0,1,7,0,'gold')])
    m.part("lapel_l","body",(1.1,4.5,-3.15),(0,0,0),[(0,0,0,1,7,0,'gold')])
    for i,y in enumerate((5.5,7.2,8.9) if False else (5.5,7.2)):
        m.part(f"button_{i}","body",(0,y,-3.3),(0,0,45),[(-0.5,-0.5,-0.5,1,1,1,'metal')])
    m.part("emblem","body",(0,3,-3.4),(0,0,45),[(-1.5,-1.5,-0.5,3,3,1,'emb',1)])
    m.part("belt","body",(0,9.2,0),(0,0,0),[(-4.6,0,-2.8,9,2,5,'leather'),(-1.2,-0.3,-3.4,2,2,1,'metal')])
    m.part("pouch","belt",(2.6,0.5,-3.3),(0,0,0),[(-1,0,-0.5,2,2,1,'leather')])
    m.part("skirt_front_r","body",(-2,11,-2.7),(-8,0,6),[(-2,0,-0.5,4,8,1,'skirt')])
    m.part("skirt_front_l","body",(2,11,-2.7),(-8,0,-6),[(-2,0,-0.5,4,8,1,'skirt')])
    m.part("skirt_back","body",(0,11,2.7),(10,0,0),[(-4.5,0,-0.5,9,10,1,'skirt')])
    m.part("skirt_r","body",(-4.6,11,0),(0,0,10),[(-0.5,0,-2.2,1,8,4,'skirt')])
    m.part("skirt_l","body",(4.6,11,0),(0,0,-10),[(-0.5,0,-2.2,1,8,4,'skirt')])
    # ---- bras : épaulettes en deux plaques, brassards, gants ----
    for side,s,arm in (("r",-1,"right_arm"),("l",1,"left_arm")):
        m.part(f"pauldron_{side}",arm,(s*1,-2.8,0),(0,0,s*-20),[(-3.2,-1,-3.2,6,3,6,'plate')])
        m.part(f"pauldron2_{side}",f"pauldron_{side}",(s*1.5,2,0),(0,0,s*-12),[(-2.5,0,-2.8,5,2,5,'plate')])
        m.part(f"bracer_{side}",arm,(s*1,5.5,0),(0,0,0),[(-2.6,0,-2.6,5,3,5,'leather')])
        m.part(f"glove_{side}",arm,(s*1,8.6,0),(0,0,0),[(-2.4,0,-2.4,4,3,4,'glove',0,0.3)])
    # ---- accessoires uniques ----
    if oid=="onyx_ravens":
        m.part("beak","head",(0,-8.5,-5.2),(25,0,0),[(-1.5,0,-2.5,3,1,3,'metal')])
        m.part("beak_tip","beak",(0,0.5,-2.5),(20,0,0),[(-0.5,0,-1.5,1,1,2,'metal')])
        for i,(x,rz,hh) in enumerate([(-2,-18,8),(0,0,10),(2,18,8)]):
            m.part(f"plume_{i}","head",(x,-9,1.5),(-40,0,rz),[(-1,-hh,0,2,hh,0,'feather')])
        for i in range(7):
            a=-90+i*30
            m.part(f"ruff_{i}","body",(math.sin(math.radians(a))*4.6,0,-math.cos(math.radians(a))*2.8 if abs(a)<90 else 2.8),(-50,a,0),[(-1.5,-5,0,3,5,0,'feather')])
        for side,s in (("r",-1),("l",1)):
            for i in range(3):
                m.part(f"fringe_{side}{i}",f"pauldron2_{side}",(s*0.5,1.5,-2+i*2),(0,0,s*-15),[(-1,0,0,2,4,0,'feather')])
    elif oid=="azure_stags":
        for side,s in (("r",-1),("l",1)):
            m.chain(f"antler_{side}","head",(s*3,-8.6,-1),[(-10,0,s*42),(-20,0,-s*25),(-20,0,s*12)],[(1,4,1),(1,4,1),(1,3,1)],'metal',down=False)
            for i,(seg,rx,rz,hh) in enumerate([(0,-40,48,3),(1,-30,-45,3),(1,30,40,2),(2,-20,-35,2)]):
                m.part(f"tine_{side}{i}",f"antler_{side}_{seg}",(0,-2.5,0),(rx,0,s*rz),[(-0.5,-hh,-0.5,1,hh,1,'metal')])
        m.part("fur_collar","capelet",(0,0,0),(0,0,0),[(-6,-1,-3.8,12,2,8,'fur')])
    elif oid=="scarlet_phoenix":
        for i,(z,hh) in enumerate([(-3,4),(-1.5,6),(0,7),(1.5,6),(3,4)]):
            m.part(f"crest_{i}","head",(0,-9,z),(-25+i*10,0,0),[(-0.5,-hh,-1,1,hh,2,'flame',1)])
        for side,s in (("r",-1),("l",1)):
            for i in range(4):
                m.part(f"wingflame_{side}{i}",f"pauldron_{side}",(s*1,-1,1),(-20,0,s*(-30-i*18)),[(-1,-6+i,0,2,6-i,0,'flame',1)])
        m.chain("plume","head",(0,-5,4.8),[(45,0,0),(25,0,0),(15,0,0),(10,0,0)],[(3,4,0),(3,4,0),(2,4,0),(2,3,0)],'flame',glow=1)
    elif oid=="jade_serpents":
        for side,s in (("r",-1),("l",1)):
            m.part(f"cobra_{side}","head",(s*4.6,-7.5,1),(0,s*-28,s*14),[(min(0,s*5),0,-0.5,5,9,1,'scale')])
            m.part(f"cobra_eye_{side}",f"cobra_{side}",(s*2.5,3,-0.7),(0,0,0),[(-0.5,-0.5,-0.2,1,1,0,'emb',1)])
            m.part(f"fang_{side}","hood_rim_top",(s*1.5,1,0),(0,0,0),[(-0.5,0,-0.5,1,2,1,'bone')])
            for i in range(3):
                m.part(f"scaleplate_{side}{i}",f"pauldron2_{side}",(0,1+i*1.2,0),(0,0,0),[(-2.5,0,-2.8,5,1,5,'scale')])
            for i in range(5):
                a=i*72
                m.part(f"coil_{side}{i}",f"right_arm" if s<0 else "left_arm",(s*1+math.cos(math.radians(a))*2.7,4+i*0.9,math.sin(math.radians(a))*2.7),(0,-a,25),[(-1,-0.5,-0.5,2,1,1,'scale')])
        m.part("scale_crest","head",(0,-9,-2),(-10,0,0),[(-1,-1,0,2,1,8,'gold')])
    elif oid=="silver_owls":
        for side,s in (("r",-1),("l",1)):
            m.part(f"tuft_{side}","head",(s*3,-9,-1),(-15,0,s*30),[(-1.5,-5,0,3,5,0,'feather')])
            m.part(f"goggle_{side}","head",(s*2,-6.8,-5.3),(0,0,0),[(-1.5,-1.5,-0.5,3,3,1,'metal'),(-1,-1,-0.7,2,2,0,'emb',1)])
        for row,(y,n,L) in enumerate([(0,7,5),(2.5,7,5)]):
            for i in range(n):
                a=-90+i*30
                m.part(f"owlf_{row}_{i}","capelet",(math.sin(math.radians(a))*5.2,y,-math.cos(math.radians(a))*3.4 if abs(a)<90 else 3.4),(10,a,0),[(-1.5,0,0,3,L,0,'feather')])
    B=lambda c,w=1: (c,w)
    mats={
     'hood':{'c':main,'n':6,'p':'fabric','border':B(gold),'border_top':False,'stitch':lining},
     'coat':{'c':main,'n':6,'p':motif if motif in('raven','filigree','owl') else 'fabric','border':B(gold),'stitch':gold},
     'cape':{'c':dark,'n':6,'p':'fabric','border':B(gold),'border_top':False,'stitch':lining},
     'skirt':{'c':main,'n':6,'p':'fabric','border':B(gold,1),'border_top':False,'stitch':lining},
     'sleeve':{'c':main,'n':6,'p':'fabric','border':B(gold),'border_top':False},
     'lining':{'c':lining,'n':5,'p':'fabric'},
     'gold':{'c':gold,'n':6,'p':'metal','edge':False},
     'metal':{'c':metal,'n':6,'p':'metal'},
     'plate':{'c':metal,'n':6,'p':'metal','border':B(gold),'border_all':True},
     'emb':{'c':emb,'n':3,'edge':False},
     'leather':{'c':(96,64,42),'n':6,'border':B((140,100,60))},
     'glove':{'c':dark,'n':5},
     'feather':{'c':acc,'n':10,'p':'raven' if oid=='onyx_ravens' else 'feather'},
     'fur':{'c':lining,'n':14,'p':'hair'},
     'flame':{'c':(255,120,30),'n':14,'p':'flame','edge':False},
     'scale':{'c':main,'n':8,'p':'scales','border':B(gold),'border_all':True},
     'bone':{'c':(236,230,214),'n':4},
    }
    def face(px,gp,part,f,x0,y0,w,h):
        if part=='head' and f=='front':     # visage ouvert, bordé de doublure
            for xx in range(x0+1,x0+w-1):
                for yy in range(y0+2,y0+h):
                    px[xx,yy]=(0,0,0,0)
            for xx in range(x0,x0+w): px[xx,y0+1]=lining+(255,)
            for yy in range(y0+1,y0+h): px[x0,yy]=lining+(255,); px[x0+w-1,yy]=lining+(255,)
        if part=='body' and f=='back':        # grand emblème brodé dans le dos
            cx,cy=x0+w//2,y0+h//2
            for dx in range(-2,3):
                for dy in range(-2,3):
                    if abs(dx)+abs(dy)<=2: px[cx+dx,cy+dy]=(emb if abs(dx)+abs(dy)<2 else gold)+(255,)
    for size in [(128,128),(256,128),(256,256)]:
        try:
            code,img,glow=m.build(mats,size,face); break
        except OverflowError: pass
    img.save(TEX+oid+'_armor.png')
    return code,size,len(m.parts)

methods=[]
for oid in ORDERS:
    code,size,n=build(oid)
    name=''.join(w.capitalize() for w in oid.split('_'))
    print(oid,n,"pièces",size)
    methods.append(f'''    public static LayerDefinition create{name}() {{
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
{chr(10).join(code)}
        return LayerDefinition.create(mesh, {size[0]}, {size[1]});
    }}
''')
java=f'''package com.blackclovermod.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tenues d'ordre en 3D (v4) : capuche pointue bordée d'or, mantelet, col, revers, boutons, ceinture et sacoche,
 * pans de manteau, épaulettes à deux plaques, brassards, gants + accessoire unique. Généré par gen/armor_v4.py.
 */
public class OrderArmorModel extends HumanoidModel<LivingEntity> {{

    public OrderArmorModel(ModelPart root) {{
        super(root);
    }}

{chr(10).join(methods)}}}
'''
open(JAVA+'OrderArmorModel.java','w').write(java)
