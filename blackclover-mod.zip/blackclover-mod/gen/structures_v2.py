"""Nouvelles structures : Trône du Créateur (End), Colisée des Chevaliers-Mages, 5 quartiers généraux d'ordre."""
import math, random, json, os, struct
from structures import Struct, L, write_nbt, chest, dump, item, DATA

class D(float): pass   # TAG_Double
import structures as S0
_old=S0._payload
def _payload(v):
    if isinstance(v,D): return struct.pack('>d',v)
    return _old(v)
_oldtid=S0._tid
def _tid(v):
    if isinstance(v,D): return 6
    return _oldtid(v)
S0._payload=_payload; S0._tid=_tid
# les listes de Double doivent utiliser le bon type
def LD(vals): return L(6,[D(v) for v in vals])

class StructE(Struct):
    def __init__(s,*a): super().__init__(*a); s.entities=[]
    def entity(s,x,y,z,nbt): s.entities.append({'blockPos':L(3,[x,y,z]),'pos':LD([x+0.5,y,z+0.5]),'nbt':nbt})
    def save(s,path):
        pal=[]; idx={}; blocks=[]
        for pos,st in s.blocks.items():
            if st not in idx: idx[st]=len(pal); pal.append(st)
            b={'pos':L(3,list(pos)),'state':idx[st]}
            if pos in s.nbt: b['nbt']=s.nbt[pos]
            blocks.append(b)
        palette=[{'Name':n,**({'Properties':dict(p)} if p else {})} for n,p in pal]
        write_nbt(path,{'DataVersion':3465,'size':L(3,list(s.size)),'palette':L(10,palette),'blocks':L(10,blocks),
                        'entities':L(10,s.entities) if s.entities else L(0,[])})
        return len(blocks)

def disc(S,c,y,r,fn):
    for x in range(S.size[0]):
        for z in range(S.size[2]):
            d=math.hypot(x-c,z-c)
            if d<=r: b=fn(x,z,d); 
            else: continue
            if b: S.set(x,y,z,*b) if isinstance(b,tuple) else S.set(x,y,z,b)
def clear(S,c,r,y0,y1):
    for x in range(S.size[0]):
        for z in range(S.size[2]):
            if math.hypot(x-c,z-c)<=r:
                for y in range(y0,y1): S.set(x,y,z,'minecraft:air')

# =====================================================================
# TRÔNE DU CRÉATEUR (End) — 33 x 22 x 33
# =====================================================================
r=random.Random(5); S=StructE(33,22,33); C=16
clear(S,C,16.4,1,22)
disc(S,C,0,16.4,lambda x,z,d: 'minecraft:crying_obsidian' if 7<d<8 else ('minecraft:obsidian' if d<2 else ('minecraft:purpur_block' if (int(d)%4==0) else ('minecraft:end_stone_bricks' if r.random()<0.7 else 'minecraft:cracked_stone_bricks'))))
for i in range(8):
    a=i*math.pi/4
    px,pz=round(C+math.cos(a)*14),round(C+math.sin(a)*14)
    for y in range(1,13):
        for dx in (0,1):
            for dz in (0,1): S.set(px+dx,y,pz+dz,'minecraft:crying_obsidian' if y%4==0 else 'minecraft:obsidian')
    S.set(px,13,pz,'minecraft:end_rod',{'facing':'up'}); S.set(px+1,13,pz+1,'minecraft:end_rod',{'facing':'up'})
# le trône (au nord)
for x in range(C-4,C+5):
    for z in range(2,7):
        for y in range(1,3): S.set(x,y,z,'minecraft:purpur_pillar',{'axis':'y'} ) if (x in (C-4,C+4)) else S.set(x,y,z,'minecraft:obsidian')
for x in range(C-3,C+4):
    for y in range(3,12): S.set(x,y,2,'minecraft:obsidian' if (x+y)%3 else 'minecraft:crying_obsidian')
for y in range(12,16): S.set(C,y,2,'minecraft:purpur_pillar',{'axis':'y'})
S.set(C,16,2,'minecraft:end_rod',{'facing':'up'})
for x in (C-3,C+3):
    for y in range(3,6): S.set(x,y,4,'minecraft:purpur_pillar',{'axis':'y'})
S.set(C,1,C-8,'blackclover:origin_altar',{'facing':'south'})
chest(S,C-2,1,C-9,'south','blackclover:chests/creator_throne'); chest(S,C+2,1,C-9,'south','blackclover:chests/creator_throne')
print("trône",S.save(DATA+'structures/creator_throne.nbt'))

# =====================================================================
# COLISÉE DES CHEVALIERS-MAGES — 41 x 18 x 41
# =====================================================================
r=random.Random(6); S=StructE(41,18,41); C=20
clear(S,C,20.6,1,18)
def colfloor(x,z,d):
    if d<3.5: return 'minecraft:gold_block' if (abs(x-C)+abs(z-C))%3==0 else 'minecraft:quartz_bricks'
    if d<14: return 'minecraft:smooth_sandstone' if (int(d)%5) else 'minecraft:cut_sandstone'
    return 'minecraft:sandstone'
disc(S,C,0,20.6,colfloor)
WOOL={'onyx_ravens':'black_wool','azure_stags':'blue_wool','scarlet_phoenix':'red_wool','jade_serpents':'green_wool','silver_owls':'white_wool'}
for x in range(41):
    for z in range(41):
        d=math.hypot(x-C,z-C); a=math.degrees(math.atan2(z-C,x-C))%360
        gate=any(abs(((a-g)+180)%360-180)<6 for g in (0,90,180,270))
        if 14.5<d<=19.5 and not gate:                  # gradins
            h=int((d-14.5))+1
            for y in range(1,h+1): S.set(x,y,z,'minecraft:smooth_sandstone' if y<h else 'minecraft:cut_sandstone')
        if 19.5<d<=20.6:                                 # mur extérieur avec arches
            top=11 if not gate else 0
            for y in range(1,12):
                if gate and y<=5: continue
                S.set(x,y,z,'minecraft:chiseled_sandstone' if y in (6,11) else 'minecraft:sandstone')
        if 13.9<d<14.6 and not gate: S.set(x,1,z,'minecraft:sandstone_wall',{'east':'none','north':'none','south':'none','west':'none','up':'true','waterlogged':'false'})
# 5 loges de capitaine sur les gradins (repérées par un bloc de magnétite sous le siège)
for i,(oid,wool) in enumerate(WOOL.items()):
    a=math.radians(i*72+18)
    tx,tz=round(C+math.cos(a)*17.5),round(C+math.sin(a)*17.5)
    for dx in (-1,0,1):
        for dz in (-1,0,1):
            for y in range(1,5): S.set(tx+dx,y,tz+dz,'minecraft:smooth_sandstone')
            S.set(tx+dx,5,tz+dz,'minecraft:'+wool.replace('wool','carpet'))
    S.set(tx,4,tz,'minecraft:lodestone')
    ox,oz=round(C+math.cos(a)*19),round(C+math.sin(a)*19)
    for y in range(5,9): S.set(ox,y,oz,'minecraft:'+wool)
    S.set(ox,9,oz,'minecraft:lantern',{'hanging':'false','waterlogged':'false'})
for i in range(8):                                       # braseros autour de l'arène
    a=i*math.pi/4+math.pi/8
    x,z=round(C+math.cos(a)*13),round(C+math.sin(a)*13)
    S.set(x,1,z,'minecraft:chiseled_sandstone'); S.set(x,2,z,'minecraft:campfire',{'facing':'north','lit':'true','signal_fire':'false','waterlogged':'false'})
S.set(C,1,C,'blackclover:exam_pedestal')
print("colisée",S.save(DATA+'structures/knight_colosseum.nbt'))

# =====================================================================
# QUARTIERS GÉNÉRAUX DES ORDRES — 23 x 18 x 23
# =====================================================================
HQ={ #           murs                         bordures                         toit                              accent                  bannière
 'onyx_ravens':('minecraft:deepslate_bricks','minecraft:polished_blackstone','minecraft:blackstone','minecraft:amethyst_block','black_wool'),
 'azure_stags':('minecraft:stone_bricks','minecraft:polished_diorite','minecraft:dark_prismarine','minecraft:lapis_block','blue_wool'),
 'scarlet_phoenix':('minecraft:bricks','minecraft:smooth_red_sandstone','minecraft:red_terracotta','minecraft:gold_block','red_wool'),
 'jade_serpents':('minecraft:mossy_stone_bricks','minecraft:polished_andesite','minecraft:green_terracotta','minecraft:emerald_block','green_wool'),
 'silver_owls':('minecraft:calcite','minecraft:smooth_quartz','minecraft:light_gray_terracotta','minecraft:quartz_bricks','white_wool'),
}
for oid,(wall,trim,roof,accent,wool) in HQ.items():
    r=random.Random(hash(oid)%999); S=StructE(23,18,23); C=11
    for x in range(23):
        for z in range(23):
            S.set(x,0,z,'minecraft:dirt_path' if (x==C or z==C) and (abs(x-C)>6 or abs(z-C)>6) else ('minecraft:grass_block' if (abs(x-C)>6 or abs(z-C)>6) else trim),{'snowy':'false'} if not ((x==C or z==C) and (abs(x-C)>6 or abs(z-C)>6)) and (abs(x-C)>6 or abs(z-C)>6) else None)
            for y in range(1,18): S.set(x,y,z,'minecraft:air')
    for x in range(C-6,C+7):                 # corps du bâtiment
        for z in range(C-6,C+7):
            edge = x in (C-6,C+6) or z in (C-6,C+6)
            corner = x in (C-6,C+6) and z in (C-6,C+6)
            for y in range(1,8):
                if corner: S.set(x,y,z,trim)
                elif edge:
                    win = y in (3,4) and (x-C)%3==0 and (z-C)%3==0 and not (x==C and z==C+6)
                    S.set(x,y,z,'minecraft:glass_pane' if win and False else ('minecraft:glass' if win else (trim if y==7 else wall)))
            S.set(x,0,z,trim if (x+z)%2 else 'minecraft:polished_andesite')
    for y in range(1,4): S.set(C,y,C+6,'minecraft:air')            # porte
    S.set(C,4,C+6,accent)
    for k in range(0,7):                                            # toit en pyramide
        for x in range(C-6+k,C+7-k):
            for z in range(C-6+k,C+7-k):
                if x in (C-6+k,C+6-k) or z in (C-6+k,C+6-k): S.set(x,8+k,z,roof)
    S.set(C,15,C,accent)
    for (x,z) in [(C-6,C-6),(C+6,C-6),(C-6,C+6),(C+6,C+6)]:       # tourelles d'angle
        for y in range(8,12): S.set(x,y,z,trim)
        S.set(x,12,z,'minecraft:lantern',{'hanging':'false','waterlogged':'false'})
    for x in (C-2,C+2):                                             # bannières de l'ordre de chaque côté de la porte
        for y in range(2,6): S.set(x,y,C+7,'minecraft:'+wool)
    # intérieur
    for x in range(C-5,C+6):
        for z in range(C-5,C+6):
            if math.hypot(x-C,z-C)<2.5: S.set(x,0,z,accent)
    S.set(C,1,C-4,'minecraft:'+wool.replace('wool','carpet')); 
    for x in (C-5,C+5):
        for z in (C-5,C+5): S.set(x,1,z,'minecraft:lantern',{'hanging':'false','waterlogged':'false'})
    chest(S,C-4,1,C-5,'south','blackclover:chests/order_hq'); chest(S,C+4,1,C-5,'south','blackclover:chests/order_hq')
    for x in range(C-5,C+6,2): S.set(x,1,C-5,'minecraft:bookshelf') if x not in (C-4,C+4) else None
    S.entity(C,1,C-3,{'id':'blackclover:captain','Order':oid,'PersistenceRequired':True,'Home':True})
    print(oid,S.save(DATA+f'structures/hq_{oid}.nbt'))

# ---------------- Génération de monde ----------------
BIOMES={
 'creator_throne':["minecraft:end_highlands","minecraft:end_midlands"],
 'knight_colosseum':["minecraft:plains","minecraft:sunflower_plains","minecraft:meadow","minecraft:savanna"],
 'hq_onyx_ravens':["minecraft:dark_forest","minecraft:old_growth_spruce_taiga","minecraft:old_growth_pine_taiga"],
 'hq_azure_stags':["minecraft:taiga","minecraft:snowy_taiga","minecraft:grove","minecraft:snowy_plains"],
 'hq_scarlet_phoenix':["minecraft:savanna","minecraft:desert","minecraft:badlands","minecraft:savanna_plateau"],
 'hq_jade_serpents':["minecraft:jungle","minecraft:sparse_jungle","minecraft:swamp","minecraft:mangrove_swamp"],
 'hq_silver_owls':["minecraft:birch_forest","minecraft:old_growth_birch_forest","minecraft:cherry_grove","minecraft:flower_forest"],
}
PLACE={'creator_throne':(30,10,734591),'knight_colosseum':(36,14,283746),'hq_onyx_ravens':(40,16,1001),'hq_azure_stags':(40,16,1002),
       'hq_scarlet_phoenix':(40,16,1003),'hq_jade_serpents':(40,16,1004),'hq_silver_owls':(40,16,1005)}
for n in BIOMES:
    dump(DATA+f'tags/worldgen/biome/has_{n}.json',{"values":BIOMES[n]})
    dump(DATA+f'tags/worldgen/structure/{n}.json',{"values":["blackclover:"+n]})
    dump(DATA+f'worldgen/structure/{n}.json',{"type":"minecraft:jigsaw","biomes":"#blackclover:has_"+n,"step":"surface_structures","spawn_overrides":{},
        "terrain_adaptation":"beard_box","start_pool":f"blackclover:{n}/start","size":1,"start_height":{"absolute":0},
        "project_start_to_heightmap":"WORLD_SURFACE_WG","max_distance_from_center":80,"use_expansion_hack":False})
    sp,se,sa=PLACE[n]
    dump(DATA+f'worldgen/structure_set/{n}.json',{"structures":[{"structure":"blackclover:"+n,"weight":1}],"placement":{"type":"minecraft:random_spread","spacing":sp,"separation":se,"salt":sa}})
    dump(DATA+f'worldgen/template_pool/{n}/start.json',{"fallback":"minecraft:empty","elements":[{"weight":1,"element":{"element_type":"minecraft:single_pool_element","location":"blackclover:"+n,"projection":"rigid","processors":"minecraft:empty"}}]})
dump(DATA+'loot_tables/chests/creator_throne.json',{"type":"minecraft:chest","pools":[{"rolls":{"type":"minecraft:uniform","min":4,"max":7},"entries":[
    item("blackclover:ancient_page",6,1,3),item("blackclover:mana_crystal",6,2,5),item("blackclover:demon_fragment",1),item("minecraft:enchanted_golden_apple",2),item("minecraft:diamond",5,2,5),item("minecraft:netherite_ingot",1)]}]})
dump(DATA+'loot_tables/chests/order_hq.json',{"type":"minecraft:chest","pools":[{"rolls":{"type":"minecraft:uniform","min":2,"max":5},"entries":[
    item("blackclover:mana_crystal",6,1,2),item("blackclover:tower_summons",2),item("minecraft:book",6,1,3),item("minecraft:bread",8,2,6),item("minecraft:iron_ingot",6,1,4),item("minecraft:experience_bottle",4,2,6)]}]})
print("ok")
