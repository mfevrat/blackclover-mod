"""Génère les modèles 3D (JSON 'elements') + textures 16x16 des objets.
Chaque matériau occupe une case 4x4 de la texture de l'objet."""
import json, os, random
from PIL import Image
random.seed(3)
ROOT='../src/main/resources/assets/blackclover/'
MOD=ROOT+'models/item/'; TEX=ROOT+'textures/item/'

def shade(c,f): return tuple(max(0,min(255,int(v*f))) for v in c)

def build(name, mats, elements, display, extra_textures=None):
    """mats: dict nom -> (couleur, bruit, tint?) ; elements: liste (from,to,mat,[rot])"""
    names=list(mats)
    img=Image.new('RGBA',(16,16),(0,0,0,0)); px=img.load()
    cell={}
    for i,m in enumerate(names):
        cx,cy=(i%4)*4,(i//4)*4; cell[m]=(cx,cy)
        col,noise=mats[m][0],mats[m][1]
        for x in range(4):
            for y in range(4):
                n=random.randint(-noise,noise)
                edge = 0.85 if (x in (0,3) or y in (0,3)) and noise>0 else 1.0
                c=shade(tuple(v+n for v in col),edge)
                px[cx+x,cy+y]=(*c,255)
    img.save(TEX+name+'.png')
    els=[]
    for e in elements:
        fr,to,m=e[0],e[1],e[2]
        cx,cy=cell[m]
        uv=[cx+0.5,cy+0.5,cx+3.5,cy+3.5]
        face={"uv":uv,"texture":"#t"}
        if len(mats[m])>2 and mats[m][2]: face["tintindex"]=0
        el={"from":fr,"to":to,"faces":{d:dict(face) for d in ("north","south","east","west","up","down")}}
        if len(e)>3 and e[3]:
            ax,ang=e[3]
            orig=[(fr[i]+to[i])/2 for i in range(3)]
            el["rotation"]={"angle":ang,"axis":ax,"origin":orig}
        els.append(el)
    model={"credit":"Black Clover : Grimoires","textures":{"t":"blackclover:item/"+name,"particle":"blackclover:item/"+name},
           "elements":els,"display":display}
    json.dump(model,open(MOD+name+'.json','w'),indent=1)

# Présentations standard
def disp(gui=(25,-35,0),gs=0.85,hand=0.55,ground=0.45,trans=(0,0,0)):
    return {
     "gui":{"rotation":list(gui),"translation":list(trans),"scale":[gs]*3},
     "ground":{"rotation":[0,0,0],"translation":[0,2,0],"scale":[ground]*3},
     "fixed":{"rotation":[0,180,0],"translation":[0,0,0],"scale":[0.8]*3},
     "thirdperson_righthand":{"rotation":[0,90,0],"translation":[0,2.5,1],"scale":[hand]*3},
     "thirdperson_lefthand":{"rotation":[0,90,0],"translation":[0,2.5,1],"scale":[hand]*3},
     "firstperson_righthand":{"rotation":[0,-75,10],"translation":[1.5,3,0],"scale":[hand*0.9]*3},
     "firstperson_lefthand":{"rotation":[0,-75,-10],"translation":[1.5,3,0],"scale":[hand*0.9]*3},
     "head":{"rotation":[0,180,0],"translation":[0,13,7],"scale":[1,1,1]}}

GOLD=(236,186,54); GOLDD=(170,120,30); PAGE=(240,230,205)

# ---------- GRIMOIRE (3 / 4 / 5 feuilles) ----------
def grimoire(name, leaves, emblem=GOLD, emb_dark=GOLDD, metal=GOLD):
    mats={"cover":((200,200,200),10,True),"spine":((150,150,150),8,True),"page":(PAGE,8),
          "metal":(metal,10),"emblem":(emblem,6),"embd":(emb_dark,0),"strap":((95,62,38),8)}
    el=[
     ([3,1,9],[13,15,10],"cover"),     # couverture avant
     ([3,1,6],[13,15,7],"cover"),      # couverture arrière
     ([3,1,6],[4,15,10],"spine"),      # dos
     ([4,1.6,7],[12.6,14.4,9],"page"), # pages
     ([12.4,7,5.8],[13.6,9,10.2],"strap"),  # fermoir
     ([12.6,7.4,10.2],[13.8,8.6,10.5],"metal"),
    ]
    for (x,y) in [(3,1),(12,1),(3,14),(12,14)]:
        el.append(([x-0.2,y-0.2,10],[x+1.2,y+1.2,10.4],"metal"))
    # trèfle sur la couverture
    import math
    cx,cy=8,9
    for i in range(leaves):
        a=math.pi/2+i*2*math.pi/leaves
        lx,ly=cx+math.cos(a)*1.9,cy+math.sin(a)*1.9
        el.append(([lx-1.1,ly-1.1,10],[lx+1.1,ly+1.1,10.5],"emblem"))
    el.append(([7.6,3.6,10],[8.4,7.4,10.4],"embd"))
    # dos décoré
    for y in (3,7.5,12): el.append(([2.8,y,5.8],[4.2,y+0.8,10.2],"metal"))
    build(name,mats,el,disp())
grimoire("grimoire",3)
grimoire("grimoire_4",4,(120,230,120),(60,150,60))
grimoire("grimoire_5",5,(170,25,25),(60,0,0),metal=(70,70,75))

# ---------- CRISTAL DE MANA ----------
build("mana_crystal",{"c1":((90,200,255),20),"c2":((40,120,230),15),"c3":((200,245,255),10),"base":((110,90,70),10)},[
 ([6,3,6],[10,12,10],"c1",("y",45)),
 ([7,12,7],[9,15,9],"c3",("y",45)),
 ([7,1,7],[9,3,9],"c2",("y",45)),
 ([3.5,2,7],[6,8,9],"c2",("z",22.5)),
 ([10,2,7],[12.5,7,9],"c1",("z",-22.5)),
 ([5,0,5],[11,1.5,11],"base"),
],disp(gui=(20,30,0)))

# ---------- CLÉ DU DONJON ----------
build("dungeon_key",{"g":(GOLD,12),"gd":(GOLDD,8),"gem":((80,220,255),10)},[
 ([7.4,1,7.4],[8.6,10,8.6],"g"),
 ([5,10,7.4],[11,11,8.6],"g"),([5,14,7.4],[11,15,8.6],"g"),
 ([5,11,7.4],[6,14,8.6],"g"),([10,11,7.4],[11,14,8.6],"g"),
 ([7.2,11.7,7.2],[8.8,13.3,8.8],"gem"),
 ([8.6,2,7.6],[10.5,3,8.4],"gd"),([8.6,4,7.6],[9.8,5,8.4],"gd"),
 ([6.8,8.5,7],[9.2,9.5,9],"gd"),
],disp(gui=(0,0,-45),gs=0.95))

# ---------- LARME ELFIQUE ----------
build("elf_tear",{"t1":((255,240,170),12),"t2":((255,250,215),8),"core":((255,255,255),0)},[
 ([5.5,1,5.5],[10.5,5.5,10.5],"t1"),
 ([6,5.5,6],[10,8,10],"t1",("y",45)),
 ([6.7,8,6.7],[9.3,10.5,9.3],"t2",("y",45)),
 ([7.3,10.5,7.3],[8.7,13,8.7],"t2",("y",45)),
 ([7.7,13,7.7],[8.3,15,8.3],"t2"),
 ([7,2.5,4.9],[9,4.5,5.5],"core"),
],disp())

# ---------- CŒUR DÉMONIAQUE ----------
build("demon_heart",{"h":((140,15,20),16),"hd":((80,5,10),10),"v":((20,5,8),5),"horn":((45,40,45),8),"eye":((255,60,40),0)},[
 ([3.5,8,6],[8,12.5,10],"h"),([8,8,6],[12.5,12.5,10],"h"),
 ([4.5,5,6.2],[11.5,8,9.8],"h"),([6,3,6.6],[10,5,9.4],"hd"),([7,1.5,7],[9,3,9],"hd"),
 ([5,9,10],[5.8,12,10.3],"v"),([9.5,6,9.8],[10.2,10,10.1],"v"),([7.6,4,9.4],[8.4,8,9.7],"v"),
 ([3.5,12.5,7.5],[5,15,8.5],"horn",("z",22.5)),([11,12.5,7.5],[12.5,15,8.5],"horn",("z",-22.5)),
 ([7.3,9.5,10],[8.7,10.7,10.4],"eye"),
],disp())

# ---------- FRAGMENT DE DÉMON ----------
build("demon_fragment",{"s":((30,26,34),10),"s2":((50,44,56),8),"r":((220,30,30),10)},[
 ([6,2,7],[10,10,9],"s",("z",22.5)),
 ([7,9,7.2],[9.5,14,8.8],"s2",("z",-22.5)),
 ([4.5,4,7.3],[7,8,8.7],"s2",("z",45)),
 ([7.8,4,9],[8.6,11,9.3],"r",("z",22.5)),
 ([6,6,6.7],[7.5,6.8,7],"r"),
],disp())

# ---------- PAGE ANCIENNE ----------
build("ancient_page",{"p":((215,190,135),14),"ink":((95,65,40),0),"edge":((170,140,90),6),"seal":(GOLD,8)},[
 ([3,1,7.6],[13,13,8.2],"p"),
 ([3,13,7.4],[13,15,8.8],"edge",("x",22.5)),
 ([3,0.5,7.4],[13,1.5,8.4],"edge"),
 ([4.5,11,8.2],[11.5,11.6,8.4],"ink"),([4.5,9,8.2],[11,9.6,8.4],"ink"),
 ([4.5,7,8.2],[11.5,7.6,8.4],"ink"),([4.5,5,8.2],[9,5.6,8.4],"ink"),
 ([10,2.5,8.2],[12,4.5,8.6],"seal"),
],disp(gui=(15,-20,0)))

# ---------- CONVOCATION (parchemin roulé + sceau) ----------
build("tower_summons",{"p":((235,218,175),12),"pd":((200,180,135),8),"w":((110,70,40),8),"seal":((170,25,25),10),"rib":((60,40,140),6)},[
 ([3,6,6],[13,10,10],"p"),
 ([3.5,5.5,5.5],[12.5,10.5,10.5],"pd",("x",45)),
 ([1.5,6.5,6.5],[3,9.5,9.5],"w"),([13,6.5,6.5],[14.5,9.5,9.5],"w"),
 ([7.5,5.6,5.6],[8.5,10.4,10.4],"rib"),
 ([6.8,6.8,10],[9.2,9.2,10.8],"seal"),
 ([4,2,7.5],[12,6,8],"p",("x",-22.5)),
],disp(gui=(25,-35,0),gs=0.95))
print("ok")
